import os
import re
import struct
import sys
from typing import Dict, List, Optional, Tuple


class AssemblerError(Exception):
    """Error de sintaxis, rango o enlazado durante el ensamblado."""
    pass


class EnsambladorGrupo21:
    """
    Ensamblador y enlazador de dos pasadas para la ISA del Grupo 21 (Lab 3c):
    - Direccionamiento por byte (Little-Endian, 2 bytes por instrucción/palabra).
    - Opcodes de 5 bits (bits [15:11]).
    - Soporte para módulos externos (.EXTERNAL modulo-ETIQUETA) en carpeta lib/.
    """

    OPCODES = {
        "BR":   0b00000,
        "ADD":  0b00001,
        "SUB":  0b00010,
        "AND":  0b00011,
        "NOT":  0b00100,
        "MUL":  0b00101,
        "MULQ": 0b00110,
        "LSL":  0b00111,
        "LSR":  0b01000,
        "ASR":  0b01001,
        "LDW":  0b01010,
        "STW":  0b01011,
        "LDRW": 0b01100,
        "STRW": 0b01101,
        "LDIW": 0b01110,
        "STIW": 0b01111,
        "LDBL": 0b10000,
        "STBL": 0b10001,
        "LDBH": 0b10010,
        "STBH": 0b10011,
        "LEA":  0b10100,
        "JMP":  0b10101,
        "JSR":  0b10110,
        "JSRR": 0b10111,
        "TRAP": 0b11111,
    }

    TRAP_ALIASES = {
        "GETC": 0x20,
        "OUT":  0x21,
        "PUTS": 0x22,
        "IN":   0x23,
        "HALT": 0x25,
    }

    LEGACY_MNEMONICS = {"LD", "ST", "LDR", "STR", "LDI", "STI", "RTI"}

    REGISTERS = {f"R{i}": i for i in range(8)}

    def __init__(self):
        self.symbols: Dict[str, int] = {}
        self.origin: int = 0x3000
        self._pending_aliases: List[Tuple[str, str]] = []

    # -------------------------------------------------------------------------
    # Utilidades de parseo y validación de rangos
    # -------------------------------------------------------------------------
    @staticmethod
    def parse_number(token: str, line_info: str) -> int:
        tok = token.strip()
        try:
            if tok.startswith("#"):
                return int(tok[1:], 10)
            if tok.lower().startswith("x"):
                return int(tok[1:], 16)
            if tok.lower().startswith("0x"):
                return int(tok[2:], 16)
            if tok.lower().startswith("b"):
                return int(tok[1:], 2)
            return int(tok, 10)
        except ValueError:
            raise AssemblerError(f"{line_info}: literal numérico inválido '{token}'")

    @staticmethod
    def check_signed_range(val: int, bits: int, label_desc: str, line_info: str) -> int:
        min_v = -(1 << (bits - 1))
        max_v = (1 << (bits - 1)) - 1
        if val < min_v or val > max_v:
            raise AssemblerError(
                f"{line_info}: {label_desc} de {val} fuera de rango [{min_v}..{max_v}]"
            )
        return val & ((1 << bits) - 1)

    @staticmethod
    def check_unsigned_range(val: int, bits: int, label_desc: str, line_info: str) -> int:
        max_v = (1 << bits) - 1
        if val < 0 or val > max_v:
            raise AssemblerError(
                f"{line_info}: {label_desc} de {val} fuera de rango [0..{max_v}]"
            )
        return val & max_v

    def parse_register(self, token: str, line_info: str) -> int:
        reg = token.strip().upper()
        if reg not in self.REGISTERS:
            raise AssemblerError(f"{line_info}: registro inválido '{token}' (use R0..R7)")
        return self.REGISTERS[reg]

    @staticmethod
    def unescape_string(raw: str) -> bytes:
        decoded = bytes(raw, "utf-8").decode("unicode_escape")
        return decoded.encode("latin-1", errors="replace")

    @staticmethod
    def strip_comment(line: str) -> str:
        """Elimina comentarios ';' respetando literales entre comillas."""
        in_str = False
        escape = False
        for i, ch in enumerate(line):
            if escape:
                escape = False
                continue
            if ch == "\\":
                escape = True
                continue
            if ch == '"':
                in_str = not in_str
            elif ch == ";" and not in_str:
                return line[:i]
        return line

    @staticmethod
    def tokenize_operands(op_str: str) -> List[str]:
        """Divide operandos por coma o espacios (fuera de comillas)."""
        if not op_str.strip():
            return []
        if '"' in op_str:
            return [op_str.strip()]
        return [p.strip() for p in re.split(r"[,\s]+", op_str.strip()) if p.strip()]

    # -------------------------------------------------------------------------
    # Enlazador recursivo de proyectos (.EXTERNAL modulo-ETIQUETA)
    # -------------------------------------------------------------------------
    def _find_module_defining_symbol(self, search_dirs: List[str], symbol_name: str) -> Optional[str]:
        """Busca en los directorios qué archivo .asm define la etiqueta 'symbol_name'."""
        pattern = re.compile(rf"^\s*{re.escape(symbol_name)}(?:\s|$|;)", re.IGNORECASE)
        for d in search_dirs:
            if not os.path.isdir(d):
                continue
            for entry in os.listdir(d):
                if not entry.lower().endswith(".asm"):
                    continue
                full_path = os.path.join(d, entry)
                try:
                    with open(full_path, "r", encoding="utf-8") as f:
                        for raw in f:
                            clean = self.strip_comment(raw).strip()
                            if pattern.match(clean):
                                return full_path
                except OSError:
                    continue
        return None

    def collect_project_lines(self, main_path: str) -> List[Tuple[str, int, str]]:
        """
        Lee el archivo principal y anexa todos los módulos declarados con
        '.EXTERNAL modulo-ETIQUETA', buscando por nombre de archivo o por etiqueta en lib/.
        """
        base_dir = os.path.dirname(os.path.abspath(main_path))
        lib_dir = os.path.join(base_dir, "lib")

        loaded_files = set()
        pending_refs: List[Tuple[str, str]] = []
        symbol_aliases: List[Tuple[str, str]] = []
        collected: List[Tuple[str, int, str]] = []

        def read_file_lines(filepath: str, prefix_labels: Optional[str] = None):
            abs_fp = os.path.abspath(filepath)
            if abs_fp in loaded_files:
                return
            loaded_files.add(abs_fp)

            fname = os.path.basename(filepath)
            with open(filepath, "r", encoding="utf-8") as f:
                raw_lines = f.readlines()

            local_labels = set()
            if prefix_labels:
                for raw in raw_lines:
                    clean = self.strip_comment(raw).strip()
                    if not clean:
                        continue
                    first_tok = clean.split()[0]
                    up = first_tok.upper()
                    if (
                        not up.startswith(".")
                        and not self._is_br_mnemonic(up)
                        and up not in self.OPCODES
                        and up not in self.TRAP_ALIASES
                        and up not in self.LEGACY_MNEMONICS
                        and up != "RET"
                    ):
                        local_labels.add(first_tok)

            for idx, raw in enumerate(raw_lines, start=1):
                clean = self.strip_comment(raw).strip()
                if not clean:
                    continue

                upper_clean = clean.upper()
                if upper_clean == ".END":
                    continue
                if prefix_labels and upper_clean.startswith(".ORIG"):
                    continue

                if upper_clean.startswith(".EXTERNAL"):
                    parts = clean.split()
                    if len(parts) < 2 or "-" not in parts[1]:
                        raise AssemblerError(
                            f"{fname} Línea {idx}: sintaxis esperada '.EXTERNAL modulo-ETIQUETA'"
                        )
                    mod_name, sym_name = parts[1].split("-", 1)
                    pending_refs.append((mod_name, sym_name))
                    continue

                if prefix_labels and local_labels:
                    clean = self._namespace_module_line(clean, prefix_labels, local_labels)

                collected.append((fname, idx, clean))

        # 1. Leer archivo principal
        read_file_lines(main_path, prefix_labels=None)

        # 2. Resolver referencias externas
        while pending_refs:
            mod, sym = pending_refs.pop(0)
            cand_lib = os.path.join(lib_dir, f"{mod}.asm")
            cand_base = os.path.join(base_dir, f"{mod}.asm")

            if os.path.isfile(cand_lib):
                mod_path = cand_lib
            elif os.path.isfile(cand_base):
                mod_path = cand_base
            else:
                mod_path = self._find_module_defining_symbol([lib_dir, base_dir], sym)
                if mod_path is None:
                    raise AssemblerError(
                        f"No se encontró el módulo '{mod}.asm' ni la etiqueta '{sym}' en '{lib_dir}'."
                    )

            real_mod_prefix = os.path.splitext(os.path.basename(mod_path))[0]
            if real_mod_prefix != mod:
                symbol_aliases.append((f"{mod}-{sym}", f"{real_mod_prefix}-{sym}"))

            read_file_lines(mod_path, prefix_labels=real_mod_prefix)

        self._pending_aliases = symbol_aliases
        return collected

    def _namespace_module_line(self, line: str, mod: str, local_labels: set) -> str:
        """Prefija etiquetas locales de un módulo externo como 'mod-ETIQUETA'."""
        segments = re.split(r'(".*?")', line)
        for i in range(0, len(segments), 2):
            seg = segments[i]
            for lbl in sorted(local_labels, key=len, reverse=True):
                pattern = rf"(?<![A-Za-z0-9_-]){re.escape(lbl)}(?![A-Za-z0-9_-])"
                seg = re.sub(pattern, f"{mod}-{lbl}", seg)
            segments[i] = seg
        return "".join(segments)

    # -------------------------------------------------------------------------
    # Parseo de cada línea a (etiqueta, mnemónico, operandos_raw)
    # -------------------------------------------------------------------------
    def parse_statement(self, line: str) -> Tuple[Optional[str], Optional[str], str]:
        tokens = line.split(None, 1)
        first = tokens[0]
        rest = tokens[1] if len(tokens) > 1 else ""
        up = first.upper()

        is_mnemonic = (
            up in self.OPCODES
            or up in self.TRAP_ALIASES
            or up in self.LEGACY_MNEMONICS
            or up == "RET"
            or up.startswith(".")
            or self._is_br_mnemonic(up)
        )

        if is_mnemonic:
            return None, up, rest

        label = first
        if not rest.strip():
            return label, None, ""

        sub_tokens = rest.split(None, 1)
        mnem = sub_tokens[0].upper()
        ops = sub_tokens[1] if len(sub_tokens) > 1 else ""
        return label, mnem, ops

    @staticmethod
    def _is_br_mnemonic(up: str) -> bool:
        if not up.startswith("BR"):
            return False
        suffix = up[2:]
        return set(suffix).issubset({"N", "Z", "P"})

    # -------------------------------------------------------------------------
    # Pasada 1: Construcción de tabla de símbolos (direcciones en bytes)
    # -------------------------------------------------------------------------
    def pass_one(self, lines: List[Tuple[str, int, str]]) -> List[Tuple[str, int, int, Optional[str], str]]:
        self.symbols.clear()
        parsed_stmts = []
        lc = 0x3000
        origin_set = False

        for fname, lno, clean in lines:
            line_info = f"{fname} Línea {lno}"
            label, mnem, ops_raw = self.parse_statement(clean)

            if mnem == ".ORIG":
                if origin_set:
                    raise AssemblerError(f"{line_info}: directiva .ORIG duplicada.")
                ops = self.tokenize_operands(ops_raw)
                if len(ops) != 1:
                    raise AssemblerError(f"{line_info}: .ORIG requiere una dirección.")
                lc = self.parse_number(ops[0], line_info) & 0xFFFF
                if lc & 1:
                    raise AssemblerError(f"{line_info}: .ORIG 0x{lc:04X} debe ser una dirección par.")
                self.origin = lc
                origin_set = True
                continue

            if mnem == ".END":
                continue

            # Asegurar alineación par antes de etiquetas o instrucciones de palabra
            if lc & 1:
                lc += 1

            if label:
                if label in self.symbols:
                    raise AssemblerError(f"{line_info}: etiqueta duplicada '{label}'.")
                self.symbols[label] = lc

            if mnem is None:
                continue

            parsed_stmts.append((fname, lno, lc, mnem, ops_raw))

            if mnem == ".FILL":
                lc += 2
            elif mnem == ".BLKW":
                ops = self.tokenize_operands(ops_raw)
                if len(ops) != 1:
                    raise AssemblerError(f"{line_info}: .BLKW requiere cantidad de palabras.")
                count = self.parse_number(ops[0], line_info)
                if count < 0:
                    raise AssemblerError(f"{line_info}: .BLKW no admite valores negativos.")
                lc += count * 2
            elif mnem == ".STRINGZ":
                m = re.match(r'^"(.*)"$', ops_raw.strip())
                if not m:
                    raise AssemblerError(f'{line_info}: .STRINGZ requiere texto entre comillas ("...").')
                raw_bytes = self.unescape_string(m.group(1))
                total_len = len(raw_bytes) + 1
                if total_len & 1:
                    total_len += 1
                lc += total_len
            else:
                lc += 2

            if lc > 0x10000:
                raise AssemblerError(f"{line_info}: desbordamiento de memoria (excede 0xFFFF).")

        for alias_name, target_name in self._pending_aliases:
            if target_name in self.symbols:
                self.symbols[alias_name] = self.symbols[target_name]

        return parsed_stmts

    # -------------------------------------------------------------------------
    # Pasada 2: Generación de código máquina (bytearray Little-Endian)
    # -------------------------------------------------------------------------
    def pass_two(self, stmts: List[Tuple[str, int, int, Optional[str], str]]) -> bytearray:
        output = bytearray()
        current_addr = self.origin

        for fname, lno, addr, mnem, ops_raw in stmts:
            line_info = f"{fname} Línea {lno}"

            while current_addr < addr:
                output.append(0x00)
                current_addr += 1

            pc_next = (addr + 2) & 0xFFFF
            ops = self.tokenize_operands(ops_raw)

            if mnem == ".FILL":
                if len(ops) != 1:
                    raise AssemblerError(f"{line_info}: .FILL requiere 1 operando.")
                tok = ops[0]
                if tok in self.symbols:
                    val = self.symbols[tok]
                else:
                    val = self.parse_number(tok, line_info)
                    if val < -32768 or val > 65535:
                        raise AssemblerError(f"{line_info}: valor .FILL {val} fuera de 16 bits.")
                output.extend(struct.pack("<H", val & 0xFFFF))
                current_addr += 2

            elif mnem == ".BLKW":
                count = self.parse_number(ops[0], line_info)
                output.extend(b"\x00\x00" * count)
                current_addr += count * 2

            elif mnem == ".STRINGZ":
                m = re.match(r'^"(.*)"$', ops_raw.strip())
                raw_bytes = self.unescape_string(m.group(1)) + b"\x00"
                if len(raw_bytes) & 1:
                    raw_bytes += b"\x00"
                output.extend(raw_bytes)
                current_addr += len(raw_bytes)

            else:
                word = self.encode_instruction(mnem, ops, pc_next, line_info)
                output.extend(struct.pack("<H", word & 0xFFFF))
                current_addr += 2

        return output

    def resolve_target(self, token: str, line_info: str) -> int:
        if token in self.symbols:
            return self.symbols[token]
        return self.parse_number(token, line_info)

    def encode_instruction(self, mnem: str, ops: List[str], pc_next: int, line_info: str) -> int:
        if mnem in self.LEGACY_MNEMONICS:
            raise AssemblerError(
                f"{line_info}: instrucción '{mnem}' de LC-3 estándar no soportada en la ISA nueva (migrar a LDW/STW/LDRW/STRW/LDIW/STIW)."
            )

        # 1. Saltos condicionales
        if self._is_br_mnemonic(mnem):
            if len(ops) != 1:
                raise AssemblerError(f"{line_info}: {mnem} requiere una etiqueta o desplazamiento.")
            suffix = mnem[2:]
            if not suffix:
                n, z, p = 1, 1, 1
            else:
                n = 1 if "N" in suffix else 0
                z = 1 if "Z" in suffix else 0
                p = 1 if "P" in suffix else 0

            target = self.resolve_target(ops[0], line_info)
            offset = target - pc_next
            off7 = self.check_signed_range(offset, 7, "offset", line_info)
            return (self.OPCODES["BR"] << 11) | (n << 10) | (z << 9) | (p << 8) | off7

        # 2. ALU Registro / Inmediato (ADD, SUB, AND, MUL, MULQ)
        if mnem in ("ADD", "SUB", "AND", "MUL", "MULQ"):
            if len(ops) != 3:
                raise AssemblerError(f"{line_info}: {mnem} requiere 3 operandos (DR, SR1, SR2/imm4).")
            dr = self.parse_register(ops[0], line_info)
            sr1 = self.parse_register(ops[1], line_info)
            op3 = ops[2].upper()
            op_code = self.OPCODES[mnem]

            if op3 in self.REGISTERS:
                sr2 = self.REGISTERS[op3]
                return (op_code << 11) | (dr << 8) | (sr1 << 5) | (0 << 4) | sr2
            else:
                imm_val = self.parse_number(ops[2], line_info)
                imm4 = self.check_signed_range(imm_val, 4, f"inmediato para {mnem}", line_info)
                return (op_code << 11) | (dr << 8) | (sr1 << 5) | (1 << 4) | imm4

        # 3. NOT
        if mnem == "NOT":
            if len(ops) != 2:
                raise AssemblerError(f"{line_info}: NOT requiere 2 operandos (DR, SR1).")
            dr = self.parse_register(ops[0], line_info)
            sr1 = self.parse_register(ops[1], line_info)
            return (self.OPCODES["NOT"] << 11) | (dr << 8) | (sr1 << 5) | 0x1F

        # 4. Desplazamientos (LSL, LSR, ASR)
        if mnem in ("LSL", "LSR", "ASR"):
            if len(ops) != 3:
                raise AssemblerError(f"{line_info}: {mnem} requiere 3 operandos (DR, SR1, shift4).")
            dr = self.parse_register(ops[0], line_info)
            sr1 = self.parse_register(ops[1], line_info)
            sh_val = self.parse_number(ops[2], line_info)
            sh4 = self.check_unsigned_range(sh_val, 4, f"desplazamiento para {mnem}", line_info)
            return (self.OPCODES[mnem] << 11) | (dr << 8) | (sr1 << 5) | sh4

        # 5. Relativos al PC (LDW, STW, LDIW, STIW, LEA) -> PCoffset8 en bytes
        if mnem in ("LDW", "STW", "LDIW", "STIW", "LEA"):
            if len(ops) != 2:
                raise AssemblerError(f"{line_info}: {mnem} requiere 2 operandos (Reg, etiqueta/offset).")
            reg = self.parse_register(ops[0], line_info)
            target = self.resolve_target(ops[1], line_info)
            offset = target - pc_next
            off8 = self.check_signed_range(offset, 8, f"offset para {mnem}", line_info)
            return (self.OPCODES[mnem] << 11) | (reg << 8) | off8

        # 6. Base + Offset5 en bytes (LDRW, STRW, LDBL, STBL, LDBH, STBH)
        if mnem in ("LDRW", "STRW", "LDBL", "STBL", "LDBH", "STBH"):
            if len(ops) != 3:
                raise AssemblerError(f"{line_info}: {mnem} requiere 3 operandos (Reg, BaseR, offset5).")
            reg = self.parse_register(ops[0], line_info)
            base_r = self.parse_register(ops[1], line_info)
            off_val = self.parse_number(ops[2], line_info)
            off5 = self.check_signed_range(off_val, 5, f"offset5 para {mnem}", line_info)
            return (self.OPCODES[mnem] << 11) | (reg << 8) | (base_r << 5) | off5

        # 7. Saltos a registro (JMP, RET, JSRR)
        if mnem == "RET":
            if ops:
                raise AssemblerError(f"{line_info}: RET no lleva operandos.")
            return (self.OPCODES["JMP"] << 11) | (7 << 5)

        if mnem in ("JMP", "JSRR"):
            if len(ops) != 1:
                raise AssemblerError(f"{line_info}: {mnem} requiere 1 operando (BaseR).")
            base_r = self.parse_register(ops[0], line_info)
            return (self.OPCODES[mnem] << 11) | (base_r << 5)

        # 8. JSR (PCoffset11 en bytes)
        if mnem == "JSR":
            if len(ops) != 1:
                raise AssemblerError(f"{line_info}: JSR requiere 1 operando (etiqueta/offset11).")
            target = self.resolve_target(ops[0], line_info)
            offset = target - pc_next
            off11 = self.check_signed_range(offset, 11, "offset11 para JSR", line_info)
            return (self.OPCODES["JSR"] << 11) | off11

        # 9. TRAP y alias
        if mnem in self.TRAP_ALIASES:
            if ops:
                raise AssemblerError(f"{line_info}: {mnem} no lleva operandos.")
            vect = self.TRAP_ALIASES[mnem]
            return (self.OPCODES["TRAP"] << 11) | vect

        if mnem == "TRAP":
            if len(ops) != 1:
                raise AssemblerError(f"{line_info}: TRAP requiere un vector de 8 bits.")
            vect_val = self.parse_number(ops[0], line_info)
            vect8 = self.check_unsigned_range(vect_val, 8, "vector TRAP", line_info)
            return (self.OPCODES["TRAP"] << 11) | vect8

        raise AssemblerError(f"{line_info}: instrucción no soportada: {mnem}")

    # -------------------------------------------------------------------------
    # Punto de entrada principal de ensamblado
    # -------------------------------------------------------------------------
    def assemble(self, input_path: str, output_path: Optional[str] = None, fmt: str = "obj"):
        lines = self.collect_project_lines(input_path)
        stmts = self.pass_one(lines)
        code_bytes = self.pass_two(stmts)

        if output_path is None:
            base, _ = os.path.splitext(input_path)
            output_path = f"{base}.{fmt}"

        if fmt == "obj":
            header = struct.pack("<H", self.origin)
            with open(output_path, "wb") as f:
                f.write(header + code_bytes)
        elif fmt == "hex":
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(f"{self.origin:04X}\n")
                for i in range(0, len(code_bytes), 2):
                    w = struct.unpack("<H", code_bytes[i:i+2])[0]
                    f.write(f"{w:04X}\n")
        else:
            raise ValueError(f"Formato no soportado: {fmt}")

        return output_path, len(code_bytes)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python assembler.py <archivo.asm> [--format obj|hex] [-o salida]")
        sys.exit(1)

    in_file = sys.argv[1]
    out_fmt = "obj"
    out_file = None

    if "--format" in sys.argv:
        idx = sys.argv.index("--format")
        if idx + 1 < len(sys.argv):
            out_fmt = sys.argv[idx + 1].lower()

    if "-o" in sys.argv:
        idx = sys.argv.index("-o")
        if idx + 1 < len(sys.argv):
            out_file = sys.argv[idx + 1]

    asm = EnsambladorGrupo21()
    try:
        saved_path, size_bytes = asm.assemble(in_file, out_file, out_fmt)
        print(
            f"Ensamblado exitoso -> '{saved_path}' "
            f"(Origen: 0x{asm.origin:04X}, Tamaño: {size_bytes} bytes, Símbolos: {len(asm.symbols)})"
        )
    except AssemblerError as e:
        print(f"ERROR: {e}")
        sys.exit(1)