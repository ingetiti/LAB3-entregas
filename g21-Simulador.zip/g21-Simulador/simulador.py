import sys
import struct


def to_signed16(val: int) -> int:
    """Convierte un entero de 16 bits sin signo [0..65535] a con signo [-32768..32767]."""
    val &= 0xFFFF
    return val - 0x10000 if (val & 0x8000) else val


def sign_extend(val: int, bits: int) -> int:
    """Extiende el signo de un campo de 'bits' de ancho a entero con signo de Python."""
    sign_bit = 1 << (bits - 1)
    mask = (1 << bits) - 1
    val &= mask
    return (val - (1 << bits)) if (val & sign_bit) else val


class SimuladorGrupo21:
    """
    Simulador funcional para la ISA del Grupo 21 (Lab 3c):
- Memoria de 64 KB (65536 bytes) direccionable por byte, Little-Endian.
- 8 registros de propósito general de 16 bits (R0..R7).
- PC de 16 bits (incremento de +2 bytes por instrucción).
- Banderas de condición: N, Z, P y V (Overflow).
- Sistema Operativo residente en memoria baja (< 0x3000) con vectores TRAP y E/S mapeada.
    """

    MEM_SIZE = 65536  # 0x0000 .. 0xFFFF

    # Registros de E/S mapeados en memoria (Memory-Mapped I/O)
    ADDR_KBSR = 0xFE00
    ADDR_KBDR = 0xFE02
    ADDR_DSR  = 0xFE04
    ADDR_DDR  = 0xFE06
    ADDR_MCR  = 0xFFFE

    # Mapa de Opcodes de 5 bits (bits [15:11])
    OP_BR   = 0b00000  # 0
    OP_ADD  = 0b00001  # 1
    OP_SUB  = 0b00010  # 2
    OP_AND  = 0b00011  # 3
    OP_NOT  = 0b00100  # 4
    OP_MUL  = 0b00101  # 5
    OP_MULQ = 0b00110  # 6
    OP_LSL  = 0b00111  # 7
    OP_LSR  = 0b01000  # 8
    OP_ASR  = 0b01001  # 9
    OP_LDW  = 0b01010  # 10
    OP_STW  = 0b01011  # 11
    OP_LDRW = 0b01100  # 12
    OP_STRW = 0b01101  # 13
    OP_LDIW = 0b01110  # 14
    OP_STIW = 0b01111  # 15
    OP_LDBL = 0b10000  # 16
    OP_STBL = 0b10001  # 17
    OP_LDBH = 0b10010  # 18
    OP_STBH = 0b10011  # 19
    OP_LEA  = 0b10100  # 20
    OP_JMP  = 0b10101  # 21 (incluye RET cuando BaseR = R7)
    OP_JSR  = 0b10110  # 22
    OP_JSRR = 0b10111  # 23
    OP_TRAP = 0b11111  # 31

    def __init__(self, strict_overflow: bool = False):
        self.mem = bytearray(self.MEM_SIZE)
        self.R = [0] * 8
        self.R[6] = 0xFD00
        self.PC = 0x3000
        self.IR = 0x0000

        # Banderas de estado
        self.N = 0
        self.Z = 1
        self.P = 0
        self.V = 0  # Overflow

        # Control de ejecución y métricas
        self.halted = False
        self.strict_overflow = strict_overflow
        self.user_instructions = 0
        self.os_instructions = 0
        self.overflow_events = []
        self.input_buffer = ""
        self._kb_char = 0
        self._kb_ready = False
        self.on_output = None

        self._install_os()

    def reset(self):
        self.mem = bytearray(self.MEM_SIZE)
        self.R = [0] * 8
        self.R[6] = 0xFD00
        self.PC = 0x3000
        self.IR = 0x0000
        self.N = 0
        self.Z = 1
        self.P = 0
        self.V = 0
        self.halted = False
        self.user_instructions = 0
        self.os_instructions = 0
        self.overflow_events.clear()
        self._kb_char = 0
        self._kb_ready = False
        self._install_os()

    # -------------------------------------------------------------------------
    # Instalación del Sistema Operativo en memoria baja (< 0x3000)
    # -------------------------------------------------------------------------
    def _put_raw_word(self, addr: int, val: int):
        addr &= 0xFFFF
        val &= 0xFFFF
        self.mem[addr] = val & 0xFF
        self.mem[(addr + 1) & 0xFFFF] = (val >> 8) & 0xFF

    def _install_os(self):
        """
        Carga la Tabla de Vectores TRAP (0x0000..0x01FE) y las rutinas del SO
        (GETC, OUT, PUTS, IN, HALT) en 0x0400..0x04D5 usando instrucciones ISA G21.
        """
        def br(n, z, p, target, pc_next):
            return (self.OP_BR << 11) | (n << 10) | (z << 9) | (p << 8) | ((target - pc_next) & 0x7F)

        def add_imm(dr, sr1, imm4):
            return (self.OP_ADD << 11) | (dr << 8) | (sr1 << 5) | (1 << 4) | (imm4 & 0xF)

        def and_imm(dr, sr1, imm4):
            return (self.OP_AND << 11) | (dr << 8) | (sr1 << 5) | (1 << 4) | (imm4 & 0xF)

        def and_reg(dr, sr1, sr2):
            return (self.OP_AND << 11) | (dr << 8) | (sr1 << 5) | (sr2 & 0x7)

        def ldw(dr, target, pc_next):
            return (self.OP_LDW << 11) | (dr << 8) | ((target - pc_next) & 0xFF)

        def stw(dr, target, pc_next):
            return (self.OP_STW << 11) | (dr << 8) | ((target - pc_next) & 0xFF)

        def ldiw(dr, target, pc_next):
            return (self.OP_LDIW << 11) | (dr << 8) | ((target - pc_next) & 0xFF)

        def stiw(dr, target, pc_next):
            return (self.OP_STIW << 11) | (dr << 8) | ((target - pc_next) & 0xFF)

        def ldbl(dr, sr1, off5):
            return (self.OP_LDBL << 11) | (dr << 8) | (sr1 << 5) | (off5 & 0x1F)

        def ret():
            return (self.OP_JMP << 11) | (7 << 5)

        def trap(vect):
            return (self.OP_TRAP << 11) | (vect & 0xFF)

        # Tabla de Vectores TRAP (índice * 2 bytes)
        self._put_raw_word(0x20 * 2, 0x0400)  # GETC
        self._put_raw_word(0x21 * 2, 0x0420)  # OUT
        self._put_raw_word(0x22 * 2, 0x0440)  # PUTS
        self._put_raw_word(0x23 * 2, 0x0480)  # IN
        self._put_raw_word(0x25 * 2, 0x04C0)  # HALT

        # --- Rutina TRAP x20: GETC (0x0400) ---
        self._put_raw_word(0x0400, ldiw(0, 0x0408, 0x0402))      # LDIW R0, KBSR
        self._put_raw_word(0x0402, br(0, 1, 1, 0x0400, 0x0404))  # BRzp poll
        self._put_raw_word(0x0404, ldiw(0, 0x040A, 0x0406))      # LDIW R0, KBDR
        self._put_raw_word(0x0406, ret())                        # RET
        self._put_raw_word(0x0408, self.ADDR_KBSR)
        self._put_raw_word(0x040A, self.ADDR_KBDR)

        # --- Rutina TRAP x21: OUT (0x0420) ---
        self._put_raw_word(0x0420, stw(1, 0x042C, 0x0422))       # STW R1, save_r1
        self._put_raw_word(0x0422, ldiw(1, 0x042E, 0x0424))      # LDIW R1, DSR
        self._put_raw_word(0x0424, br(0, 1, 1, 0x0422, 0x0426))  # BRzp poll
        self._put_raw_word(0x0426, stiw(0, 0x0430, 0x0428))      # STIW R0, DDR
        self._put_raw_word(0x0428, ldw(1, 0x042C, 0x042A))       # LDW R1, save_r1
        self._put_raw_word(0x042A, ret())                        # RET
        self._put_raw_word(0x042C, 0x0000)
        self._put_raw_word(0x042E, self.ADDR_DSR)
        self._put_raw_word(0x0430, self.ADDR_DDR)

        # --- Rutina TRAP x22: PUTS (0x0440) ---
        self._put_raw_word(0x0440, stw(0, 0x0460, 0x0442))       # STW R0, save_r0
        self._put_raw_word(0x0442, stw(1, 0x0462, 0x0444))       # STW R1, save_r1
        self._put_raw_word(0x0444, stw(2, 0x0464, 0x0446))       # STW R2, save_r2
        self._put_raw_word(0x0446, add_imm(1, 0, 0))             # ADD R1, R0, #0
        self._put_raw_word(0x0448, and_imm(0, 0, 0))             # AND R0, R0, #0
        self._put_raw_word(0x044A, ldbl(0, 1, 0))                # LDBL R0, R1, #0
        self._put_raw_word(0x044C, br(0, 1, 0, 0x0458, 0x044E))  # BRz done
        self._put_raw_word(0x044E, ldiw(2, 0x0466, 0x0450))      # LDIW R2, DSR
        self._put_raw_word(0x0450, br(0, 1, 1, 0x044E, 0x0452))  # BRzp poll
        self._put_raw_word(0x0452, stiw(0, 0x0468, 0x0454))      # STIW R0, DDR
        self._put_raw_word(0x0454, add_imm(1, 1, 1))             # ADD R1, R1, #1
        self._put_raw_word(0x0456, br(1, 1, 1, 0x0448, 0x0458))  # BRnzp loop
        self._put_raw_word(0x0458, ldw(0, 0x0460, 0x045A))       # LDW R0, save_r0
        self._put_raw_word(0x045A, ldw(1, 0x0462, 0x045C))       # LDW R1, save_r1
        self._put_raw_word(0x045C, ldw(2, 0x0464, 0x045E))       # LDW R2, save_r2
        self._put_raw_word(0x045E, ret())                        # RET
        self._put_raw_word(0x0460, 0x0000)
        self._put_raw_word(0x0462, 0x0000)
        self._put_raw_word(0x0464, 0x0000)
        self._put_raw_word(0x0466, self.ADDR_DSR)
        self._put_raw_word(0x0468, self.ADDR_DDR)

        # --- Rutina TRAP x23: IN (0x0480) ---
        self._put_raw_word(0x0480, stw(7, 0x0490, 0x0482))       # STW R7, save_r7
        self._put_raw_word(0x0482, ldw(0, 0x0492, 0x0484))       # LDW R0, prompt_ptr
        self._put_raw_word(0x0484, trap(0x22))                   # PUTS
        self._put_raw_word(0x0486, trap(0x20))                   # GETC
        self._put_raw_word(0x0488, trap(0x21))                   # OUT
        self._put_raw_word(0x048A, ldw(7, 0x0490, 0x048C))       # LDW R7, save_r7
        self._put_raw_word(0x048C, ret())                        # RET
        self._put_raw_word(0x0490, 0x0000)
        self._put_raw_word(0x0492, 0x0494)
        prompt = b"Ingrese un caracter: \x00"
        for i, b in enumerate(prompt):
            self.mem[0x0494 + i] = b

        # --- Rutina TRAP x25: HALT (0x04C0) ---
        self._put_raw_word(0x04C0, stw(0, 0x04CE, 0x04C2))       # STW R0, save_r0
        self._put_raw_word(0x04C2, stw(1, 0x04D0, 0x04C4))       # STW R1, save_r1
        self._put_raw_word(0x04C4, ldiw(0, 0x04D2, 0x04C6))      # LDIW R0, MCR
        self._put_raw_word(0x04C6, ldw(1, 0x04D4, 0x04C8))       # LDW R1, mask_7fff
        self._put_raw_word(0x04C8, and_reg(0, 0, 1))             # AND R0, R0, R1
        self._put_raw_word(0x04CA, stiw(0, 0x04D2, 0x04CC))      # STIW R0, MCR
        self._put_raw_word(0x04CC, br(1, 1, 1, 0x04CC, 0x04CE))  # BRnzp halt_loop
        self._put_raw_word(0x04CE, 0x0000)
        self._put_raw_word(0x04D0, 0x0000)
        self._put_raw_word(0x04D2, self.ADDR_MCR)
        self._put_raw_word(0x04D4, 0x7FFF)

        # MCR activo (bit 15 = 1)
        self._put_raw_word(self.ADDR_MCR, 0x8000)

    # -------------------------------------------------------------------------
    # Acceso a Memoria (Little-Endian + E/S Mapeada + Validación de Alineación)
    # -------------------------------------------------------------------------
    def read_byte(self, addr: int) -> int:
        return self.mem[addr & 0xFFFF]

    def write_byte(self, addr: int, val: int):
        self.mem[addr & 0xFFFF] = val & 0xFF

    def read_word(self, addr: int) -> int:
        addr &= 0xFFFF
        if addr & 1:
            raise MemoryError(f"Error de alineación en lectura de palabra en 0x{addr:04X} (PC=0x{self.PC:04X})")

        if addr == self.ADDR_KBSR:
            if not self._kb_ready:
                if self.input_buffer:
                    ch = self.input_buffer[0]
                    self.input_buffer = self.input_buffer[1:]
                    self._kb_char = ord(ch) & 0xFF
                    self._kb_ready = True
                elif self.on_output is None and sys.stdin is not None and not sys.stdin.closed:
                    try:
                        line = sys.stdin.read(1)
                        if line:
                            self._kb_char = ord(line) & 0xFF
                            self._kb_ready = True
                    except Exception:
                        pass
            return 0x8000 if self._kb_ready else 0x0000

        if addr == self.ADDR_KBDR:
            self._kb_ready = False
            return self._kb_char & 0xFF

        if addr == self.ADDR_DSR:
            return 0x8000

        low = self.mem[addr]
        high = self.mem[(addr + 1) & 0xFFFF]
        return (high << 8) | low

    def write_word(self, addr: int, val: int):
        addr &= 0xFFFF
        if addr & 1:
            raise MemoryError(f"Error de alineación en escritura de palabra en 0x{addr:04X} (PC=0x{self.PC:04X})")
        val &= 0xFFFF

        if addr == self.ADDR_DDR:
            ch = chr(val & 0xFF)
            if self.on_output:
                self.on_output(ch)
            else:
                sys.stdout.write(ch)
                sys.stdout.flush()
            return

        if addr == self.ADDR_MCR:
            self._put_raw_word(addr, val)
            if (val & 0x8000) == 0:
                self.halted = True
            return

        self.mem[addr] = val & 0xFF
        self.mem[(addr + 1) & 0xFFFF] = (val >> 8) & 0xFF

    # -------------------------------------------------------------------------
    # Carga de archivo .obj
    # -------------------------------------------------------------------------
    def load_obj(self, filepath: str):
        """
        Carga un archivo binario .obj donde los primeros 2 bytes indican la
        dirección de origen (.ORIG) y el resto son bytes de instrucciones/datos.
        """
        with open(filepath, "rb") as f:
            data = f.read()

        if len(data) < 2:
            raise ValueError("Archivo .obj inválido o vacío.")

        origin = struct.unpack("<H", data[:2])[0]
        payload = data[2:]

        if origin + len(payload) > self.MEM_SIZE:
            raise OverflowError(
                f"Desbordamiento de memoria al cargar .obj: origen 0x{origin:04X} + {len(payload)} bytes excede 64 KB."
            )

        for i, b in enumerate(payload):
            self.mem[(origin + i) & 0xFFFF] = b

        self.PC = origin

    # -------------------------------------------------------------------------
    # Actualización de Banderas (N, Z, P, V)
    # -------------------------------------------------------------------------
    def update_nzp(self, result: int):
        s_val = to_signed16(result)
        if s_val < 0:
            self.N, self.Z, self.P = 1, 0, 0
        elif s_val == 0:
            self.N, self.Z, self.P = 0, 1, 0
        else:
            self.N, self.Z, self.P = 0, 0, 1

    def _register_overflow(self, pc_instr: int, mnemonic: str, detail: str):
        self.V = 1
        msg = f"[OVERFLOW V=1] PC=0x{pc_instr:04X} ({mnemonic}): {detail}"
        self.overflow_events.append(msg)
        if self.strict_overflow:
            raise OverflowError(msg)

    # -------------------------------------------------------------------------
    # Ciclo Fetch - Decode - Execute
    # -------------------------------------------------------------------------
    def step(self):
        if self.halted:
            return

        pc_actual = self.PC
        self.IR = self.read_word(pc_actual)
        self.PC = (self.PC + 2) & 0xFFFF

        # Contabilizar instrucciones de usuario vs Sistema Operativo (< 0x3000)
        if pc_actual < 0x3000:
            self.os_instructions += 1
        else:
            self.user_instructions += 1

        opcode = (self.IR >> 11) & 0x1F
        dr = (self.IR >> 8) & 0x07
        sr1 = (self.IR >> 5) & 0x07
        mode = (self.IR >> 4) & 0x01

        # --- CONTROL DE FLUJO ---
        if opcode == self.OP_BR:
            n = (self.IR >> 10) & 1
            z = (self.IR >> 9) & 1
            p = (self.IR >> 8) & 1
            offset7 = sign_extend(self.IR & 0x7F, 7)
            if (n and self.N) or (z and self.Z) or (p and self.P):
                self.PC = (self.PC + offset7) & 0xFFFF

        elif opcode == self.OP_JMP:
            self.PC = self.R[sr1] & 0xFFFF

        elif opcode == self.OP_JSR:
            self.R[7] = self.PC
            offset11 = sign_extend(self.IR & 0x7FF, 11)
            self.PC = (self.PC + offset11) & 0xFFFF

        elif opcode == self.OP_JSRR:
            temp = self.R[sr1] & 0xFFFF
            self.R[7] = self.PC
            self.PC = temp

        # --- ARITMÉTICA Y LÓGICA ---
        elif opcode == self.OP_ADD:
            a = to_signed16(self.R[sr1])
            b = sign_extend(self.IR & 0x0F, 4) if mode else to_signed16(self.R[self.IR & 0x07])
            res_full = a + b
            res16 = res_full & 0xFFFF
            self.R[dr] = res16
            self.update_nzp(res16)

            self.V = 0
            if res_full < -32768 or res_full > 32767:
                self._register_overflow(pc_actual, "ADD", f"{a} + {b} = {res_full}")

        elif opcode == self.OP_SUB:
            a = to_signed16(self.R[sr1])
            b = sign_extend(self.IR & 0x0F, 4) if mode else to_signed16(self.R[self.IR & 0x07])
            res_full = a - b
            res16 = res_full & 0xFFFF
            self.R[dr] = res16
            self.update_nzp(res16)

            self.V = 0
            if res_full < -32768 or res_full > 32767:
                self._register_overflow(pc_actual, "SUB", f"{a} - {b} = {res_full}")

        elif opcode == self.OP_AND:
            a = self.R[sr1]
            b = (sign_extend(self.IR & 0x0F, 4) & 0xFFFF) if mode else self.R[self.IR & 0x07]
            res16 = (a & b) & 0xFFFF
            self.R[dr] = res16
            self.V = 0
            self.update_nzp(res16)

        elif opcode == self.OP_NOT:
            res16 = (~self.R[sr1]) & 0xFFFF
            self.R[dr] = res16
            self.V = 0
            self.update_nzp(res16)

        elif opcode == self.OP_MUL:
            a = to_signed16(self.R[sr1])
            b = sign_extend(self.IR & 0x0F, 4) if mode else to_signed16(self.R[self.IR & 0x07])
            prod32 = a * b
            res16 = prod32 & 0xFFFF
            self.R[dr] = res16
            self.update_nzp(res16)

            self.V = 0
            if prod32 < -32768 or prod32 > 32767:
                self._register_overflow(pc_actual, "MUL", f"{a} * {b} = {prod32} (truncado a {to_signed16(res16)})")

        elif opcode == self.OP_MULQ:
            a = to_signed16(self.R[sr1])
            b = sign_extend(self.IR & 0x0F, 4) if mode else to_signed16(self.R[self.IR & 0x07])
            prod32 = (a * b) >> 8
            res16 = prod32 & 0xFFFF
            self.R[dr] = res16
            self.update_nzp(res16)

            self.V = 0
            if prod32 < -32768 or prod32 > 32767:
                self._register_overflow(pc_actual, "MULQ", f"({a} * {b}) >> 8 = {prod32}")

        # --- DESPLAZAMIENTOS ---
        elif opcode == self.OP_LSL:
            shift = self.IR & 0x0F
            val = self.R[sr1] & 0xFFFF
            res_full = val << shift
            res16 = res_full & 0xFFFF
            self.R[dr] = res16
            self.update_nzp(res16)

            self.V = 0
            if shift > 0 and (res_full >> 16) != 0:
                self._register_overflow(pc_actual, "LSL", f"0x{val:04X} << {shift} pierde bits altos")

        elif opcode == self.OP_LSR:
            shift = self.IR & 0x0F
            val = self.R[sr1] & 0xFFFF
            res16 = (val >> shift) & 0xFFFF
            self.R[dr] = res16
            self.V = 0
            self.update_nzp(res16)

        elif opcode == self.OP_ASR:
            shift = self.IR & 0x0F
            s_val = to_signed16(self.R[sr1])
            res16 = (s_val >> shift) & 0xFFFF
            self.R[dr] = res16
            self.V = 0
            self.update_nzp(res16)

        # --- ACCESO A MEMORIA ---
        elif opcode == self.OP_LDW:
            off8 = sign_extend(self.IR & 0xFF, 8)
            addr = (self.PC + off8) & 0xFFFF
            res16 = self.read_word(addr)
            self.R[dr] = res16
            self.V = 0
            self.update_nzp(res16)

        elif opcode == self.OP_STW:
            off8 = sign_extend(self.IR & 0xFF, 8)
            addr = (self.PC + off8) & 0xFFFF
            self.write_word(addr, self.R[dr])

        elif opcode == self.OP_LDRW:
            off5 = sign_extend(self.IR & 0x1F, 5)
            addr = (self.R[sr1] + off5) & 0xFFFF
            res16 = self.read_word(addr)
            self.R[dr] = res16
            self.V = 0
            self.update_nzp(res16)

        elif opcode == self.OP_STRW:
            off5 = sign_extend(self.IR & 0x1F, 5)
            addr = (self.R[sr1] + off5) & 0xFFFF
            self.write_word(addr, self.R[dr])

        elif opcode == self.OP_LDIW:
            off8 = sign_extend(self.IR & 0xFF, 8)
            ptr_addr = (self.PC + off8) & 0xFFFF
            eff_addr = self.read_word(ptr_addr)
            res16 = self.read_word(eff_addr)
            self.R[dr] = res16
            self.V = 0
            self.update_nzp(res16)

        elif opcode == self.OP_STIW:
            off8 = sign_extend(self.IR & 0xFF, 8)
            ptr_addr = (self.PC + off8) & 0xFFFF
            eff_addr = self.read_word(ptr_addr)
            self.write_word(eff_addr, self.R[dr])

        elif opcode == self.OP_LDBL:
            off5 = sign_extend(self.IR & 0x1F, 5)
            addr = (self.R[sr1] + off5) & 0xFFFF
            byte_val = self.read_byte(addr)
            self.R[dr] = (self.R[dr] & 0xFF00) | byte_val
            self.V = 0
            self.update_nzp(self.R[dr])

        elif opcode == self.OP_STBL:
            off5 = sign_extend(self.IR & 0x1F, 5)
            addr = (self.R[sr1] + off5) & 0xFFFF
            self.write_byte(addr, self.R[dr] & 0xFF)

        elif opcode == self.OP_LDBH:
            off5 = sign_extend(self.IR & 0x1F, 5)
            addr = (self.R[sr1] + off5) & 0xFFFF
            byte_val = self.read_byte(addr)
            self.R[dr] = (byte_val << 8) | (self.R[dr] & 0x00FF)
            self.V = 0
            self.update_nzp(self.R[dr])

        elif opcode == self.OP_STBH:
            off5 = sign_extend(self.IR & 0x1F, 5)
            addr = (self.R[sr1] + off5) & 0xFFFF
            self.write_byte(addr, (self.R[dr] >> 8) & 0xFF)

        elif opcode == self.OP_LEA:
            off8 = sign_extend(self.IR & 0xFF, 8)
            addr = (self.PC + off8) & 0xFFFF
            self.R[dr] = addr
            self.V = 0
            self.update_nzp(addr)

        # --- SISTEMA OPERATIVO / TRAPS (salto a vector en < 0x3000) ---
        elif opcode == self.OP_TRAP:
            trapvect = self.IR & 0xFF
            handler = self.read_word((trapvect * 2) & 0xFFFF)
            if handler == 0:
                print(f"[DEBUG TRAP] vect=0x{trapvect:02X} | PC_instr=0x{pc_actual:04X} | R6=0x{self.R[6]:04X} | R7=0x{self.R[7]:04X}")
                for a in (0x42BE, 0x42C0, 0x42C2, 0x43F0, 0x43F2, 0x43F4, 0x43F6):
                    print(f"  mem[0x{a:04X}] = 0x{self.read_word(a):04X}")
                raise RuntimeError(f"Vector TRAP no soportado: 0x{trapvect:02X}")
            self.R[7] = self.PC
            self.PC = handler

        else:
            raise RuntimeError(f"Opcode inválido 0b{opcode:05b} en PC=0x{pc_actual:04X}")

    def run(self, max_steps: int = 5_000_000):
        steps = 0
        while not self.halted:
            if steps >= max_steps:
                raise RuntimeError(f"Límite de {max_steps} instrucciones alcanzado (posible bucle infinito).")
            self.step()
            steps += 1

    def dump_state(self):
        print("\n" + "=" * 56)
        print(f"ESTADO FINAL | PC: 0x{self.PC:04X} | Flags: N={self.N} Z={self.Z} P={self.P} V={self.V}")
        print("-" * 56)
        for i in range(0, 8, 2):
            s0, s1 = to_signed16(self.R[i]), to_signed16(self.R[i + 1])
            print(f"R{i}: 0x{self.R[i]:04X} ({s0:6d})   |   R{i+1}: 0x{self.R[i+1]:04X} ({s1:6d})")
        print("-" * 56)
        total = self.user_instructions + self.os_instructions
        print(f"Instrucciones ejecutadas -> Usuario: {self.user_instructions} | SO: {self.os_instructions} | Total: {total}")
        if self.overflow_events:
            print(f"Advertencias de Overflow registradas: {len(self.overflow_events)}")
            for ev in self.overflow_events[:5]:
                print("  ", ev)
        w_429a = self.read_word(0x429A)
        print(f"Palabra en 0x429A: 0x{w_429a:04X} | Palabra en PC (0x{self.PC:04X}): 0x{self.read_word(self.PC):04X}")
        print("=" * 56)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python simulador.py <archivo.obj> [--strict-overflow]")
        sys.exit(1)

    obj_path = sys.argv[1]
    strict = "--strict-overflow" in sys.argv

    sim = SimuladorGrupo21(strict_overflow=strict)
    sim.load_obj(obj_path)
    sim.run()
    sim.dump_state()