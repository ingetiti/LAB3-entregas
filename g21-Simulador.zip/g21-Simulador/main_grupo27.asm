.ORIG x3000
BR main

;   ============================================================================
;       Programa de ENTRADA para pruebas del menu
;       *****************************************
;   ============================================================================

.EXTERNAL G27_MAIN_MENU_PROGRESO-MAIN_MENU
sub_main_menu       .FILL G27_MAIN_MENU_PROGRESO-MAIN_MENU

main
    ; Para modo INTERACTIVO, comenta LEA y descomenta AND R0, R0, #0
    AND R0, R0, #0
    ;LEA R0, programa_del_menu_completo

    LDW R1, sub_main_menu
    JSRR R1
    HALT


;   (i) Bloque de Operaciones para correr AUTOMATICAMENTE en el menu:
programa_del_menu_completo
    .FILL   #1      ; modo verboso: muestra cada operacion, sus operandos y su resultado

    .FILL   #2      ; SENO TAYLOR: seno de 60.0 grados (600 decimas) ~= 0.8660 (Q3.12)
    .FILL   #600    ; 60.0 grados (en decimas de grado)
    .FILL   #0      ; segundo operando no utilizado
    .FILL   #0      ; resultado (Q3.12)
    .FILL   #0      ; espacio sin uso

    .FILL   #18     ; DIVISION CORDIC (indice 18 en main_menu_op_table)
    .FILL   x4000   ; var_a: 0.5 en Q15
    .FILL   x7FFF   ; var_b: ~1.0 en Q15
    .FILL   #0      ; resultado (Q15)
    .FILL   #0      ; espacio sin uso

    .FILL   #14     ; MULTIPLICACION BASIC (indice 14 en main_menu_op_table)
    .FILL   #1280   ; var_a: 5.0 en Q7.8 (5 * 256)
    .FILL   #640    ; var_b: 2.5 en Q7.8 (2.5 * 256)
    .FILL   #0      ; resultado parte alta (Q15.16)
    .FILL   #0      ; resultado parte baja (Q15.16)

    .FILL   #12     ; POTENCIACION EXP BINARIA (indice 12 en main_menu_op_table)
    .FILL   #2      ; base: 2 (int)
    .FILL   #5      ; exponente: 5 (int)
    .FILL   #0      ; resultado (int)
    .FILL   #0      ; espacio sin uso

    .FILL   #11     ; POTENCIACION MULTIPLICACIONES SUCESIVAS (indice 11)
    .FILL   #512    ; base A: 2.0 en Q7.8 (2 * 256)
    .FILL   #3      ; exponente B: 3 (int)
    .FILL   #0      ; resultado (Q7.8)
    .FILL   #0      ; espacio sin uso

    .FILL   #10     ; EXP (indice 10 en main_menu_op_table)
    .FILL   x1000   ; entrada: 1.0 en Q3.12 (4096) -> salida esperada ~2.71875 en Q7.8
    .FILL   #0      ; segundo operando no utilizado
    .FILL   #0      ; resultado (Q7.8)
    .FILL   #0      ; espacio sin uso

    .FILL   #21      ; MCD (reemplazá #8 por el índice exacto de MCD en main_menu_op_table)
    .FILL   #48     ; primer operando (int) = 48
    .FILL   #18     ; segundo operando (int) = 18 -> salida esperada: 6
    .FILL   #0      ; resultado (int)
    .FILL   #0      ; espacio sin uso

    .FILL   #22     ; MCM (indice 22 en main_menu_op_table)
    .FILL   #12     ; primer operando: 12
    .FILL   #18     ; segundo operando: 18 -> salida esperada: 36
    .FILL   #0      ; resultado (int)
    .FILL   #0      ; espacio sin uso

    .FILL   #0      ; SALIR: termina la ejecucion del bloque

.END