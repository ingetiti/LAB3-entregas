import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from assembler import EnsambladorGrupo21, AssemblerError
from simulador import SimuladorGrupo21, to_signed16, sign_extend


TRAP_NAMES = {
    0x20: "GETC",
    0x21: "OUT",
    0x22: "PUTS",
    0x23: "IN",
    0x25: "HALT",
}


def desensamblar_instruccion(word: int, addr: int, symbols_inv: dict) -> str:
    op = (word >> 11) & 0x1F
    dr = (word >> 8) & 0x07
    sr1 = (word >> 5) & 0x07
    mode = (word >> 4) & 0x01
    pc_next = (addr + 2) & 0xFFFF

    def fmt_target(target: int) -> str:
        lbl = symbols_inv.get(target)
        return lbl if lbl else f"x{target:04X}"

    if op == 0:  # BR
        n, z, p = (word >> 10) & 1, (word >> 9) & 1, (word >> 8) & 1
        if n == 0 and z == 0 and p == 0:
            return "NOP"
        cond = ("n" if n else "") + ("z" if z else "") + ("p" if p else "")
        mnem = "BR" if cond == "nzp" else f"BR{cond}"
        target = (pc_next + sign_extend(word & 0x7F, 7)) & 0xFFFF
        return f"{mnem} {fmt_target(target)}"

    alu_ops = {1: "ADD", 2: "SUB", 3: "AND", 5: "MUL", 6: "MULQ"}
    if op in alu_ops:
        mnem = alu_ops[op]
        if mode:
            imm4 = sign_extend(word & 0x0F, 4)
            return f"{mnem} R{dr}, R{sr1}, #{imm4}"
        return f"{mnem} R{dr}, R{sr1}, R{word & 0x07}"

    if op == 4:
        return f"NOT R{dr}, R{sr1}"

    shift_ops = {7: "LSL", 8: "LSR", 9: "ASR"}
    if op in shift_ops:
        return f"{shift_ops[op]} R{dr}, R{sr1}, #{word & 0x0F}"

    pc_rel_ops = {10: "LDW", 11: "STW", 14: "LDIW", 15: "STIW", 20: "LEA"}
    if op in pc_rel_ops:
        target = (pc_next + sign_extend(word & 0xFF, 8)) & 0xFFFF
        return f"{pc_rel_ops[op]} R{dr}, {fmt_target(target)}"

    base_ops = {12: "LDRW", 13: "STRW", 16: "LDBL", 17: "STBL", 18: "LDBH", 19: "STBH"}
    if op in base_ops:
        off5 = sign_extend(word & 0x1F, 5)
        return f"{base_ops[op]} R{dr}, R{sr1}, #{off5}"

    if op == 21:
        return "RET" if sr1 == 7 else f"JMP R{sr1}"

    if op == 22:
        target = (pc_next + sign_extend(word & 0x7FF, 11)) & 0xFFFF
        return f"JSR {fmt_target(target)}"

    if op == 23:
        return f"JSRR R{sr1}"

    if op == 31:
        vect = word & 0xFF
        return TRAP_NAMES.get(vect, f"TRAP x{vect:02X}")

    return f".FILL x{word:04X}"


class SimuladorIDE(tk.Tk):
    BG_MAIN = "#fdf6f8"
    BG_PANEL = "#fffafc"
    BG_HEADER = "#f7e6ed"
    BG_INPUT = "#ffffff"
    BG_CONSOLE = "#2b1e29"
    FG_CONSOLE = "#fceef3"
    FG_TEXT = "#3b2636"
    FG_MUTED = "#7c5e74"
    ACCENT = "#d45d8a"
    ACCENT_HOVER = "#bf4774"
    ACCENT_SOFT = "#fce4ec"
    ACCENT_MINT = "#5c9e8b"
    BORDER = "#ebd2de"
    PC_HIGHLIGHT = "#ffe0ec"

    def __init__(self):
        super().__init__()
        self.title("Calculadora & Simulador ISA G21")
        self.geometry("1280x720")
        self.minsize(1020, 620)
        self.configure(bg=self.BG_MAIN)

        self.sim = SimuladorGrupo21()
        self.sim.on_output = self.escribir_consola

        self.base_dir = os.getcwd()
        self.main_asm_path = None
        self.editing_file_path = None
        self.current_obj_path = None
        self.symbols = {}
        self.symbols_inv = {}

        self.running = False
        self.seguir_pc = True
        self.mem_view_base = 0x3000
        self.reg_format = tk.StringVar(value="Q3.12")
        self.speed_var = tk.StringVar(value="máx.")

        self._configurar_estilos()
        self._construir_toolbar()
        self._construir_cuerpo()
        self._construir_statusbar()

        default_main = os.path.join(self.base_dir, "main_grupo27.asm")
        if os.path.isfile(default_main):
            self.main_asm_path = default_main
            self._cargar_archivo_en_editor(default_main)
        self._refrescar_arbol_archivos()
        self.actualizar_vista()

    def _configurar_estilos(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TNotebook", background=self.BG_MAIN, borderwidth=0)
        style.configure(
            "TNotebook.Tab",
            background=self.BG_HEADER,
            foreground=self.FG_MUTED,
            padding=[12, 5],
            borderwidth=0,
            font=("Segoe UI", 9),
        )
        style.map(
            "TNotebook.Tab",
            background=[("selected", self.BG_PANEL)],
            foreground=[("selected", self.ACCENT)],
        )
        style.configure(
            "Treeview",
            background=self.BG_PANEL,
            foreground=self.FG_TEXT,
            fieldbackground=self.BG_PANEL,
            borderwidth=0,
            rowheight=22,
            font=("Consolas", 9),
        )
        style.map(
            "Treeview",
            background=[("selected", self.ACCENT_SOFT)],
            foreground=[("selected", self.ACCENT)],
        )
        style.configure(
            "TCombobox",
            fieldbackground=self.BG_INPUT,
            background=self.BG_HEADER,
            foreground=self.FG_TEXT,
        )

    def _construir_toolbar(self):
        bar = tk.Frame(self, bg=self.BG_HEADER, padx=10, pady=6, highlightbackground=self.BORDER, highlightthickness=1)
        bar.pack(fill=tk.X)

        tk.Label(
            bar,
            text="✦ ISA G21",
            bg=self.ACCENT,
            fg="#ffffff",
            font=("Segoe UI", 9, "bold"),
            padx=10,
            pady=3,
        ).pack(side=tk.LEFT, padx=(0, 10))

        btn_soft = {
            "bg": self.BG_INPUT,
            "fg": self.FG_TEXT,
            "activebackground": self.ACCENT_SOFT,
            "activeforeground": self.ACCENT,
            "relief": tk.FLAT,
            "padx": 10,
            "pady": 4,
            "font": ("Segoe UI", 9),
            "cursor": "hand2",
        }

        tk.Button(bar, text="Abrir .ASM", command=self.abrir_asm, **btn_soft).pack(side=tk.LEFT, padx=2)
        tk.Button(bar, text="Guardar", command=self.guardar_editor, **btn_soft).pack(side=tk.LEFT, padx=2)

        tk.Frame(bar, width=1, bg=self.BORDER).pack(side=tk.LEFT, fill=tk.Y, padx=8, pady=2)

        tk.Button(
            bar,
            text="Ensamblar",
            command=self.ensamblar,
            bg=self.ACCENT_MINT,
            fg="#ffffff",
            activebackground="#4a8776",
            activeforeground="#ffffff",
            relief=tk.FLAT,
            padx=12,
            pady=4,
            font=("Segoe UI", 9, "bold"),
            cursor="hand2",
        ).pack(side=tk.LEFT, padx=2)

        tk.Button(
            bar,
            text="▶ Continuar",
            command=self.iniciar_run,
            bg=self.ACCENT,
            fg="#ffffff",
            activebackground=self.ACCENT_HOVER,
            activeforeground="#ffffff",
            relief=tk.FLAT,
            padx=12,
            pady=4,
            font=("Segoe UI", 9, "bold"),
            cursor="hand2",
        ).pack(side=tk.LEFT, padx=2)

        tk.Button(bar, text="⏸ Pausa", command=self.pausar, **btn_soft).pack(side=tk.LEFT, padx=2)
        tk.Button(bar, text="↷ Paso", command=self.paso_sobre, **btn_soft).pack(side=tk.LEFT, padx=2)
        tk.Button(bar, text="↓ Entrar", command=self.paso_entrar, **btn_soft).pack(side=tk.LEFT, padx=2)
        tk.Button(bar, text="↑ Salir", command=self.paso_salir, **btn_soft).pack(side=tk.LEFT, padx=2)
        tk.Button(bar, text="↻ Reiniciar", command=self.reiniciar, **btn_soft).pack(side=tk.LEFT, padx=2)

        tk.Label(bar, text="Velocidad:", bg=self.BG_HEADER, fg=self.FG_MUTED, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(10, 4))
        vel_combo = ttk.Combobox(bar, textvariable=self.speed_var, values=["máx.", "media", "lenta"], width=7, state="readonly")
        vel_combo.pack(side=tk.LEFT)

        self.lbl_main_target = tk.Label(bar, text="", bg=self.BG_HEADER, fg=self.FG_MUTED, font=("Consolas", 9))
        self.lbl_main_target.pack(side=tk.RIGHT, padx=6)

    def _construir_cuerpo(self):
        paned_h = tk.PanedWindow(self, orient=tk.HORIZONTAL, bg=self.BORDER, sashwidth=3, sashrelief=tk.FLAT)
        paned_h.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        col_files = tk.Frame(paned_h, bg=self.BG_PANEL, width=215, highlightbackground=self.BORDER, highlightthickness=1)
        paned_h.add(col_files, minsize=165)

        hdr_files = tk.Frame(col_files, bg=self.BG_HEADER, padx=10, pady=6)
        hdr_files.pack(fill=tk.X)
        tk.Label(hdr_files, text="Archivos", bg=self.BG_HEADER, fg=self.FG_TEXT, font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT)
        tk.Button(
            hdr_files,
            text="↻",
            command=self._refrescar_arbol_archivos,
            bg=self.BG_HEADER,
            fg=self.ACCENT,
            relief=tk.FLAT,
            bd=0,
            cursor="hand2",
        ).pack(side=tk.RIGHT)

        self.tree_files = ttk.Treeview(col_files, show="tree")
        self.tree_files.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.tree_files.bind("<<TreeviewSelect>>", self._on_select_file)

        paned_center = tk.PanedWindow(paned_h, orient=tk.VERTICAL, bg=self.BORDER, sashwidth=3)
        paned_h.add(paned_center, minsize=430)

        editor_wrap = tk.Frame(paned_center, bg=self.BG_PANEL, highlightbackground=self.BORDER, highlightthickness=1)
        paned_center.add(editor_wrap, minsize=230)

        tab_bar = tk.Frame(editor_wrap, bg=self.BG_HEADER)
        tab_bar.pack(fill=tk.X)
        self.lbl_editor_tab = tk.Label(
            tab_bar,
            text="  sin_archivo.asm  ",
            bg=self.BG_PANEL,
            fg=self.ACCENT,
            font=("Consolas", 9, "bold"),
            padx=8,
            pady=4,
        )
        self.lbl_editor_tab.pack(side=tk.LEFT)

        ed_body = tk.Frame(editor_wrap, bg=self.BG_PANEL)
        ed_body.pack(fill=tk.BOTH, expand=True)

        self.line_numbers = tk.Text(
            ed_body,
            width=4,
            bg="#f9eef3",
            fg="#a88b9f",
            font=("Consolas", 10),
            state=tk.DISABLED,
            relief=tk.FLAT,
            padx=4,
            pady=6,
        )
        self.line_numbers.pack(side=tk.LEFT, fill=tk.Y)

        self.editor = tk.Text(
            ed_body,
            bg=self.BG_PANEL,
            fg=self.FG_TEXT,
            insertbackground=self.ACCENT,
            selectbackground=self.ACCENT_SOFT,
            font=("Consolas", 10),
            relief=tk.FLAT,
            undo=True,
            wrap=tk.NONE,
            padx=8,
            pady=6,
        )
        self.editor.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        ed_scroll_y = tk.Scrollbar(ed_body, command=self._on_editor_scroll)
        ed_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        self.editor.config(yscrollcommand=ed_scroll_y.set)
        self.editor.bind("<KeyRelease>", self._actualizar_numeros_linea)
        self.editor.bind("<Control-s>", lambda e: self.guardar_editor())

        self.editor.tag_configure("comment", foreground="#8b9e8e")
        self.editor.tag_configure("directive", foreground="#b84a78")

        bottom_tabs = ttk.Notebook(paned_center)
        paned_center.add(bottom_tabs, minsize=175)

        tab_console = tk.Frame(bottom_tabs, bg=self.BG_CONSOLE)
        bottom_tabs.add(tab_console, text="Consola")

        self.console_text = tk.Text(
            tab_console,
            bg=self.BG_CONSOLE,
            fg=self.FG_CONSOLE,
            insertbackground="#ff9ec4",
            font=("Consolas", 10),
            relief=tk.FLAT,
            padx=8,
            pady=6,
        )
        self.console_text.pack(fill=tk.BOTH, expand=True)

        in_row = tk.Frame(tab_console, bg="#3a2837", padx=6, pady=4)
        in_row.pack(fill=tk.X)
        tk.Label(in_row, text="Entrada >", bg="#3a2837", fg="#ffb3d1", font=("Consolas", 9, "bold")).pack(side=tk.LEFT, padx=(0, 6))
        self.entry_in = tk.Entry(
            in_row,
            bg="#4a3446",
            fg="#ffffff",
            insertbackground="#ffffff",
            font=("Consolas", 10),
            relief=tk.FLAT,
        )
        self.entry_in.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, ipady=2)
        self.entry_in.bind("<Return>", self.enviar_entrada)
        tk.Button(
            in_row,
            text="Enviar",
            command=self.enviar_entrada,
            bg=self.ACCENT,
            fg="#ffffff",
            relief=tk.FLAT,
            padx=12,
            pady=2,
            font=("Segoe UI", 9, "bold"),
            cursor="hand2",
        ).pack(side=tk.RIGHT, padx=4)

        tab_probs = tk.Frame(bottom_tabs, bg=self.BG_PANEL)
        bottom_tabs.add(tab_probs, text="Problemas")
        self.problems_text = tk.Text(tab_probs, bg=self.BG_PANEL, fg="#b83b5e", font=("Consolas", 9), relief=tk.FLAT, padx=8, pady=6)
        self.problems_text.pack(fill=tk.BOTH, expand=True)

        tab_symbols = tk.Frame(bottom_tabs, bg=self.BG_PANEL)
        bottom_tabs.add(tab_symbols, text="Mapa de enlace")
        self.symbols_text = tk.Text(tab_symbols, bg=self.BG_PANEL, fg=self.FG_TEXT, font=("Consolas", 9), relief=tk.FLAT, padx=8, pady=6)
        self.symbols_text.pack(fill=tk.BOTH, expand=True)

        self.bottom_tabs = bottom_tabs

        paned_right = tk.PanedWindow(paned_h, orient=tk.VERTICAL, bg=self.BORDER, sashwidth=3)
        paned_h.add(paned_right, minsize=390)

        reg_panel = tk.Frame(paned_right, bg=self.BG_PANEL, padx=10, pady=8, highlightbackground=self.BORDER, highlightthickness=1)
        paned_right.add(reg_panel, minsize=275)

        reg_hdr = tk.Frame(reg_panel, bg=self.BG_PANEL)
        reg_hdr.pack(fill=tk.X, pady=(0, 6))
        tk.Label(reg_hdr, text="Registros", bg=self.BG_PANEL, fg=self.FG_TEXT, font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT)
        tk.Label(reg_hdr, text="(doble clic para editar)", bg=self.BG_PANEL, fg=self.FG_MUTED, font=("Segoe UI", 8)).pack(side=tk.LEFT, padx=6)

        fmt_combo = ttk.Combobox(reg_hdr, textvariable=self.reg_format, values=["Dec", "Q3.12", "Q7.8"], width=7, state="readonly")
        fmt_combo.pack(side=tk.RIGHT)
        fmt_combo.bind("<<ComboboxSelected>>", lambda e: self.actualizar_vista())

        self.reg_widgets = []
        for i in range(8):
            row = tk.Frame(reg_panel, bg=self.BG_PANEL)
            row.pack(fill=tk.X, pady=2)

            lbl_name = tk.Label(row, text=f"R{i}", width=4, anchor="w", bg=self.BG_PANEL, fg=self.ACCENT, font=("Consolas", 9, "bold"))
            lbl_name.pack(side=tk.LEFT)

            lbl_hex = tk.Label(
                row,
                text="x0000",
                width=8,
                bg=self.BG_HEADER,
                fg=self.FG_TEXT,
                font=("Consolas", 9, "bold"),
                padx=4,
                pady=1,
            )
            lbl_hex.pack(side=tk.LEFT, padx=6)

            lbl_val = tk.Label(row, text="0.000000", anchor="e", bg=self.BG_PANEL, fg=self.FG_MUTED, font=("Consolas", 9))
            lbl_val.pack(side=tk.RIGHT)

            for w in (lbl_name, lbl_hex, lbl_val):
                w.bind("<Double-Button-1>", lambda e, idx=i: self._editar_registro(idx))

            self.reg_widgets.append((lbl_hex, lbl_val))

        tk.Frame(reg_panel, height=1, bg=self.BORDER).pack(fill=tk.X, pady=6)

        self.special_widgets = {}
        for key in ("PC", "IR", "Flags", "MCR"):
            row = tk.Frame(reg_panel, bg=self.BG_PANEL)
            row.pack(fill=tk.X, pady=2)
            tk.Label(row, text=key, width=6, anchor="w", bg=self.BG_PANEL, fg=self.ACCENT_MINT, font=("Consolas", 9, "bold")).pack(side=tk.LEFT)
            lbl_hex = tk.Label(row, text="x0000", width=16, bg=self.ACCENT_SOFT, fg=self.FG_TEXT, font=("Consolas", 9, "bold"), padx=4, pady=1)
            lbl_hex.pack(side=tk.LEFT, padx=6)
            lbl_info = tk.Label(row, text="", anchor="e", bg=self.BG_PANEL, fg=self.FG_MUTED, font=("Consolas", 8))
            lbl_info.pack(side=tk.RIGHT)
            self.special_widgets[key] = (lbl_hex, lbl_info)

        mem_panel = tk.Frame(paned_right, bg=self.BG_PANEL, padx=10, pady=8, highlightbackground=self.BORDER, highlightthickness=1)
        paned_right.add(mem_panel, minsize=240)

        mem_hdr = tk.Frame(mem_panel, bg=self.BG_PANEL)
        mem_hdr.pack(fill=tk.X, pady=(0, 6))
        tk.Label(mem_hdr, text="Memoria", bg=self.BG_PANEL, fg=self.FG_TEXT, font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT)

        self.entry_addr = tk.Entry(mem_hdr, width=14, bg=self.BG_INPUT, fg=self.FG_TEXT, font=("Consolas", 9), relief=tk.FLAT, highlightbackground=self.BORDER, highlightthickness=1)
        self.entry_addr.insert(0, "x3000")
        self.entry_addr.pack(side=tk.LEFT, padx=8, ipady=1)
        self.entry_addr.bind("<Return>", self._ir_a_direccion)

        self.btn_follow = tk.Button(
            mem_hdr,
            text="Seguir PC: ON",
            command=self._toggle_seguir_pc,
            bg=self.ACCENT_SOFT,
            fg=self.ACCENT,
            relief=tk.FLAT,
            font=("Segoe UI", 8, "bold"),
            padx=8,
            pady=2,
            cursor="hand2",
        )
        self.btn_follow.pack(side=tk.RIGHT)

        tk.Label(
            mem_panel,
            text="  Dir.   Etiqueta         Hex     Dec    Instrucción           Car.",
            bg=self.BG_HEADER,
            fg=self.FG_MUTED,
            font=("Consolas", 8, "bold"),
            anchor="w",
            pady=2,
        ).pack(fill=tk.X)

        self.mem_text = tk.Text(mem_panel, bg=self.BG_PANEL, fg=self.FG_TEXT, font=("Consolas", 9), relief=tk.FLAT, padx=2, pady=2)
        self.mem_text.pack(fill=tk.BOTH, expand=True)
        self.mem_text.tag_configure("pc_row", background=self.PC_HIGHLIGHT, foreground=self.ACCENT)
        self.mem_text.bind("<MouseWheel>", self._on_mem_wheel)

    def _construir_statusbar(self):
        sb = tk.Frame(self, bg=self.BG_HEADER, padx=10, pady=4, highlightbackground=self.BORDER, highlightthickness=1)
        sb.pack(fill=tk.X)

        self.lbl_mode = tk.Label(sb, text="ISA Grupo 21 · modo usuario", bg=self.BG_HEADER, fg=self.FG_MUTED, font=("Segoe UI", 8))
        self.lbl_mode.pack(side=tk.LEFT)

        self.lbl_instr_count = tk.Label(
            sb,
            text="0 instrucciones (0 usuario + 0 SO)",
            bg=self.BG_HEADER,
            fg=self.ACCENT,
            font=("Consolas", 9, "bold"),
        )
        self.lbl_instr_count.pack(side=tk.RIGHT)

    def _refrescar_arbol_archivos(self):
        self.tree_files.delete(*self.tree_files.get_children())
        root_node = self.tree_files.insert("", tk.END, text=f"📁 {os.path.basename(self.base_dir)}", open=True)

        for fn in sorted(os.listdir(self.base_dir)):
            if fn.lower().endswith(".asm"):
                self.tree_files.insert(root_node, tk.END, text=f"📄 {fn}", values=(os.path.join(self.base_dir, fn),))

        lib_dir = os.path.join(self.base_dir, "lib")
        if os.path.isdir(lib_dir):
            lib_node = self.tree_files.insert(root_node, tk.END, text="📁 lib", open=True)
            for fn in sorted(os.listdir(lib_dir)):
                if fn.lower().endswith(".asm"):
                    self.tree_files.insert(lib_node, tk.END, text=f"📄 {fn}", values=(os.path.join(lib_dir, fn),))

    def _on_select_file(self, event):
        sel = self.tree_files.selection()
        if not sel:
            return
        vals = self.tree_files.item(sel[0], "values")
        if vals and os.path.isfile(vals[0]):
            self._cargar_archivo_en_editor(vals[0])

    def _cargar_archivo_en_editor(self, filepath: str):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                contenido = f.read()
        except Exception as e:
            messagebox.showerror("Error al abrir archivo", str(e))
            return

        self.editing_file_path = filepath
        rel = os.path.relpath(filepath, self.base_dir)
        self.lbl_editor_tab.config(text=f"  {rel}  ")
        self.editor.delete("1.0", tk.END)
        self.editor.insert("1.0", contenido)
        self._actualizar_numeros_linea()

    def abrir_asm(self):
        ruta = filedialog.askopenfilename(title="Seleccionar archivo .asm", filetypes=[("Ensamblador", "*.asm"), ("Todos", "*.*")])
        if not ruta:
            return
        self.base_dir = os.path.dirname(os.path.abspath(ruta))
        self.main_asm_path = os.path.abspath(ruta)
        self.lbl_main_target.config(text=f"Principal: {os.path.basename(ruta)}")
        self._cargar_archivo_en_editor(self.main_asm_path)
        self._refrescar_arbol_archivos()

    def guardar_editor(self):
        if not self.editing_file_path:
            return
        contenido = self.editor.get("1.0", "end-1c")
        with open(self.editing_file_path, "w", encoding="utf-8") as f:
            f.write(contenido)
        self._resaltar_sintaxis()

    def _on_editor_scroll(self, *args):
        self.editor.yview(*args)
        self.line_numbers.yview(*args)

    def _actualizar_numeros_linea(self, event=None):
        lines = int(self.editor.index("end-1c").split(".")[0])
        nums = "\n".join(str(i) for i in range(1, lines + 1))
        self.line_numbers.config(state=tk.NORMAL)
        self.line_numbers.delete("1.0", tk.END)
        self.line_numbers.insert("1.0", nums)
        self.line_numbers.config(state=tk.DISABLED)
        self.line_numbers.yview_moveto(self.editor.yview()[0])
        self._resaltar_sintaxis()

    def _resaltar_sintaxis(self):
        for tag in ("comment", "directive"):
            self.editor.tag_remove(tag, "1.0", tk.END)
        lines = int(self.editor.index("end-1c").split(".")[0])
        for i in range(1, lines + 1):
            line_txt = self.editor.get(f"{i}.0", f"{i}.end")
            semi = line_txt.find(";")
            if semi != -1:
                self.editor.tag_add("comment", f"{i}.{semi}", f"{i}.end")
            code_part = line_txt[:semi] if semi != -1 else line_txt
            for kw in (".ORIG", ".END", ".FILL", ".BLKW", ".STRINGZ", ".EXTERNAL"):
                idx = code_part.upper().find(kw)
                if idx != -1:
                    self.editor.tag_add("directive", f"{i}.{idx}", f"{i}.{idx + len(kw)}")

    def ensamblar(self):
        self.guardar_editor()
        target_asm = self.main_asm_path or self.editing_file_path
        if not target_asm:
            self.abrir_asm()
            target_asm = self.main_asm_path
            if not target_asm:
                return

        self.problems_text.delete("1.0", tk.END)
        asm = EnsambladorGrupo21()
        try:
            obj_path, size_bytes = asm.assemble(target_asm, fmt="obj")
        except AssemblerError as err:
            self.problems_text.insert(tk.END, f"• {err}\n")
            self.bottom_tabs.select(1)
            return
        except Exception as err:
            self.problems_text.insert(tk.END, f"• Error inesperado: {err}\n")
            self.bottom_tabs.select(1)
            return

        self.current_obj_path = obj_path
        self.symbols = dict(asm.symbols)
        self.symbols_inv = {addr: sym for sym, addr in asm.symbols.items()}
        self.lbl_main_target.config(text=f"{os.path.basename(target_asm)} · {size_bytes} B · {len(self.symbols)} símbolos")

        self.symbols_text.delete("1.0", tk.END)
        for sym, addr in sorted(self.symbols.items(), key=lambda x: x[1]):
            self.symbols_text.insert(tk.END, f"x{addr:04X}   {sym}\n")

        self.reiniciar()
        self.bottom_tabs.select(0)
        self.escribir_consola(f"[Ensamblado OK: {os.path.basename(obj_path)}]\n")

    def reiniciar(self):
        self.running = False
        self.sim.reset()
        self.sim.on_output = self.escribir_consola
        self.console_text.delete("1.0", tk.END)
        if self.current_obj_path and os.path.isfile(self.current_obj_path):
            self.sim.load_obj(self.current_obj_path)
        self.mem_view_base = self.sim.PC
        self.actualizar_vista()

    def paso_entrar(self):
        if self.sim.halted:
            return
        try:
            self.sim.step()
        except Exception as e:
            self.running = False
            messagebox.showerror("Error en simulación", str(e))
        self.actualizar_vista()

    def paso_sobre(self):
        if self.sim.halted:
            return
        word = self.sim.mem[self.sim.PC] | (self.sim.mem[(self.sim.PC + 1) & 0xFFFF] << 8)
        op = (word >> 11) & 0x1F
        if op in (self.sim.OP_JSR, self.sim.OP_JSRR, self.sim.OP_TRAP):
            ret_pc = (self.sim.PC + 2) & 0xFFFF
            try:
                guard = 0
                while not self.sim.halted and self.sim.PC != ret_pc and guard < 200_000:
                    if self.sim.PC == 0x0400 and not self.sim.input_buffer and not self.sim._kb_ready:
                        break
                    self.sim.step()
                    guard += 1
            except Exception as e:
                messagebox.showerror("Error en simulación", str(e))
            self.actualizar_vista()
        else:
            self.paso_entrar()

    def paso_salir(self):
        if self.sim.halted:
            return
        target_ret = self.sim.R[7] & 0xFFFF
        try:
            guard = 0
            while not self.sim.halted and self.sim.PC != target_ret and guard < 200_000:
                if self.sim.PC == 0x0400 and not self.sim.input_buffer and not self.sim._kb_ready:
                    break
                self.sim.step()
                guard += 1
        except Exception as e:
            messagebox.showerror("Error en simulación", str(e))
        self.actualizar_vista()

    def iniciar_run(self):
        if self.sim.halted or self.running:
            return
        self.running = True
        self._ciclo_run()

    def pausar(self):
        self.running = False

    def _ciclo_run(self):
        if not self.running or self.sim.halted:
            self.running = False
            self.actualizar_vista()
            return

        vel = self.speed_var.get()
        batch = 400 if vel == "máx." else (25 if vel == "media" else 1)
        delay = 8 if vel == "máx." else (30 if vel == "media" else 140)

        try:
            for _ in range(batch):
                if self.sim.halted:
                    break
                if self.sim.PC == 0x0400 and not self.sim.input_buffer and not self.sim._kb_ready:
                    break
                self.sim.step()
        except Exception as e:
            self.running = False
            messagebox.showerror("Error en simulación", str(e))

        if self.sim.halted:
            self.running = False
            total = self.sim.user_instructions + self.sim.os_instructions
            self.escribir_consola(
                f"\n[Fin · {total} instr.: {self.sim.user_instructions} usuario + {self.sim.os_instructions} SO]\n"
            )

        self.actualizar_vista()
        if self.running and not self.sim.halted:
            self.after(delay, self._ciclo_run)

    def escribir_consola(self, texto: str):
        self.console_text.insert(tk.END, texto)
        self.console_text.see(tk.END)

    def enviar_entrada(self, event=None):
        dato = self.entry_in.get()
        self.entry_in.delete(0, tk.END)
        self.sim.input_buffer += dato + "\n"
        self.escribir_consola(
            f"[Enviado '{dato}' | PC=x{self.sim.PC:04X} | buf={repr(self.sim.input_buffer)}]\n"
        )

    def _editar_registro(self, idx: int):
        val_str = simpledialog.askstring("Editar registro", f"Nuevo valor para R{idx} (ej: 600, x0258, 0.5):", parent=self)
        if not val_str:
            return
        s = val_str.strip()
        try:
            if s.lower().startswith("x"):
                val = int(s[1:], 16)
            elif "." in s:
                fval = float(s)
                shift = 12 if self.reg_format.get() == "Q3.12" else 8
                val = int(round(fval * (1 << shift)))
            else:
                val = int(s, 10)
            self.sim.R[idx] = val & 0xFFFF
            self.actualizar_vista()
        except ValueError:
            messagebox.showerror("Valor inválido", "Formato no reconocido.")

    def _toggle_seguir_pc(self):
        self.seguir_pc = not self.seguir_pc
        if self.seguir_pc:
            self.btn_follow.config(bg=self.ACCENT_SOFT, fg=self.ACCENT, text="Seguir PC: ON")
        else:
            self.btn_follow.config(bg=self.BG_HEADER, fg=self.FG_MUTED, text="Seguir PC: OFF")
        self.actualizar_vista()

    def _ir_a_direccion(self, event=None):
        q = self.entry_addr.get().strip()
        if q in self.symbols:
            self.mem_view_base = self.symbols[q] & ~1
        else:
            try:
                addr = int(q[1:], 16) if q.lower().startswith("x") else int(q, 16 if q.lower().startswith("0x") else 10)
                self.mem_view_base = addr & 0xFFFE
            except ValueError:
                return
        self.seguir_pc = False
        self.btn_follow.config(bg=self.BG_HEADER, fg=self.FG_MUTED, text="Seguir PC: OFF")
        self.actualizar_vista()

    def _on_mem_wheel(self, event):
        self.seguir_pc = False
        self.btn_follow.config(bg=self.BG_HEADER, fg=self.FG_MUTED, text="Seguir PC: OFF")
        delta = -4 if event.delta > 0 else 4
        self.mem_view_base = (self.mem_view_base + delta) & 0xFFFE
        self.actualizar_vista()

    def _formatear_valor_reg(self, val16: int) -> str:
        sval = to_signed16(val16)
        fmt = self.reg_format.get()
        if fmt == "Q3.12":
            return f"{sval / 4096.0:.6f}"
        if fmt == "Q7.8":
            return f"{sval / 256.0:.4f}"
        return f"{sval}"

    def actualizar_vista(self):
        for i in range(8):
            val = self.sim.R[i] & 0xFFFF
            lbl_hex, lbl_val = self.reg_widgets[i]
            lbl_hex.config(text=f"x{val:04X}")
            lbl_val.config(text=self._formatear_valor_reg(val))

        mcr = self.sim.mem[self.sim.ADDR_MCR] | (self.sim.mem[self.sim.ADDR_MCR + 1] << 8)
        flags_str = f"N={self.sim.N} Z={self.sim.Z} P={self.sim.P} V={self.sim.V}"
        mnem_ir = desensamblar_instruccion(self.sim.IR, (self.sim.PC - 2) & 0xFFFF, self.symbols_inv).split()[0]

        specials = {
            "PC": (f"x{self.sim.PC:04X}", self.symbols_inv.get(self.sim.PC, "")),
            "IR": (f"x{self.sim.IR:04X}", mnem_ir),
            "Flags": (flags_str, "usuario" if self.sim.PC >= 0x3000 else "SO"),
            "MCR": (f"x{mcr:04X}", "activo" if (mcr & 0x8000) else "detenido"),
        }
        for key, (badge_txt, info_txt) in specials.items():
            lbl_hex, lbl_info = self.special_widgets[key]
            lbl_hex.config(text=badge_txt)
            lbl_info.config(text=info_txt)

        if self.seguir_pc:
            self.mem_view_base = max(0, (self.sim.PC - 8) & ~1)

        self.mem_text.delete("1.0", tk.END)
        for offset in range(0, 44, 2):
            addr = (self.mem_view_base + offset) & 0xFFFF
            word = self.sim.mem[addr] | (self.sim.mem[(addr + 1) & 0xFFFF] << 8)
            sval = to_signed16(word)
            lbl = self.symbols_inv.get(addr, "")
            lbl_col = f"{lbl[:15]:<15}" if lbl else " " * 15
            asm_col = f"{desensamblar_instruccion(word, addr, self.symbols_inv)[:21]:<21}"
            c_lo = chr(word & 0xFF) if 32 <= (word & 0xFF) <= 126 else "."
            c_hi = chr((word >> 8) & 0xFF) if 32 <= ((word >> 8) & 0xFF) <= 126 else "."
            marca = "▶" if addr == self.sim.PC else " "

            linea = f"{marca} x{addr:04X}  {lbl_col}  x{word:04X}  {sval:6d}  {asm_col} {c_lo}{c_hi}\n"
            self.mem_text.insert(tk.END, linea, ("pc_row",) if addr == self.sim.PC else ())

        modo = "modo usuario" if self.sim.PC >= 0x3000 else "modo SO"
        self.lbl_mode.config(text=f"ISA Grupo 21 · {modo}")
        total = self.sim.user_instructions + self.sim.os_instructions
        self.lbl_instr_count.config(text=f"{total} instrucciones ({self.sim.user_instructions} usuario + {self.sim.os_instructions} SO)")


if __name__ == "__main__":
    app = SimuladorIDE()
    app.mainloop()