;   ============================================================================
;   Subrutina: CIRCLSH (Migrada a ISA Grupo 21)
;       Desplazamiento circular a la izquierda de 32 bits sobre (R0, R1).
;
;   -> INPUT  [R0] Palabra alta (bits 31..16)
;   -> INPUT  [R1] Palabra baja (bits 15..0)
;   -> INPUT  [R2] Cantidad de bits a rotar
;   <- OUTPUT [R0] Palabra alta rotada
;   <- OUTPUT [R1] Palabra baja rotada
;   ============================================================================

CIRCLSH
    STW R2, circlsh_r2
    STW R3, circlsh_r3
    STW R4, circlsh_r4

    ADD R2, R2, #0
    BRnz circlsh_ret

circlsh_loop
    AND R3, R3, #0                      ; bit saliente de R0 (MSB)
    ADD R0, R0, #0
    BRzp circlsh_chk_r1
    ADD R3, R3, #1

circlsh_chk_r1
    AND R4, R4, #0                      ; bit saliente de R1 (MSB)
    ADD R1, R1, #0
    BRzp circlsh_shift
    ADD R4, R4, #1

circlsh_shift
    ADD R0, R0, R0                      ; R0 <<= 1
    ADD R0, R0, R4                      ; entra MSB de R1 en LSB de R0
    ADD R1, R1, R1                      ; R1 <<= 1
    ADD R1, R1, R3                      ; entra MSB de R0 en LSB de R1

    ADD R2, R2, #-1
    BRp circlsh_loop

circlsh_ret
    LDW R2, circlsh_r2
    LDW R3, circlsh_r3
    LDW R4, circlsh_r4
    RET

circlsh_r2      .FILL #0
circlsh_r3      .FILL #0
circlsh_r4      .FILL #0

.END