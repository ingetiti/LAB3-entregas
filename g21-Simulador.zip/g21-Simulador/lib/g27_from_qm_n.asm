.EXTERNAL CIRCLSH-CIRCLSH
sub_circlsh     .FILL CIRCLSH-CIRCLSH


;   ============================================================================
;   Subrutina: FROM_QM_N (Migrada a ISA Grupo 21)
;       Convierte entre distintos formatos Q (De Qm.n a Q15.16).
;   
;   -> INPUT  [R0] Qm.n .
;   -> INPUT  [R1] n .
;   <- OUTPUT [R0] Parte entera del Q15.16 . 
;   <- OUTPUT [R1] Parte fraccionaria del Q15.16 .
;   ============================================================================

FROM_QM_N

    STW R2, from_qm_n_r2
    STW R3, from_qm_n_r3
    STW R7, from_qm_n_r7
    
    ; [R0] qm.n
    ; [R1] n

    ADD R2, R1, #0                      ;   [R2] n
    ADD R2, R2, #-8                     ;
    ADD R2, R2, #-8                     ;   [R2] n - 16
    NOT R2, R2
    ADD R2, R2, #1                      ;   [R2] 16 - n
    ADD R1, R0, #0                      ;   [R1] qm.n

    AND R0, R0, #0                        
    ADD R1, R1, #0
    BRzp from_qm_n_sk1
    NOT R0, R0                          ;   ext

from_qm_n_sk1
    LDW R3, sub_circlsh
    JSRR R3
    
    STW R0, from_qm_n_entero
    STW R1, from_qm_n_fraccion

    AND R0, R0, #0
    NOT R1, R0
    LDW R3, sub_circlsh
    JSRR R3                             ; [R1] mascara

    LDW R0, from_qm_n_entero
    LDW R2, from_qm_n_fraccion
    AND R1, R1, R2

    LDW R2, from_qm_n_r2
    LDW R3, from_qm_n_r3
    LDW R7, from_qm_n_r7
    RET

from_qm_n_r2        .FILL #0
from_qm_n_r3        .FILL #0
from_qm_n_r7        .FILL #0
from_qm_n_entero    .FILL #0
from_qm_n_fraccion  .FILL #0

.END