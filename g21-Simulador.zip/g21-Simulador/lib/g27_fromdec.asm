.EXTERNAL SUMOVER-SUMOVER
sub_sumover     .FILL SUMOVER-SUMOVER


;   ============================================================================
;   Subrutina: FROMDEC (Migrada a ISA Grupo 21 - Direccionable por Byte)
;       Convierte una cadena de texto decimal al valor correspondiente.
;
;   -> INPUT  [R0] Puntero de la cadena.
;   <- OUTPUT [R0] Parte entera obtenida.
;   <- OUTPUT [R1] Parte fraccionaria obtenida.
;   <- OUTPUT [R5] Error flag bits [15:2 none, 1 OVERFLOW, 0 INVALID_INPUT].
;   ============================================================================

FROMDEC                                 ;
    STW R2, fromdec_r2                  ;
    STW R3, fromdec_r3                  ;
    STW R4, fromdec_r4                  ;
    STW R7, fromdec_r7                  ;

    AND R5, R5, #0                      ;   [R5] errores
    ADD R4, R0, #0                      ;   [R4] texto

    AND R0, R0, #0
    STW R0, fromdec_entero              ;   [entero] = 0
    STW R0, fromdec_fraccion            ;   [fraccion] = 0
    STW R0, fromdec_negativo            ;   [negativo] = 0
    STW R0, fromdec_has_number          ;   [tiene_numero] = 0

;   ==- Signo -=================================================================
    LDBL R0, R4, #0                     ;   [R0] char = texto[0] (1 byte)
    LDW R1, fromdec_neg_minus           ;
    ADD R1, R1, R0                      ;
    BRnp fromdec_chk_plus               ;   if char == '-':
    AND R1, R1, #0                      ;
    ADD R1, R1, #1                      ;
    STW R1, fromdec_negativo            ;       [negativo] = 1
    ADD R4, R4, #1                      ;       texto += 1 byte
    BRnzp fromdec_int_loop              ;

fromdec_chk_plus                        ;
    LDW R1, fromdec_neg_plus            ;
    ADD R1, R1, R0                      ;
    BRnp fromdec_int_loop               ;   elif char == '+':
    ADD R4, R4, #1                      ;       texto += 1 byte
    BRnzp fromdec_int_loop              ;

; --- Pool local 1 ---
fromdec_entero          .FILL #0
fromdec_fraccion        .FILL #0
fromdec_negativo        .FILL #0
fromdec_has_number      .FILL #0
fromdec_r2              .FILL #0
fromdec_r3              .FILL #0
fromdec_r4              .FILL #0
fromdec_r7              .FILL #0
fromdec_ret_ptr1        .FILL fromdec_ret
fromdec_dec_ptr         .FILL fromdec_dec
fromdec_inv_ptr         .FILL fromdec_int_invalid
fromdec_neg_plus        .FILL #-43      ;   - ord('+')
fromdec_neg_period      .FILL #-44      ;   - ord(',')
fromdec_neg_minus       .FILL #-45      ;   - ord('-')
fromdec_neg_dot         .FILL #-46      ;   - ord('.')
fromdec_neg_zero        .FILL #-48      ;   - ord('0')
fromdec_neg_eight       .FILL #-56      ;   - ord('8')
fromdec_neg_nine        .FILL #-57      ;   - ord('9')
fromdec_neg_overchk     .FILL #-3276
fromdec_vars_ptr1       .FILL fromdec_entero

;   ==- Parte entera -==========================================================
fromdec_int_loop                        ;   while True:
    LDBL R0, R4, #0                     ;       [R0] char = texto[0] (1 byte)
    BRnp fromdec_int_not_end            ;       if char == '\0': return
    LDW R1, fromdec_ret_ptr1            ;
    JMP R1                              ;

fromdec_int_not_end                     ;
    LDW R1, fromdec_neg_dot             ;
    ADD R1, R1, R0                      ;
    BRz fromdec_int_period_found        ;
    LDW R1, fromdec_neg_period          ;
    ADD R1, R1, R0                      ;
    BRz fromdec_int_period_found        ;
    BRnzp fromdec_int_range_chk         ;

fromdec_int_period_found                ;       if char == '.' or char == ',':
    ADD R4, R4, #1                      ;           texto += 1 byte
    LDW R1, fromdec_dec_ptr             ;
    JMP R1                              ;           break -> fromdec_dec

fromdec_int_range_chk                   ;
    LDW R1, fromdec_neg_zero            ;
    ADD R1, R1, R0                      ;
    BRzp fromdec_chk_nine               ;
    LDW R1, fromdec_inv_ptr             ;
    JMP R1                              ;       if char < '0': invalid

fromdec_chk_nine                        ;
    LDW R1, fromdec_neg_nine            ;
    ADD R1, R1, R0                      ;
    BRnz fromdec_chk_ovf                ;
    LDW R1, fromdec_inv_ptr             ;
    JMP R1                              ;       if char > '9': invalid

fromdec_chk_ovf                         ;
    LDW R3, fromdec_vars_ptr1           ;   base a fromdec_entero
    LDRW R1, R3, #0                     ;   [R1] entero = [entero] (+0)
    LDW R2, fromdec_neg_overchk         ;
    ADD R2, R2, R1                      ;
    BRp fromdec_int_overflow            ;
    BRn fromdec_int_append              ;
    LDW R2, fromdec_neg_eight           ;
    LDRW R3, R3, #4                     ;   [R3] negativo (+4)
    NOT R3, R3                          ;
    ADD R3, R3, #1                      ;
    ADD R2, R2, R3                      ;
    ADD R2, R2, R0                      ;
    BRn fromdec_int_append              ;

fromdec_int_overflow                    ;
    NOT R5, R5                          ;
    AND R5, R5, #-3                     ;
    NOT R5, R5                          ;   errores = errores | OVERFLOW

fromdec_int_append                      ;
    ADD R2, R1, R1                      ;
    ADD R2, R2, R2                      ;
    ADD R2, R2, R1                      ;
    ADD R1, R2, R2                      ;   entero = entero * 10

    LDW R2, fromdec_neg_zero            ;
    ADD R1, R1, R2                      ;
    ADD R1, R1, R0                      ;   entero = entero + char - '0'

    LDW R3, fromdec_vars_ptr1           ;   base a fromdec_entero
    AND R2, R2, #0                      ;
    ADD R2, R2, #1                      ;
    STRW R2, R3, #6                     ;   [tiene_numero] = 1 (+6)
    ADD R4, R4, #1                      ;   texto += 1 byte
    STRW R1, R3, #0                     ;   [entero] = entero (+0)
    LDW R2, fromdec_int_loop_ptr2       ;
    JMP R2                              ;   continue
fromdec_int_loop_ptr2   .FILL fromdec_int_loop

fromdec_int_invalid                     ;
    NOT R5, R5                          ;
    AND R5, R5, #-2                     ;
    NOT R5, R5                          ;   errores = errores | INVALID_INPUT
    LDW R1, fromdec_ret_ptr_inv         ;
    JMP R1                              ;   return
fromdec_ret_ptr_inv     .FILL fromdec_ret

;   ==- Parte fraccionaria -====================================================
fromdec_dec                             ;
    AND R0, R0, #0                      ;
    STW R0, fromdec_fraccion_l          ;   [fraccion_l] = 0
    STW R0, fromdec_fraccion_h          ;   [fraccion_h] = 0
    AND R0, R0, #0                      ;
    ADD R0, R0, #5                      ;
    ADD R0, R0, #4                      ;   R0 = 9
    STW R0, fromdec_contador            ;   [contador] = 9

fromdec_dec_loop                        ;
    LDW R0, fromdec_contador            ;
    BRp fromdec_dec_body                ;   while contador > 0:
    LDW R1, fromdec_dec_brk_ptr         ;
    JMP R1                              ;

fromdec_dec_body                        ;
    AND R0, R0, #0                      ;
    STW R0, fromdec_current             ;       [current] = 0
    LDBL R0, R4, #0                     ;       [R0] char = texto[0] (1 byte)

    LDW R1, fromdec_neg_zero_2          ;
    ADD R1, R1, R0                      ;
    BRn fromdec_dec_sk1                 ;
    LDW R1, fromdec_neg_nine_2          ;
    ADD R1, R1, R0                      ;
    BRp fromdec_dec_sk1                 ;       if char >= '0' and char <= '9':
    LDW R1, fromdec_neg_zero_2          ;
    ADD R1, R1, R0                      ;
    STW R1, fromdec_current             ;           [current] = char - ord('0')
    ADD R4, R4, #1                      ;           texto += 1 byte
    BRnzp fromdec_dec_increment         ;

fromdec_dec_sk1                         ;
    ADD R0, R0, #0                      ;
    BRz fromdec_dec_increment           ;       elif char != '\0':
    NOT R5, R5                          ;
    AND R5, R5, #-2                     ;
    NOT R5, R5                          ;           errores = errores | INVALID_INPUT
    BRnzp fromdec_dec_increment         ;

; --- Pool local 2A ---
fromdec_fraccion_h      .FILL #0
fromdec_fraccion_l      .FILL #0
fromdec_aux_h           .FILL #0
fromdec_aux_l           .FILL #0
fromdec_current         .FILL #0
fromdec_contador        .FILL #0
fromdec_neg_zero_2      .FILL #-48
fromdec_neg_nine_2      .FILL #-57
fromdec_dec_brk_ptr     .FILL fromdec_dec_break

fromdec_dec_increment                   ;
    LDW R0, fromdec_fraccion_h          ;
    LDW R1, fromdec_fraccion_l          ;
    ADD R0, R0, R0                      ;
    ADD R1, R1, #0                      ;
    BRzp fromdec_dec_incr_sk1           ;
    ADD R0, R0, #1                      ;
fromdec_dec_incr_sk1                    ;
    ADD R1, R1, R1                      ;       * 2

    ADD R0, R0, R0                      ;
    ADD R1, R1, #0                      ;
    BRzp fromdec_dec_incr_sk2           ;
    ADD R0, R0, #1                      ;
fromdec_dec_incr_sk2                    ;
    ADD R1, R1, R1                      ;       * 4
    STW R0, fromdec_aux_h               ;
    STW R1, fromdec_aux_l               ;

    LDW R0, fromdec_aux_l               ;
    LDW R1, fromdec_fraccion_l          ;
    AND R2, R2, #0                      ;
    LDW R3, sub_sumover_1               ;
    JSRR R3                             ;
    STW R0, fromdec_aux_l               ;
    LDW R0, fromdec_aux_h               ;
    LDW R1, fromdec_fraccion_h          ;
    ADD R0, R0, R1                      ;
    ADD R0, R0, R2                      ;
    STW R0, fromdec_aux_h               ;       * 5

    LDW R0, fromdec_aux_h               ;
    LDW R1, fromdec_aux_l               ;
    ADD R0, R0, R0                      ;
    ADD R1, R1, #0                      ;
    BRzp fromdec_dec_incr_sk3           ;
    ADD R0, R0, #1                      ;
fromdec_dec_incr_sk3                    ;
    ADD R1, R1, R1                      ;
    STW R0, fromdec_fraccion_h          ;
    STW R1, fromdec_fraccion_l          ;       * 10

    LDW R0, fromdec_fraccion_l          ;
    LDW R1, fromdec_current             ;
    ADD R0, R0, R1                      ;
    STW R0, fromdec_fraccion_l          ;

    LDW R0, fromdec_contador            ;
    ADD R0, R0, #-1                     ;
    STW R0, fromdec_contador            ;
    LDW R1, fromdec_dec_loop_ptr        ;
    JMP R1                              ;

; --- Pool local 2B ---
sub_sumover_1           .FILL SUMOVER-SUMOVER
fromdec_dec_loop_ptr    .FILL fromdec_dec_loop
fromdec_fvars_ptr2      .FILL fromdec_fraccion_h
fromdec_vars_ptr2       .FILL fromdec_entero
fromdec_neg_frac_h      .FILL xC465
fromdec_neg_frac_l      .FILL x3600
fromdec_ret_ptr2        .FILL fromdec_ret
fromdec_loop2_ptr       .FILL fromdec_dec_loop2

fromdec_dec_break                       ;
    LDW R3, fromdec_fvars_ptr2          ;   base a fromdec_fraccion_h (+0..+10)
    AND R0, R0, #0                      ;
    STRW R0, R3, #10                    ;   [contador] = 0 (+10)

fromdec_dec_loop2                       ;   while True:
    LDW R3, fromdec_fvars_ptr2          ;   base a fromdec_fraccion_h
    LDRW R0, R3, #0                     ;   fraccion_h (+0)
    LDRW R1, R3, #2                     ;   fraccion_l (+2)
    ADD R0, R0, R0                      ;
    ADD R1, R1, #0                      ;
    BRzp fromdec_dec_loop2_sk1          ;
    ADD R0, R0, #1                      ;
fromdec_dec_loop2_sk1                   ;
    ADD R1, R1, R1                      ;
    STRW R0, R3, #0                     ;   fraccion_h (+0) * 2
    STRW R1, R3, #2                     ;   fraccion_l (+2) * 2

    LDRW R0, R3, #2                     ;   fraccion_l (+2)
    LDW R1, fromdec_neg_frac_l          ;
    AND R2, R2, #0                      ;
    LDW R3, sub_sumover_1               ;
    JSRR R3                             ;
    LDW R3, fromdec_fvars_ptr2          ;   restaura base R3
    STRW R0, R3, #6                     ;   aux_l (+6)
    LDRW R0, R3, #0                     ;   fraccion_h (+0)
    LDW R1, fromdec_neg_frac_h          ;
    ADD R0, R0, R1                      ;
    ADD R0, R0, R2                      ;
    STRW R0, R3, #4                     ;   aux_h (+4) = [fraccion_h, fraccion_l] - 1_000_000_000

    LDRW R0, R3, #10                    ;   contador (+10)
    ADD R0, R0, #-8                     ;
    ADD R0, R0, #-8                     ;   contador - 16
    BRn fromdec_dec_increment2          ;   if [contador] >= 16:

    LDRW R0, R3, #4                     ;   aux_h (+4)
    BRzp fromdec_round_up               ;   if [aux_h, aux_l] < 0: return
    LDW R1, fromdec_ret_ptr2            ;
    JMP R1                              ;

fromdec_round_up                        ;
    LDW R3, fromdec_vars_ptr2           ;   base a fromdec_entero
    LDRW R0, R3, #2                     ;   [R0] = fraccion (+2)
    ADD R0, R0, #1                      ;
    STRW R0, R3, #2                     ;   [fraccion] += 1

    BRnp fromdec_round_done             ;   if [fraccion] == 0:
    LDRW R0, R3, #0                     ;   [R0] = entero (+0)
    ADD R0, R0, #1                      ;
    STRW R0, R3, #0                     ;   [entero] += 1

fromdec_round_done                      ;
    LDW R1, fromdec_ret_ptr2            ;
    JMP R1                              ;   return

fromdec_dec_increment2                  ;
    LDW R2, fromdec_vars_ptr2           ;   base a fromdec_entero
    LDRW R0, R2, #2                     ;   [R0] = fraccion (+2)
    ADD R0, R0, R0                      ;
    STRW R0, R2, #2                     ;   [fraccion] <<= 1

    LDRW R0, R3, #4                     ;   aux_h (+4)
    BRn fromdec_dec_continue2           ;   if [aux_h, aux_l] >= 0:
    LDRW R0, R2, #2                     ;   [R0] = fraccion (+2)
    ADD R0, R0, #1                      ;
    STRW R0, R2, #2                     ;   [fraccion] += 1
    LDRW R0, R3, #6                     ;   aux_l (+6)
    STRW R0, R3, #2                     ;   fraccion_l (+2)
    LDRW R0, R3, #4                     ;   aux_h (+4)
    STRW R0, R3, #0                     ;   fraccion_h (+0)

fromdec_dec_continue2                   ;
    LDRW R0, R3, #10                    ;   contador (+10)
    ADD R0, R0, #1                      ;
    STRW R0, R3, #10                    ;   contador (+10)
    LDW R1, fromdec_loop2_ptr           ;
    JMP R1                              ;

;   ==- Return -================================================================
fromdec_ret                             ;
    LDW R3, fromdec_vars_ptr3           ;   base a fromdec_entero (+0..+14)
    LDRW R0, R3, #6                     ;   has_number (+6)
    BRnp fromdec_ret_sk1                ;   if not [tiene_numero]:
    NOT R5, R5                          ;
    AND R5, R5, #-2                     ;
    NOT R5, R5                          ;       errores = errores | INVALID_INPUT

fromdec_ret_sk1
    LDRW R0, R3, #4                     ;   negativo (+4)
    BRz fromdec_ret_skp_neg             ;   if [negativo]:
    LDRW R0, R3, #0                     ;   entero (+0)
    NOT R0, R0                          ;
    LDRW R1, R3, #2                     ;   fraccion (+2)
    BRnp fromdec_ret_sk2                ;
    ADD R0, R0, #1                      ;
fromdec_ret_sk2                         ;
    NOT R1, R1                          ;
    ADD R1, R1, #1                      ;
    STRW R0, R3, #0                     ;   entero (+0)
    STRW R1, R3, #2                     ;   fraccion (+2)

fromdec_ret_skp_neg                     ;
    LDRW R0, R3, #0                     ;   entero (+0)
    LDRW R1, R3, #2                     ;   fraccion (+2)
    LDRW R2, R3, #8                     ;   r2 (+8)
    LDRW R4, R3, #12                    ;   r4 (+12)
    LDRW R7, R3, #14                    ;   r7 (+14)
    LDRW R3, R3, #10                    ;   r3 (+10)
    RET                                 ;

fromdec_vars_ptr3       .FILL fromdec_entero

.END