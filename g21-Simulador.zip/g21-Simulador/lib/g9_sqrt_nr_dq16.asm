; LAB 3 - GRUPO 9 - SQRT Newton-Raphson con normalizacion de rango (ISA Grupo 21)
; Input:  R0=palabra entera, R1=palabra fraccionaria (Q15.16, signo 32 bits)
; Output: R0=palabra entera, R1=fraccionaria de sqrt(x), Q15.16
; R2-R7 preservados; R6 no se utiliza.

.EXTERNAL SQRT_NR_Q8-SQRT_NR_Q8
.EXTERNAL SQ9_MATH_HELPERS-SQ9_ROTL32
.EXTERNAL SQ9_MATH_HELPERS-SQ9_DQ16_TO_Q8
.EXTERNAL SQ9_MATH_HELPERS-SQ9_Q8_TO_DQ16

SQW_PTR_ZERO      .FILL SQW_ZERO
SQW_PTR_NORM      .FILL SQW_NORM
SQW_PTR_DIV4      .FILL SQW_DIV4
SQW_PTR_MUL4      .FILL SQW_MUL4
SQW_PTR_DONE      .FILL SQW_DONE

SQRT_NR_DQ16
        STW R2, SQW_SAVE2
        STW R3, SQW_SAVE3
        STW R4, SQW_SAVE4
        STW R5, SQW_SAVE5
        STW R7, SQW_SAVE7

        ADD R0, R0, #0
        BRn SQW_ZERO_JMP
        BRp SQW_PREPARE
        ADD R1, R1, #0
        BRz SQW_ZERO_JMP

SQW_PREPARE
        AND R4, R4, #0
        STW R4, SQW_EXP

SQW_NORM
        ADD R2, R0, #-8
        ADD R2, R2, #-8
        BRp SQW_DIV4_JMP
        BRn SQW_CHECK_LOW
        ADD R1, R1, #0
        BRnp SQW_DIV4_JMP
        BRnzp SQW_NORMALIZED

SQW_CHECK_LOW
        ADD R2, R0, #-4
        BRn SQW_MUL4_JMP
        BRnzp SQW_NORMALIZED

SQW_DIV4
        LDW R2, SQW_ROT30
        LDW R3, SQW_CIRCLSH_PTR
        JSRR R3
        LDW R2, SQW_MASK14
        AND R0, R0, R2
        LDW R4, SQW_EXP
        ADD R4, R4, #1
        STW R4, SQW_EXP
        LDW R6, SQW_PTR_NORM
        JMP R6

SQW_MUL4
        LDW R2, SQW_ROT2
        LDW R3, SQW_CIRCLSH_PTR
        JSRR R3
        LDW R4, SQW_EXP
        ADD R4, R4, #-1
        STW R4, SQW_EXP
        LDW R6, SQW_PTR_NORM
        JMP R6

SQW_NORMALIZED
        LDW R3, SQW_DQ16_Q8_PTR
        JSRR R3
        LDW R3, SQW_SQRT_PTR
        JSRR R3
        LDW R3, SQW_Q8_DQ16_PTR
        JSRR R3

        LDW R4, SQW_EXP
        BRz SQW_DONE_JMP
        BRn SQW_SCALE_DOWN

SQW_SCALE_UP
        ADD R2, R4, #0
        LDW R3, SQW_CIRCLSH_PTR
        JSRR R3
        BRnzp SQW_DONE

SQW_SCALE_DOWN
        LDW R2, SQW_ROT31
        LDW R3, SQW_CIRCLSH_PTR
        JSRR R3
        LDW R2, SQW_MASK15
        AND R0, R0, R2
        ADD R4, R4, #1
        BRn SQW_SCALE_DOWN
        BRnzp SQW_DONE

SQW_ZERO_JMP
        LDW R6, SQW_PTR_ZERO
        JMP R6

SQW_DIV4_JMP
        LDW R6, SQW_PTR_DIV4
        JMP R6

SQW_MUL4_JMP
        LDW R6, SQW_PTR_MUL4
        JMP R6

SQW_DONE_JMP
        LDW R6, SQW_PTR_DONE
        JMP R6

SQW_ZERO
        AND R0, R0, #0
        AND R1, R1, #0

SQW_DONE
        LDW R2, SQW_SAVE2
        LDW R3, SQW_SAVE3
        LDW R4, SQW_SAVE4
        LDW R5, SQW_SAVE5
        LDW R7, SQW_SAVE7
        ADD R0, R0, #0
        RET

SQW_ROT2          .FILL #2
SQW_ROT30         .FILL #30
SQW_ROT31         .FILL #31
SQW_MASK14        .FILL x3FFF
SQW_MASK15        .FILL x7FFF
SQW_EXP           .FILL #0
SQW_CIRCLSH_PTR   .FILL SQ9_MATH_HELPERS-SQ9_ROTL32
SQW_DQ16_Q8_PTR   .FILL SQ9_MATH_HELPERS-SQ9_DQ16_TO_Q8
SQW_Q8_DQ16_PTR   .FILL SQ9_MATH_HELPERS-SQ9_Q8_TO_DQ16
SQW_SQRT_PTR      .FILL SQRT_NR_Q8-SQRT_NR_Q8
SQW_SAVE2         .FILL #0
SQW_SAVE3         .FILL #0
SQW_SAVE4         .FILL #0
SQW_SAVE5         .FILL #0
SQW_SAVE7         .FILL #0

.END