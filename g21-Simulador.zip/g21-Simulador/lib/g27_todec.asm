.EXTERNAL SUMOVER-SUMOVER
sub_sumover     .FILL SUMOVER-SUMOVER


;   ============================================================================
;   Subrutina: TODEC (Migrada a ISA Grupo 21 - Direccionable por Byte)
;       Convierte un valor a cadena de texto decimal.
;
;   -> INPUT  [R0] Parte entera.
;   -> INPUT  [R1] Parte fraccionaria.
;   -> INPUT  [R2] Puntero al buffer de la cadena.
;   -> INPUT  [R3] Formato bits [15:3 none, 2 SHOW_ENDZ, 1 SHOW_LEADZ, 0 SHOW_PLUS]
;   <- OUTPUT [R2] Puntero al buffer de la cadena ya cargada.
;   ============================================================================

TODEC                                   ;
    STW R0, todec_r0                    ;
    STW R1, todec_r1                    ;
    STW R3, todec_r3                    ;
    STW R4, todec_r4                    ;
    STW R5, todec_r5                    ;
    STW R7, todec_r7                    ;

    STW R0, todec_entero                ;   [entero] = entero
    STW R1, todec_fraccion              ;   [fraccion] = fraccion
    STW R2, todec_cursor_beg            ;   [cursor_beg] = cursor
    STW R2, todec_cursor_wr             ;   [cursor_wr] = cursor
    STW R3, todec_format                ;   [formato] = formato

;   ==- Signo -=================================================================
    LDW R0, todec_entero                ;
    BRzp todec_sig_elif                 ;   if [entero] < 0:
    LDW R0, todec_chr_minus             ;
    LDW R1, todec_cursor_wr             ;
    STBL R0, R1, #0                     ;   1 byte char '-'
    ADD R1, R1, #1                      ;   cursor += 1 byte
    STW R1, todec_cursor_wr             ;

    LDW R0, todec_entero                ;
    NOT R0, R0                          ;
    LDW R1, todec_fraccion              ;
    BRnp todec_sig_sk1                  ;
    ADD R0, R0, #1                      ;
todec_sig_sk1                           ;
    NOT R1, R1                          ;
    ADD R1, R1, #1                      ;
    STW R0, todec_entero                ;
    STW R1, todec_fraccion              ;
    BRnzp todec_int                     ;

todec_sig_elif                          ;
    LDW R0, todec_format                ;
    AND R0, R0, #1                      ;
    BRz todec_int                       ;   elif [format] & SHOW_PLUS:
    LDW R0, todec_chr_plus              ;
    LDW R1, todec_cursor_wr             ;
    STBL R0, R1, #0                     ;   1 byte char '+'
    ADD R1, R1, #1                      ;   cursor += 1 byte
    STW R1, todec_cursor_wr             ;
    BRnzp todec_int                     ;

; --- Pool local 1 ---
; Offsets desde todec_entero:
;   -12: r0        | -10: r1         | -8: r3          | -6: r4
;   -4: r5         | -2: r7          |  0: entero      | +2: fraccion
;   +4: cursor_beg | +6: cursor_wr   | +8: format
todec_r0            .FILL #0
todec_r1            .FILL #0
todec_r3            .FILL #0
todec_r4            .FILL #0
todec_r5            .FILL #0
todec_r7            .FILL #0
todec_entero        .FILL #0
todec_fraccion      .FILL #0
todec_cursor_beg    .FILL #0
todec_cursor_wr     .FILL #0
todec_format        .FILL #0
todec_chr_plus      .FILL #43           ;   ord('+')
todec_chr_minus     .FILL #45           ;   ord('-')
todec_chr_dot       .FILL #46           ;   ord('.')
todec_chr_zero      .FILL #48           ;   ord('0')
todec_expr_vec_ptr1 .FILL todec_expr_vec
todec_vars_ptr1     .FILL todec_entero

;   ==- Entero -================================================================
todec_int                               ;
    LDW R5, todec_expr_vec_ptr1         ;
    ADD R5, R5, #6                      ;
    ADD R5, R5, #5                      ;
    ADD R5, R5, #5                      ;   +16 bytes (5to digito: 4 entradas * 4 bytes)
    LDRW R4, R5, #2                     ;   +2 bytes: -expr_actual = -10_000
    LDW R3, todec_entero                ;   [R3] entero = [entero]
    AND R2, R2, #0                      ;   [R2] contador = 0

todec_int_loop                          ;   while True:
    ADD R0, R3, R4                      ;       [R0] aux = entero + -expr_actual
    BRn todec_int_format_chk            ;       if aux >= 0:
    ADD R2, R2, #1                      ;           contador += 1
    ADD R3, R0, #0                      ;           entero = aux
    BRnzp todec_int_loop                ;

todec_int_format_chk                    ;
    LDW R0, todec_format                ;
    AND R0, R0, #2                      ;
    BRnp todec_int_append               ;
    ADD R0, R2, #0                      ;
    BRnp todec_int_append               ;
    BRnzp todec_int_sk1                 ;

todec_int_append                        ;
    LDW R0, todec_format                ;
    NOT R0, R0                          ;
    AND R0, R0, #-3                     ;
    NOT R0, R0                          ;
    STW R0, todec_format                ;
    LDW R0, todec_chr_zero              ;
    LDW R1, todec_cursor_wr             ;
    ADD R0, R0, R2                      ;
    STBL R0, R1, #0                     ;   1 byte char
    ADD R1, R1, #1                      ;   cursor += 1 byte
    STW R1, todec_cursor_wr             ;

todec_int_sk1                           ;
    AND R2, R2, #0                      ;   contador = 0
    ADD R5, R5, #4                      ;   siguiente entrada 32-bit (+4 bytes)
    LDRW R4, R5, #2                     ;   +2 bytes: -expr_actual
    BRnp todec_int_loop                 ;

todec_int_break                         ;
    LDW R3, todec_vars_ptr1             ;   base a todec_entero
    LDRW R0, R3, #8                     ;   format (+8)
    AND R0, R0, #2                      ;
    BRnp todec_early                    ;
    LDW R0, todec_chr_zero_2            ;
    LDRW R1, R3, #6                     ;   cursor_wr (+6)
    STBL R0, R1, #0                     ;   1 byte char '0'
    ADD R1, R1, #1                      ;   cursor += 1 byte
    STRW R1, R3, #6                     ;   cursor_wr (+6)

;   ==- Prueba para retorno temprano -==========================================
todec_early                             ;
    LDW R3, todec_vars_ptr1             ;   base a todec_entero
    LDRW R0, R3, #2                     ;   fraccion (+2)
    BRnp todec_dec                      ;   if fraccion == 0:
    LDRW R1, R3, #6                     ;   cursor_wr (+6)
    LDRW R0, R3, #8                     ;   format (+8)
    AND R0, R0, #4                      ;
    BRz todec_early_chk                 ;       if [formato] & SHOW_ENDZ:
    LDW R0, todec_chr_dot_2             ;
    STBL R0, R1, #0                     ;   1 byte char '.'
    ADD R1, R1, #1                      ;
    LDW R0, todec_chr_zero_2            ;
    AND R2, R2, #0                      ;
    ADD R2, R2, #5                      ;
    ADD R2, R2, #4                      ;   contador = 9
todec_early_chk_loop                    ;
    ADD R2, R2, #0                      ;
    BRnz todec_early_chk                ;
    STBL R0, R1, #0                     ;   1 byte char '0'
    ADD R1, R1, #1                      ;
    ADD R2, R2, #-1                     ;
    BRnzp todec_early_chk_loop          ;

todec_early_chk                         ;
    AND R0, R0, #0                      ;
    STBL R0, R1, #0                     ;   1 byte '\0'
    STRW R1, R3, #6                     ;   cursor_wr (+6)
    LDW R0, todec_ret_ptr               ;
    JMP R0                              ;

; --- Pool local 2 ---
todec_chr_dot_2     .FILL #46           ;   ord('.')
todec_chr_zero_2    .FILL #48           ;   ord('0')
todec_ret_ptr       .FILL todec_ret
todec_vars_ptr2     .FILL todec_entero
todec_frac_expr_h   .FILL x3B9A
todec_frac_expr_l   .FILL xCA00         ;   1_000_000_000
sub_sumover_1       .FILL SUMOVER-SUMOVER

;   ==- Decimal -===============================================================
todec_dec                               ;
    LDW R3, todec_vars_ptr2             ;   base a todec_entero
    LDW R0, todec_chr_dot_2             ;
    LDRW R1, R3, #6                     ;   cursor_wr (+6)
    STBL R0, R1, #0                     ;   1 byte char '.'
    ADD R1, R1, #1                      ;   cursor += 1 byte
    STRW R1, R3, #6                     ;   cursor_wr (+6)

    AND R0, R0, #0                      ;
    STW R0, todec_fraccion_h            ;
    STW R0, todec_fraccion_l            ;

    STW R0, todec_aux_0                 ;
    LDW R0, todec_frac_expr_h           ;
    STW R0, todec_aux_1                 ;
    LDW R0, todec_frac_expr_l           ;
    STW R0, todec_aux_2                 ;

    AND R5, R5, #0                      ;
    ADD R5, R5, #1                      ;   [R5] mascara = 1

todec_dec_loop1                         ;
    ADD R5, R5, #0                      ;
    BRnp todec_dec_loop1_body           ;
    LDW R0, todec_brk1_ptr              ;
    JMP R0                              ;
todec_brk1_ptr      .FILL todec_dec_break1

todec_dec_loop1_body                    ;
    LDW R3, todec_vars_ptr2             ;   base a todec_entero
    LDRW R0, R3, #2                     ;   fraccion (+2)
    AND R0, R0, R5                      ;
    BRnp todec_dec_add_bit              ;   if [fraccion] & mascara:
    LDW R0, todec_cont1_ptr             ;
    JMP R0                              ;
todec_cont1_ptr     .FILL todec_dec_continue1

todec_dec_add_bit                       ;
    LDW R0, todec_fraccion_l            ;
    LDW R1, todec_aux_1                 ;
    AND R2, R2, #0                      ;
    LDW R3, sub_sumover_1               ;
    JSRR R3                             ;
    STW R0, todec_fraccion_l            ;
    LDW R0, todec_fraccion_h            ;
    LDW R1, todec_aux_0                 ;
    ADD R0, R0, R1                      ;
    ADD R0, R0, R2                      ;
    STW R0, todec_fraccion_h            ;

todec_dec_continue1                     ;
    LDW R0, todec_aux_0                 ;
    ADD R0, R0, R0                      ;
    LDW R1, todec_aux_1                 ;
    BRzp todec_dec_cont1_sk1            ;
    ADD R0, R0, #1                      ;
todec_dec_cont1_sk1                     ;
    ADD R1, R1, R1                      ;
    LDW R2, todec_aux_2                 ;
    BRzp todec_dec_cont1_sk2            ;
    ADD R1, R1, #1                      ;
todec_dec_cont1_sk2                     ;
    ADD R2, R2, R2                      ;
    STW R0, todec_aux_0                 ;
    STW R1, todec_aux_1                 ;
    STW R2, todec_aux_2                 ;

    ADD R5, R5, R5                      ;
    LDW R0, todec_loop1_ptr             ;
    JMP R0                              ;
todec_loop1_ptr     .FILL todec_dec_loop1

; --- Pool local 3 ---
; Offsets desde todec_fraccion_h:
;   0: fraccion_h | +2: fraccion_l | +4: aux_0 | +6: aux_1 | +8: aux_2
todec_fraccion_h    .FILL #0
todec_fraccion_l    .FILL #0
todec_aux_0         .FILL #0
todec_aux_1         .FILL #0
todec_aux_2         .FILL #0
todec_fvars_ptr2    .FILL todec_fraccion_h
todec_vars_ptr3     .FILL todec_entero
todec_expr_vec_ptr2 .FILL todec_expr_vec
todec_chr_zero_3    .FILL #48           ;   ord('0')
sub_sumover_2       .FILL SUMOVER-SUMOVER

todec_dec_break1                        ;
    LDW R5, todec_expr_vec_ptr2         ;   [R5] expresiones
    AND R4, R4, #0                      ;   [R4] contador = 0

todec_dec_loop2                         ;   while True:
    LDW R0, todec_fraccion_l            ;
    LDRW R1, R5, #2                     ;   +2 bytes: palabra baja
    AND R2, R2, #0                      ;
    LDW R3, sub_sumover_2               ;
    JSRR R3                             ;

    LDW R1, todec_fraccion_h            ;
    ADD R1, R1, R2                      ;
    LDRW R2, R5, #0                     ;   +0 bytes: palabra alta
    ADD R1, R1, R2                      ;

    BRn todec_dec_append                ;
    STW R1, todec_fraccion_h            ;
    STW R0, todec_fraccion_l            ;
    ADD R4, R4, #1                      ;
    BRnzp todec_dec_loop2               ;

todec_dec_append                        ;
    LDW R3, todec_vars_ptr3             ;   base a todec_entero
    LDW R0, todec_chr_zero_3            ;
    LDRW R1, R3, #6                     ;   cursor_wr (+6)
    ADD R0, R0, R4                      ;
    STBL R0, R1, #0                     ;   1 byte char
    ADD R1, R1, #1                      ;   cursor += 1 byte
    STRW R1, R3, #6                     ;   cursor_wr (+6)

todec_dec_format_chk                    ;
    LDRW R0, R3, #8                     ;   format (+8)
    AND R0, R0, #4                      ;
    BRnp todec_dec_continue2            ;
    LDW R2, todec_fvars_ptr2            ;   base a todec_fraccion_h
    LDRW R0, R2, #2                     ;   fraccion_l (+2)
    BRnp todec_dec_continue2            ;
    LDRW R0, R2, #0                     ;   fraccion_h (+0)
    BRnp todec_dec_continue2            ;
    BRnzp todec_dec_break2              ;

todec_dec_continue2                     ;
    AND R4, R4, #0                      ;
    ADD R5, R5, #4                      ;   siguiente entrada 32-bit (+4 bytes)
    LDRW R0, R5, #2                     ;   +2 bytes
    BRnp todec_dec_jmp_loop2            ;
    LDRW R0, R5, #0                     ;   +0 bytes
    BRz todec_dec_break2                ;
todec_dec_jmp_loop2                     ;
    LDW R0, todec_loop2_ptr             ;
    JMP R0                              ;
todec_loop2_ptr     .FILL todec_dec_loop2

todec_dec_break2                        ;
    LDW R3, todec_vars_ptr4             ;   base a todec_entero
    LDRW R1, R3, #6                     ;   cursor_wr (+6)
    AND R0, R0, #0                      ;
    STBL R0, R1, #0                     ;   1 byte '\0'
    ADD R1, R1, #1                      ;
    STRW R1, R3, #6                     ;   cursor_wr (+6)

;   ==- Return -================================================================
todec_ret                               ;
    LDW R3, todec_vars_ptr4             ;   base a todec_entero (-12..+8)
    LDRW R0, R3, #-12                   ;   r0 (-12)
    LDRW R1, R3, #-10                   ;   r1 (-10)
    LDRW R2, R3, #4                     ;   cursor_beg (+4)
    LDRW R4, R3, #-6                    ;   r4 (-6)
    LDRW R5, R3, #-4                    ;   r5 (-4)
    LDRW R7, R3, #-2                    ;   r7 (-2)
    LDRW R3, R3, #-8                    ;   r3 (-8)
    RET                                 ;

todec_vars_ptr4     .FILL todec_entero

todec_expr_vec      .FILL xfa0a         ;
                    .FILL x1f00         ;  - 10**8
                    .FILL xff67         ;
                    .FILL x6980         ;  - 10**7
                    .FILL xfff0         ;
                    .FILL xbdc0         ;  - 10**6
                    .FILL xfffe         ;
                    .FILL x7960         ;  - 10**5
                    .FILL xffff         ;
                    .FILL xd8f0         ;  - 10**4
                    .FILL xffff         ;
                    .FILL xfc18         ;  - 10**3
                    .FILL xffff         ;
                    .FILL xff9c         ;  - 10**2
                    .FILL xffff         ;
                    .FILL xfff6         ;  - 10**1
                    .FILL xffff         ;
                    .FILL xffff         ;  - 10**0
                    .FILL x0000         ;
                    .FILL x0000         ;  NULL32

.END