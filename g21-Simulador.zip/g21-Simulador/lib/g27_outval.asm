.EXTERNAL GETVAL_BUFFER-BUFFER
ext_buffer      .FILL GETVAL_BUFFER-BUFFER

.EXTERNAL TODEC-TODEC
sub_todec       .FILL TODEC-TODEC 

.EXTERNAL FROM_QM_N-FROM_QM_N
sub_from_qm_n   .FILL FROM_QM_N-FROM_QM_N


;   ============================================================================
;   Subrutina: OUTVAL (Migrada a ISA Grupo 21)
;       Muestra por consola un valor, en un formato especifico.
;
;   -> INPUT  [R0] Qn.m , o parte entera (depende del formato).
;   -> INPUT  [R1] cero, o parte fraccionaria (depende del formato).
;   -> INPUT  [R2] n .
;   ============================================================================
OUTVAL                                  ;

    STW R0, outval_r0                   ;
    STW R1, outval_r1                   ; 
    STW R2, outval_r2                   ;
    STW R3, outval_r3                   ;
    STW R4, outval_r4                   ;
    STW R7, outval_r7                   ;

    ADD R2, R2, #0                      ;
    BRnp outval_sk1                     ;   if n == 0:
    AND R1, R1, #0                      ;       fraccion = 0
    BRnzp outval_out                    ;

outval_sk1                              ;
    ADD R3, R2, #-8                     ;
    ADD R3, R3, #-8                     ;   n - 16
    BRz outval_out                      ;   if n != 16:
    ADD R1, R2, #0                      ;
    LDW R2, sub_from_qm_n               ;
    JSRR R2                             ;       (entero, fraccion) = fromQm_n(qm_n, n)

outval_out
    LDW R2, ext_buffer                  ;
    AND R3, R3, #0                      ;
    LDW R4, sub_todec                   ;
    JSRR R4                             ;
    LDW R0, ext_buffer                  ;
    PUTS                                ;   print(todec(value))
    AND R0, R0, #0                      ;
    ADD R0, R0, #5                      ;
    ADD R0, R0, #5                      ;   R0 = 10 ('\n')
    OUT                                 ;   print('\n')

    LDW R0, outval_r0                   ;
    LDW R1, outval_r1                   ;
    LDW R2, outval_r2                   ;
    LDW R3, outval_r3                   ;
    LDW R4, outval_r4                   ;
    LDW R7, outval_r7                   ;
    RET                                 ;

outval_r0           .FILL #0
outval_r1           .FILL #0 
outval_r2           .FILL #0
outval_r3           .FILL #0 
outval_r4           .FILL #0 
outval_r7           .FILL #0 

.END