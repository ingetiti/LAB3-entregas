; ============================================================
; SUBRUTINA: EXP_RAPIDA (adaptada a ISA Grupo 21)
;
; ENTRADAS:
;   R0 = Base (int)
;   R1 = Exponente (int)
;
; SALIDA:
;   R0 = Base ^ Exponente (int)
;
; REGISTROS CALLEE-SAVED:
;   R1, R2, R3, R4, R5
; ============================================================

EXP_RAPIDA

        STIW    R1, ptr_exp_r1
        STIW    R2, ptr_exp_r2
        STIW    R3, ptr_exp_r3
        STIW    R4, ptr_exp_r4
        STIW    R5, ptr_exp_r5
        BRnzp   exp_inicio

ptr_exp_r1          .FILL exp_guardado_r1
ptr_exp_r2          .FILL exp_guardado_r2
ptr_exp_r3          .FILL exp_guardado_r3
ptr_exp_r4          .FILL exp_guardado_r4
ptr_exp_r5          .FILL exp_guardado_r5
ptr_exp_paridad     .FILL exp_paridad
ptr_exp_loop_w      .FILL EXP_LOOP_W
ptr_exp_post_proc   .FILL EXP_POST_PROC

exp_inicio
        ; Copiar argumentos a registros de trabajo
        ADD     R2, R0, #0          ; R2 = base
        ADD     R3, R1, #0          ; R3 = exponente

        ; R4 = 1 (acumulador)
        AND     R4, R4, #0
        ADD     R4, R4, #1

        ; Guardar paridad del exponente original (0 = par, 1 = impar)
        AND     R0, R3, #1
        STIW    R0, ptr_exp_paridad

        ; Determinar signo de la base (R5 = 0 positiva, R5 = 1 negativa)
        AND     R5, R5, #0
        ADD     R2, R2, #0
        BRzp    EXP_LOOP_W

        ADD     R5, R5, #1
        NOT     R2, R2
        ADD     R2, R2, #1

        ; ====================================================
        ; BUCLE PRINCIPAL DE EXPONENCIACION RAPIDA
        ; ====================================================
EXP_LOOP_W
        ADD     R3, R3, #0
        BRp     EXP_EXP_POS
        LDW     R0, ptr_exp_post_proc
        JMP     R0

EXP_EXP_POS
        ; Comprobar si el exponente es impar
        AND     R0, R3, #1
        BRz     EXP_L_SHIFT

        ; R4 = R4 * R2 mediante sumas sucesivas
        AND     R0, R0, #0          ; resultado temporal = 0
        ADD     R1, R2, #0          ; contador = |base|

EXP_M_LOOP1
        ADD     R1, R1, #0
        BRnz    EXP_M_END1
        ADD     R0, R0, R4
        ADD     R1, R1, #-1
        BRnzp   EXP_M_LOOP1

EXP_M_END1
        ADD     R4, R0, #0          ; R4 = R4 * R2

        ; Dividir exponente entre 2 mediante restas sucesivas
EXP_L_SHIFT
        AND     R0, R0, #0          ; cociente = 0
        ADD     R1, R3, #0          ; dividendo = exponente

EXP_D_LOOP
        ADD     R1, R1, #-2
        BRn     EXP_D_END
        ADD     R0, R0, #1
        BRnzp   EXP_D_LOOP

EXP_D_END
        ADD     R3, R0, #0          ; R3 = R3 / 2

        ; Si el nuevo exponente es 0, termina
        ADD     R3, R3, #0
        BRp     EXP_M_CUADRADO
        LDW     R0, ptr_exp_post_proc
        JMP     R0

        ; R2 = R2 * R2 mediante sumas sucesivas
EXP_M_CUADRADO
        AND     R0, R0, #0          ; resultado temporal = 0
        ADD     R1, R2, #0          ; contador = R2

EXP_M_LOOP2
        ADD     R1, R1, #0
        BRnz    EXP_M_END2
        ADD     R0, R0, R2
        ADD     R1, R1, #-1
        BRnzp   EXP_M_LOOP2

EXP_M_END2
        ADD     R2, R0, #0          ; R2 = R2 * R2
        LDW     R0, ptr_exp_loop_w
        JMP     R0

        ; ====================================================
        ; PROCESAMIENTO FINAL
        ; ====================================================
EXP_POST_PROC
        ADD     R0, R4, #0          ; resultado absoluto en R0

        ADD     R5, R5, #0
        BRz     EXP_RESTAURAR

        LDIW    R1, ptr_exp_paridad_end
        ADD     R1, R1, #0
        BRz     EXP_RESTAURAR

        NOT     R0, R0
        ADD     R0, R0, #1

EXP_RESTAURAR
        LDIW    R1, ptr_exp_r1_end
        LDIW    R2, ptr_exp_r2_end
        LDIW    R3, ptr_exp_r3_end
        LDIW    R4, ptr_exp_r4_end
        LDIW    R5, ptr_exp_r5_end
        RET

ptr_exp_paridad_end .FILL exp_paridad
ptr_exp_r1_end      .FILL exp_guardado_r1
ptr_exp_r2_end      .FILL exp_guardado_r2
ptr_exp_r3_end      .FILL exp_guardado_r3
ptr_exp_r4_end      .FILL exp_guardado_r4
ptr_exp_r5_end      .FILL exp_guardado_r5

exp_paridad         .FILL #0
exp_guardado_r1     .FILL #0
exp_guardado_r2     .FILL #0
exp_guardado_r3     .FILL #0
exp_guardado_r4     .FILL #0
exp_guardado_r5     .FILL #0

.END