;==============================================================================
; SUBRUTINA SENO TAYLOR (Optimizada para ISA Grupo 21)
; Entrada:  R0 = angulo en decimas de grado (0..3600, ej: 600 = 60.0°)
; Salida:   R0 = sin(angulo) en formato Q3.12 (o -1 si angulo fuera de rango)
;==============================================================================

CALCULAR_SENO
    STW R0, ENTRADA_ANGULO

    ; Guardar R3 original (+4 bytes) y usar R3 como puntero base de respaldo
    LEA R0, GUARDADO_R1
    STRW R3, R0, #4

    LEA R3, GUARDADO_R1
    STRW R1, R3, #0
    STRW R2, R3, #2
    STRW R4, R3, #6
    STRW R5, R3, #8
    STRW R7, R3, #10
    STRW R6, R3, #14

    LDW R0, ENTRADA_ANGULO

; =================================
; VALIDAR ANGULO [0 .. 3600]
; =================================
    ADD R0, R0, #0
    BRn ERROR

    LDW R1, LIMITE360
    SUB R2, R0, R1
    BRp ERROR
    BRnzp CONTINUAR

ERROR
    AND R0, R0, #0
    ADD R0, R0, #-1
    LDW R1, FIN_SENO_PTR
    JMP R1

; =================================
; SELECCION DE CUADRANTE
; =================================
CONTINUAR
    LDW R1, LIMITE90
    SUB R2, R0, R1
    BRnz CUADRANTE1

    LDW R1, LIMITE180
    SUB R2, R0, R1
    BRnz CUADRANTE2

    LDW R1, LIMITE270
    SUB R2, R0, R1
    BRnz CUADRANTE3

    BRnzp CUADRANTE4

CUADRANTE1
    ADD R2, R0, #0
    AND R1, R1, #0
    ADD R1, R1, #1
    STRW R1, R3, #12            ; SIGNO_CUADRANTE = +1
    LDW R1, CONVERSION_PTR
    JMP R1

CUADRANTE2
    LDW R1, LIMITE180
    SUB R2, R1, R0              ; 1800 - angulo
    AND R1, R1, #0
    ADD R1, R1, #1
    STRW R1, R3, #12            ; SIGNO_CUADRANTE = +1
    LDW R1, CONVERSION_PTR
    JMP R1

CUADRANTE3
    LDW R1, LIMITE180
    SUB R2, R0, R1              ; angulo - 1800
    AND R1, R1, #0
    ADD R1, R1, #-1
    STRW R1, R3, #12            ; SIGNO_CUADRANTE = -1
    LDW R1, CONVERSION_PTR
    JMP R1

CUADRANTE4
    LDW R1, LIMITE360
    SUB R2, R1, R0              ; 3600 - angulo
    AND R1, R1, #0
    ADD R1, R1, #-1
    STRW R1, R3, #12            ; SIGNO_CUADRANTE = -1
    LDW R1, CONVERSION_PTR
    JMP R1

; --- Pool local 1 (datos de entrada, limites y constantes de conversion) ---
ENTRADA_ANGULO  .FILL #0
GUARDADO_R1     .BLKW #8        ; +0:R1, +2:R2, +4:R3, +6:R4, +8:R5, +10:R7, +12:SIGNO, +14:R6
FIN_SENO_PTR    .FILL FIN_CALCULAR_SENO
CONVERSION_PTR  .FILL CONVERSION
MULT_SUB_PTR_1  .FILL MULT_32_B15
LIMITE90        .FILL #900
LIMITE180       .FILL #1800
LIMITE270       .FILL #2700
LIMITE360       .FILL #3600
MULTIPLICADOR   .FILL #12868
BASE32768       .FILL x8000
NEG1800         .FILL #-1800
NEG6            .FILL #-6
ANGULO_Q12      .FILL #0
CUADRADO_Q12    .FILL #0
CUBO_Q12        .FILL #0
T2_Q12          .FILL #0

; =================================
; 1. CONVERSION A RADIANES Q3.12: x = angulo_reducido * 12868 / 1800
; =================================
CONVERSION
    LDW R1, MULTIPLICADOR
    LDW R0, MULT_SUB_PTR_1
    JSRR R0                     ; (R5, R4) = angulo_reducido * 12868

    ; Division por 1800 (maximo 7 iteraciones)
    AND R2, R2, #0
    LDW R1, NEG1800

BUCLE_DIV1800
    ADD R7, R4, R1
    BRzp RESTA1800

    ADD R5, R5, #0
    BRz FIN_DIV1800

    ADD R5, R5, #-1
    LDW R0, BASE32768
    ADD R7, R7, R0
    ADD R4, R7, #0
    ADD R2, R2, #1
    BRnzp BUCLE_DIV1800

RESTA1800
    ADD R4, R7, #0
    ADD R2, R2, #1
    BRnzp BUCLE_DIV1800

FIN_DIV1800
    STW R2, ANGULO_Q12

; =================================
; 2. CALCULAR X^2 = (X * X) >> 12
; =================================
    LDW R1, ANGULO_Q12
    ADD R2, R1, #0
    LDW R0, MULT_SUB_PTR_1
    JSRR R0                     ; (R5, R4) = X * X

    LSL R5, R5, #3              ; (R5 * 2^15) / 2^12 = R5 << 3
    LSR R4, R4, #12             ; R4 / 2^12 = R4 >> 12
    ADD R2, R5, R4
    STW R2, CUADRADO_Q12

; =================================
; 3. CALCULAR X^3 = (X^2 * X) >> 12  y  T2 = -X^3 / 6
; =================================
    LDW R1, CUADRADO_Q12
    LDW R2, ANGULO_Q12
    LDW R0, MULT_SUB_PTR_1
    JSRR R0                     ; (R5, R4) = X^2 * X

    LSL R5, R5, #3
    LSR R4, R4, #12
    ADD R4, R5, R4
    STW R4, CUBO_Q12

    ; T2 = -(X^3 / 6)
    LDW R1, NEG6
    AND R2, R2, #0

BUCLE_DIV_T2
    ADD R4, R4, R1
    BRn FIN_DIV_T2
    ADD R2, R2, #1
    BRnzp BUCLE_DIV_T2

FIN_DIV_T2
    NOT R2, R2
    ADD R2, R2, #1
    STW R2, T2_Q12

; =================================
; 4. CALCULAR X^5 = (X^3 * X^2) >> 12  y  T3 = X^5 / 120
; =================================
    LDW R1, CUBO_Q12
    LDW R2, CUADRADO_Q12
    LDW R0, MULT_SUB_PTR
    JSRR R0                     ; (R5, R4) = X^3 * X^2

    LSL R5, R5, #3
    LSR R4, R4, #12
    ADD R4, R5, R4              ; R4 = X^5 en Q3.12 (sin signo)

    AND R5, R5, #0
    ADD R4, R4, #0
    BRzp INICIO_DIV_T3

    ADD R5, R5, #1              ; Si X^5 >= 32768, separar parte alta
    LDW R7, BASE32768_2
    ADD R4, R4, R7

INICIO_DIV_T3
    AND R2, R2, #0
    LDW R1, NEG120

BUCLE_DIV_T3
    ADD R4, R4, R1
    BRn PRESTAR_T3
    ADD R2, R2, #1
    BRnzp BUCLE_DIV_T3

PRESTAR_T3
    ADD R5, R5, #0
    BRz FIN_DIV_T3
    ADD R5, R5, #-1
    LDW R7, BASE32768_2
    ADD R4, R4, R7
    ADD R2, R2, #1
    BRnzp BUCLE_DIV_T3

FIN_DIV_T3
    STW R2, T3_Q12

; =================================
; 5. CALCULAR T4 = ((T3 * X^2) >> 12) / 42
; =================================
    LDW R1, T3_Q12
    LDW R2, CUADRADO_PTR
    LDRW R2, R2, #0
    LDW R0, MULT_SUB_PTR
    JSRR R0                     ; (R5, R4) = T3 * X^2

    LSL R5, R5, #3
    LSR R4, R4, #12
    ADD R2, R5, R4

    AND R1, R1, #0
    LDW R4, NEG42

BUCLE_DIV42
    ADD R2, R2, R4
    BRn FIN_DIV42
    ADD R1, R1, #1
    BRnzp BUCLE_DIV42

FIN_DIV42
    STW R1, T4_Q12

; =================================
; 6. SUMAR SERIE DE TAYLOR: S = X + T2 + T3 - T4
; =================================
    LDW R0, ANGULO_PTR
    LDRW R0, R0, #0

    LDW R1, T2_PTR
    LDRW R1, R1, #0
    ADD R0, R0, R1

    LDW R1, T3_Q12
    ADD R0, R0, R1

    LDW R1, T4_Q12
    SUB R0, R0, R1              ; S = X + T2 + T3 - T4

    ; Aplicar signo del cuadrante (+12 bytes)
    LDRW R1, R3, #12
    ADD R1, R1, #0
    BRzp FIN_CALCULAR_SENO

    NOT R0, R0
    ADD R0, R0, #1

FIN_CALCULAR_SENO
    LDRW R1, R3, #0
    LDRW R2, R3, #2
    LDRW R4, R3, #6
    LDRW R5, R3, #8
    LDRW R7, R3, #10
    LDRW R6, R3, #14
    LDRW R3, R3, #4
    RET

; --- Pool local 2 (constantes de Taylor y punteros) ---
MULT_SUB_PTR    .FILL MULT_32_B15
CUADRADO_PTR    .FILL CUADRADO_Q12
ANGULO_PTR      .FILL ANGULO_Q12
T2_PTR          .FILL T2_Q12
BASE32768_2     .FILL x8000
NEG120          .FILL #-120
NEG42           .FILL #-42
T3_Q12          .FILL #0
T4_Q12          .FILL #0

; =============================================================================
; Subrutina auxiliar: MULT_32_B15
; Multiplicacion rapida por desplazamiento (Shift-and-Add en base 32768)
; Entrada: R1 = multiplicando (0..32767), R2 = multiplicador (0..32767)
; Salida:  (R5, R4) = R1 * R2 en base 32768 (R5 = bits [29:15], R4 = bits [14:0])
; Preserva R3 y R7
; =============================================================================
MULT_32_B15
    STW R7, M32_RET_ADDR        ; Preservar direccion de retorno
    AND R4, R4, #0              ; Acumulador bajo
    AND R5, R5, #0              ; Acumulador alto
    AND R7, R7, #0              ; Multiplicando alto
    LDW R6, M32_NEG32768

M32_LOOP
    ADD R2, R2, #0
    BRz M32_DONE

    AND R0, R2, #1              ; Bit menos significativo de R2
    BRz M32_SHIFT

    ADD R4, R4, R1              ; Acumular parte baja
    BRn M32_CARRY_ACC
    ADD R5, R5, R7              ; Acumular parte alta
    BRnzp M32_SHIFT

M32_CARRY_ACC
    ADD R4, R4, R6              ; R4 -= 32768
    ADD R5, R5, R7
    ADD R5, R5, #1              ; Acarreo a parte alta

M32_SHIFT
    LSR R2, R2, #1              ; R2 >>= 1
    BRz M32_DONE

    ADD R7, R7, R7              ; Multiplicando alto <<= 1
    ADD R1, R1, R1              ; Multiplicando bajo <<= 1
    BRzp M32_LOOP

    ADD R1, R1, R6              ; R1 -= 32768
    ADD R7, R7, #1              ; Acarreo al multiplicando alto
    BRnzp M32_LOOP

M32_DONE
    LDW R7, M32_RET_ADDR        ; Restaurar direccion de retorno
    RET

M32_NEG32768    .FILL x8000
M32_RET_ADDR    .FILL #0

.END