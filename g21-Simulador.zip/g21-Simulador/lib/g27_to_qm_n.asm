;   ============================================================================
;   Subrutina: TO_QM_N (Migrada a ISA Grupo 21 - Direccionable por Byte)
;       Convierte un numero en Q15.16 (entero, fraccion) a formato Qm.n.
;
;   -> INPUT  [R0] Parte entera (16 bits con signo)
;   -> INPUT  [R1] Parte fraccionaria (16 bits sin signo)
;   -> INPUT  [R2] n (cantidad de bits fraccionarios, 0..15)
;   <- OUTPUT [R0] Valor en formato Qm.n
;   ============================================================================

TO_QM_N
    STW R1, to_qm_n_r1
    STW R2, to_qm_n_r2
    STW R3, to_qm_n_r3

    ADD R2, R2, #0
    BRz to_qm_n_ret                     ; Si n == 0, devuelve R0 tal cual

    ; 1. Desplazar parte entera a la izquierda n bits: R0 = R0 << n
    ADD R3, R2, #0
to_qm_n_shl
    ADD R0, R0, R0
    ADD R3, R3, #-1
    BRp to_qm_n_shl

    ; 2. Desplazar parte fraccionaria a la derecha (16 - n) bits: R1 = R1 >>> (16 - n)
    AND R3, R3, #0
    ADD R3, R3, #6
    ADD R3, R3, #5
    ADD R3, R3, #5                      ; R3 = 16
    SUB R3, R3, R2                      ; R3 = 16 - n
    BRnz to_qm_n_combine

to_qm_n_shr
    LSR R1, R1, #1
    ADD R3, R3, #-1
    BRp to_qm_n_shr

to_qm_n_combine
    ADD R0, R0, R1                      ; Combinar parte entera + fraccionaria

to_qm_n_ret
    LDW R1, to_qm_n_r1
    LDW R2, to_qm_n_r2
    LDW R3, to_qm_n_r3
    RET

to_qm_n_r1      .FILL #0
to_qm_n_r2      .FILL #0
to_qm_n_r3      .FILL #0

.END