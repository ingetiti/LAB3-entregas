.EXTERNAL GETVAL_BUFFER-BUFFER
.EXTERNAL GETVAL_BUFFER-BUFFER_END
ext_buffer      .FILL GETVAL_BUFFER-BUFFER
ext_buffer_end  .FILL GETVAL_BUFFER-BUFFER_END

.EXTERNAL GETLINE-GETLINE
.EXTERNAL FROMDEC-FROMDEC
.EXTERNAL TODEC-TODEC
sub_getline     .FILL GETLINE-GETLINE
sub_fromdec     .FILL FROMDEC-FROMDEC
sub_todec       .FILL TODEC-TODEC

.EXTERNAL to_qm_n-TO_QM_N
.EXTERNAL from_qm_n-FROM_QM_N
sub_to_qm_n     .FILL to_qm_n-TO_QM_N
sub_from_qm_n   .FILL from_qm_n-FROM_QM_N

;   ============================================================================
;   Subrutina: GETVAL (Migrada a ISA Grupo 21)
;       Obtiene un valor por teclado en un formato especifico, mostrando el valor
;       que se obtuvo realmente.
;
;   -> INPUT  [R0] n .
;   <- OUTPUT [R0] Qn.m obtenido, o parte entera obtenida (depende del formato).
;   <- OUTPUT [R1] cero, o parte fraccionaria obtenida (depende del formato).
;   ============================================================================
GETVAL                                  ;    
    STW R2, getval_r2                   ;
    STW R3, getval_r3                   ;
    STW R4, getval_r4                   ;
    STW R5, getval_r5                   ;
    STW R7, getval_r7                   ;

    STW R0, getval_n                    ;
    
    LDW R0, ext_buffer                  ;
    LDW R1, ext_buffer_end              ;
    LDW R2, sub_getline                 ;
    JSRR R2                             ;   [R0] buffer = getline()

    LDW R2, sub_fromdec                 ;
    JSRR R2                             ;   [R0, R1, R5] = [entero, fraccion, errores]

getval_get_int                          ;
    LDW R2, getval_n                    ;
    BRnp getval_get_dq16                ;   if n == 0:
    ADD R1, R1, #0                      ;
    BRzp getval_get_int_sk1             ;
    ADD R0, R0, #1                      ;
getval_get_int_sk1                      ;
    AND R1, R1, #0                      ;       fraccion = 0
    STW R0, getval_value_0              ;       [value_0] = entero
    STW R1, getval_value_1              ;       [value_1] = 0
    BRnzp getval_out                    ;

getval_get_dq16                         ;   
    ADD R2, R2, #-8                     ;
    ADD R2, R2, #-8                     ;   n - 16
    BRnp getval_get_qnm                 ;   elif n == 16:
    STW R0, getval_value_0              ;       [value_0] = entero
    STW R1, getval_value_1              ;       [value_1] = fraccion
    BRnzp getval_out                    ;

getval_get_qnm                          ;   else:
    LDW R2, getval_n                    ;
    LDW R3, sub_to_qm_n                 ;
    JSRR R3                             ;       [R0] qm_n = to_Qm_n(entero, fraccion, n)
    AND R1, R1, #0                      ;       fraccion = 0
    STW R0, getval_value_0              ;       [value_0] = qm_n
    STW R1, getval_value_1              ;       [value_1] = 0
    LDW R1, getval_n                    ;
    LDW R2, sub_from_qm_n               ;   
    JSRR R2                             ;       [R0, R1] = from_Qm_n(qm_n, n)

getval_out                              ;
    LDW R2, ext_buffer                  ;
    AND R3, R3, #0                      ;   # (R3 = formato)
    LDW R4, sub_todec                   ;
    JSRR R4                             ;   [R2] = buffer   # (con valor actualizado)

    LEA R0, getval_lbraket              ;
    PUTS                                ;
    ADD R0, R2, #0                      ;
    PUTS                                ;
    LEA R0, getval_rbraket              ;
    PUTS                                ;   print("[ " + buffer + " ]\n")

    LDW R0, getval_value_0              ;
    LDW R1, getval_value_1              ;
    LDW R2, getval_r2                   ;
    LDW R3, getval_r3                   ;
    LDW R4, getval_r4                   ;
    LDW R5, getval_r5                   ;
    LDW R7, getval_r7                   ;
    RET                                 ;


getval_lbraket      .STRINGZ "[ "
getval_rbraket      .STRINGZ " ]\n"
getval_n            .FILL #0
getval_value_0      .FILL #0
getval_value_1      .FILL #0
getval_r2           .FILL #0
getval_r3           .FILL #0
getval_r4           .FILL #0
getval_r5           .FILL #0
getval_r7           .FILL #0

.END