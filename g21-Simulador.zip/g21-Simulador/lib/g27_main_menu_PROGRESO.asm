.EXTERNAL GETCFILTERED-GETCFILTERED
.EXTERNAL PAUSE-PAUSE

.EXTERNAL FROM_QM_N-FROM_QM_N

.EXTERNAL GETVAL-GETVAL
.EXTERNAL OUTVAL-OUTVAL


;   ============================================================================
;   Subrutina: MAIN_MENU (Migrada a ISA Grupo 21 - Direccionable por Byte)
;       Estructura de cada NODO (5 palabras = 10 bytes, offsets en bytes):
;       +0 - Puntero al controlador
;       +2 - Puntero al Texto
;       +4 - Puntero al Filtro
;       +6 - Puntero al Vector de nodos Siguientes
;       +8 - Puntero a Direccion de la Subrutina
;   ============================================================================

MAIN_MENU                               ;
    STW R0, main_menu_r0                ;
    STW R1, main_menu_r1                ;
    STW R2, main_menu_r2                ;
    STW R3, main_menu_r3                ;
    STW R4, main_menu_r4                ;
    STW R5, main_menu_r5                ;
    STW R7, main_menu_r7                ;

    AND R1, R1, #0                      ;
    ADD R1, R1, #1                      ;
    STW R1, main_menu_op_verbose        ;   [verbose_op] = 1

    ADD R0, R0, #0                      ;
    BRz main_menu_sk1                   ;   if cursor_de_op:
    LDRW R1, R0, #0                     ;
    STW R1, main_menu_op_verbose        ;       [verbose_op] = cursor_de_op.peek()
    ADD R0, R0, #2                      ;       cursor_de_op.incr() (+2 bytes)

main_menu_sk1
    STW R0, main_menu_op_cursor         ;   [cursor_de_op] = cursor_de_op

    LDW R0, main_menu_state_initial     ;
    STW R0, main_menu_state             ;   [estado] = init
    LDRW R0, R0, #0                     ;
    JMP R0                              ;   goto init.controlador


;   ==- Cambio de estado al siguiente nodo -====================================
;   !! ANTES DE SALTAR AQUI, [R0] next_offset (indice de palabra -> *2 en bytes)
main_menu_swap_node                     ;
    LDW R5, main_menu_state             ;   [R5] nodo = [estado]
    LDRW R1, R5, #6                     ;   campo 3 (+6 bytes): nodo.next
    ADD R0, R0, R0                      ;   offset en bytes = next_offset * 2
    ADD R1, R1, R0                      ;
    LDRW R5, R1, #0                     ;   nodo = (nodo.next).peek(next_offset)
    STW R5, main_menu_state             ;   [estado] = nodo
    LDRW R0, R5, #0                     ;
    JMP R0                              ;   goto nodo.controlador


;   ==- Return -================================================================
main_menu_return                        ;
    LDW R0, main_menu_r0                ;
    LDW R1, main_menu_r1                ;
    LDW R2, main_menu_r2                ;
    LDW R3, main_menu_r3                ;
    LDW R4, main_menu_r4                ;
    LDW R5, main_menu_r5                ;
    LDW R7, main_menu_r7                ;
    RET                                 ;


;   ==- Variables cercanas al bloque superior -=================================
main_menu_op_verbose        .FILL #0
main_menu_op_cursor         .FILL #0
main_menu_state             .FILL #0
main_menu_state_initial     .FILL main_menu_init
main_menu_r0                .FILL #0
main_menu_r1                .FILL #0
main_menu_r2                .FILL #0
main_menu_r3                .FILL #0
main_menu_r4                .FILL #0
main_menu_r5                .FILL #0
main_menu_r7                .FILL #0
main_menu_op_table_ads      .FILL main_menu_op_table
mm_swap_node_top            .FILL main_menu_swap_node
sub_getcfiltered            .FILL GETCFILTERED-GETCFILTERED


;   ==- Controlador para mostrar menus -========================================
main_menu_show_menu                     ;
    LDW R1, main_menu_op_cursor         ;
    BRz main_menu_show_menu_sk1         ;   if [cursor_de_op]:
    LDRW R0, R1, #0                     ;       [R0] indice
    ADD R1, R1, #2                      ;       +2 bytes
    STW R1, main_menu_op_cursor         ;       [cursor_de_op].incr()

    LDW R5, main_menu_op_table_ads      ;
    ADD R0, R0, R0                      ;       indice * 2 bytes
    ADD R5, R5, R0                      ;
    LDRW R5, R5, #0                     ;
    STW R5, main_menu_state             ;       [estado] = tabla_de_nodos.peek(indice)

    LDRW R0, R5, #0                     ;
    JMP R0                              ;       goto nodo.controlador

main_menu_show_menu_sk1
    LDW R5, main_menu_state             ;   [R5] nodo = [estado]
    LDRW R0, R5, #2                     ;   campo 1 (+2 bytes): texto
    PUTS                                ;   print(nodo.texto)

    LDRW R0, R5, #4                     ;   campo 2 (+4 bytes): filtro
    LDW R1, sub_getcfiltered            ;
    JSRR R1                             ;   [R0] char = getcfiltered(nodo.filtro)

    LDW R1, mm_neg_97                   ;   -97 (-'a')
    ADD R2, R0, R1                      ;
    BRn mm_chk_upper                    ;   if char >= 'a':
    ADD R0, R2, #5                      ;
    ADD R0, R0, #5                      ;       R0 = (char - 'a') + 10
    BRnzp mm_do_swap                    ;

mm_chk_upper
    LDW R1, mm_neg_65                   ;   -65 (-'A')
    ADD R2, R0, R1                      ;
    BRn mm_chk_digit                    ;   if char >= 'A':
    ADD R0, R2, #5                      ;
    ADD R0, R0, #5                      ;       R0 = (char - 'A') + 10
    BRnzp mm_do_swap                    ;

mm_chk_digit
    LDW R1, mm_neg_48                   ;   -48 (-'0')
    ADD R0, R0, R1                      ;       R0 = char - '0'

mm_do_swap
    LDW R1, mm_swap_node_top            ;
    JMP R1                              ;   # Cambio de nodo (offset = valor)

mm_neg_48                   .FILL #-48
mm_neg_65                   .FILL #-65
mm_neg_97                   .FILL #-97


;   ==- Controladores de formato Q (bloque 1) -=================================
main_menu_one_int_noresult
    LDW R0, mm_0
    LDW R1, mm_neg_1
    LDW R2, mm_neg_1
    LDW R3, mm_call_ads
    JMP R3

main_menu_one_int_result_q12
    LDW R0, mm_0
    LDW R1, mm_neg_1
    LDW R2, mm_12
    LDW R3, mm_call_ads
    JMP R3

main_menu_two_int
    LDW R0, mm_0
    LDW R1, mm_0
    LDW R2, mm_0
    LDW R3, mm_call_ads
    JMP R3

main_menu_one_q12
    LDW R0, mm_12
    LDW R1, mm_neg_1
    LDW R2, mm_12
    LDW R3, mm_call_ads
    JMP R3

main_menu_one_q12_result_q8
    LDW R0, mm_12
    LDW R1, mm_neg_1
    LDW R2, mm_8
    LDW R3, mm_call_ads
    JMP R3

main_menu_one_q12_result_q14
    LDW R0, mm_12
    LDW R1, mm_neg_1
    LDW R2, mm_14
    LDW R3, mm_call_ads
    JMP R3

main_menu_one_q7
    LDW R0, mm_7
    LDW R1, mm_neg_1
    LDW R2, mm_7
    LDW R3, mm_call_ads
    JMP R3


;   ==- Constantes en punto medio de los controladores Q -======================
mm_call_ads                 .FILL main_menu_call
mm_neg_1                    .FILL #-1
mm_0                        .FILL #0
mm_7                        .FILL #7
mm_8                        .FILL #8
mm_9                        .FILL #9
mm_12                       .FILL #12
mm_14                       .FILL #14
mm_15                       .FILL #15
mm_16                       .FILL #16


;   ==- Controladores de formato Q (bloque 2) -=================================
main_menu_one_q8
    LDW R0, mm_8
    LDW R1, mm_neg_1
    LDW R2, mm_8
    LDW R3, mm_call_ads
    JMP R3

main_menu_q8_int_result_q8
    LDW R0, mm_8
    LDW R1, mm_0
    LDW R2, mm_8
    LDW R3, mm_call_ads
    JMP R3

main_menu_one_q8_result_q9
    LDW R0, mm_8
    LDW R1, mm_neg_1
    LDW R2, mm_9
    LDW R3, mm_call_ads
    JMP R3

main_menu_two_q8
    LDW R0, mm_8
    LDW R1, mm_8
    LDW R2, mm_8
    LDW R3, mm_call_ads
    JMP R3

main_menu_two_q15
    LDW R0, mm_15
    LDW R1, mm_15
    LDW R2, mm_15
    LDW R3, mm_call_ads
    JMP R3

main_menu_one_dq16
    LDW R0, mm_16
    LDW R1, mm_neg_1
    LDW R2, mm_16
    LDW R3, mm_call_ads
    JMP R3

main_menu_two_q8_result_dq16
    LDW R0, mm_8
    LDW R1, mm_8
    LDW R2, mm_16
    LDW R3, mm_call_ads
    JMP R3


;   ==- Controlador subrutinas (modo interactivo) -=============================
main_menu_call
    LDW R5, mm_vars_ptr                 ;
    LDRW R4, R5, #2                     ;   [R4] = op_cursor (+2)
    BRz main_menu_call_interactive      ;
    LDW R3, mm_call_op_ads              ;
    JMP R3

main_menu_call_interactive
    STW R0, main_menu_aux_2             ;
    STW R1, main_menu_aux_3             ;
    STW R2, main_menu_aux_4             ;

    LDRW R5, R5, #4                     ;
    LDRW R0, R5, #2                     ;
    PUTS                                ;

main_menu_call_get1                     ;
    LDW R0, main_menu_aux_2             ;
    BRn main_menu_call_get2             ;

    LDW R0, main_menu_prompt_qa_vec     ;
    LDW R1, main_menu_aux_2             ;
    ADD R1, R1, R1                      ;
    ADD R0, R0, R1                      ;
    LDRW R0, R0, #0                     ;
    PUTS                                ;

    LDW R0, main_menu_aux_2             ;
    LDW R1, sub_getval                  ;
    JSRR R1                             ;
    STW R0, main_menu_aux_0             ;
    STW R1, main_menu_aux_1             ;

main_menu_call_get2
    LDW R0, main_menu_aux_3             ;
    BRn main_menu_call_exec             ;

    LDW R0, main_menu_prompt_qb_vec     ;
    LDW R1, main_menu_aux_3             ;
    ADD R1, R1, R1                      ;
    ADD R0, R0, R1                      ;
    LDRW R0, R0, #0                     ;
    PUTS                                ;

    LDW R0, main_menu_aux_3             ;
    LDW R1, sub_getval                  ;
    JSRR R1                             ;
    STW R0, main_menu_aux_1             ;

main_menu_call_exec
    LDW R0, main_menu_aux_0             ;
    LDW R1, main_menu_aux_1             ;
    LDRW R2, R5, #8                     ;
    LDRW R2, R2, #0                     ;
    JSRR R2                             ;
    STW R0, main_menu_aux_0             ;
    STW R1, main_menu_aux_1             ;

main_menu_call_out                      ;
    LDW R0, main_menu_aux_4             ;
    BRn main_menu_call_next             ;

    LDW R0, main_menu_prompt_q_vec      ;
    LDW R1, main_menu_aux_4             ;
    ADD R1, R1, R1                      ;
    ADD R0, R0, R1                      ;
    LDRW R0, R0, #0                     ;
    PUTS                                ;

    LDW R0, main_menu_aux_0             ;
    LDW R1, main_menu_aux_1             ;
    LDW R2, main_menu_aux_4             ;
    LDW R3, sub_outval                  ;
    JSRR R3                             ;

main_menu_call_next
    LDW R0, sub_pause                   ;
    JSRR R0                             ;

    AND R0, R0, #0                      ;
    LDW R1, main_menu_swap_node_ads     ;
    JMP R1                              ;


;   ==- Variables cercanas a main_menu_call y main_menu_call_op -===============
mm_vars_ptr                 .FILL main_menu_op_verbose
mm_call_op_ads              .FILL main_menu_call_op
main_menu_prompt_qa_vec     .FILL main_menu_prompt_qa_text_vec
main_menu_prompt_qb_vec     .FILL main_menu_prompt_qb_text_vec
main_menu_prompt_q_vec      .FILL main_menu_prompt_q_text_vec
main_menu_aux_0             .FILL #0
main_menu_aux_1             .FILL #0
main_menu_aux_2             .FILL #0
main_menu_aux_3             .FILL #0
main_menu_aux_4             .FILL #0
main_menu_swap_node_ads     .FILL main_menu_swap_node
sub_pause                   .FILL PAUSE-PAUSE
sub_from_qm_n               .FILL FROM_QM_N-FROM_QM_N
sub_getval                  .FILL GETVAL-GETVAL
sub_outval                  .FILL OUTVAL-OUTVAL


;   ==- Controlador subrutinas OPERACION -=====================================
main_menu_call_op
    STW R0, main_menu_aux_2             ;
    STW R1, main_menu_aux_3             ;
    STW R2, main_menu_aux_4             ;

    LDW R3, mm_vars_ptr                 ;
    LDRW R5, R3, #4                     ;
    LDRW R4, R3, #2                     ;

    LDRW R0, R4, #0                     ;
    STW R0, main_menu_aux_0             ;
    LDRW R0, R4, #2                     ;
    STW R0, main_menu_aux_1             ;

    LDRW R0, R3, #0                     ;
    BRz main_menu_call_op_exec          ;

main_menu_call_op_show_title            ;
    LDRW R0, R5, #2                     ;
    PUTS                                ;

main_menu_call_op_show1                 ;
    LDW R0, main_menu_aux_2             ;
    BRn main_menu_call_op_show2         ;

    LDW R0, main_menu_prompt_q_vec      ;
    LDW R1, main_menu_aux_2             ;
    ADD R1, R1, R1                      ;
    ADD R0, R0, R1                      ;
    LDRW R0, R0, #0                     ;
    PUTS                                ;

    LDW R0, main_menu_aux_0             ;
    LDW R1, main_menu_aux_1             ;
    LDW R2, main_menu_aux_2             ;
    LDW R3, sub_outval                  ;
    JSRR R3                             ;

main_menu_call_op_show2                 ;
    LDW R0, main_menu_aux_3             ;
    BRn main_menu_call_op_exec          ;

    LDW R0, main_menu_prompt_q_vec      ;
    LDW R1, main_menu_aux_3             ;
    ADD R1, R1, R1                      ;
    ADD R0, R0, R1                      ;
    LDRW R0, R0, #0                     ;
    PUTS                                ;

    LDW R0, main_menu_aux_1             ;
    AND R1, R1, #0                      ;
    LDW R2, main_menu_aux_3             ;
    LDW R3, sub_outval                  ;
    JSRR R3                             ;

main_menu_call_op_exec
    LDW R3, mm_aux_ptr_op               ;
    LDRW R0, R3, #0                     ;
    LDRW R1, R3, #2                     ;
    LDRW R2, R5, #8                     ;
    LDRW R2, R2, #0                     ;
    JSRR R2                             ;
    LDW R3, mm_aux_ptr_op               ;
    STRW R0, R3, #0                     ;
    STRW R1, R3, #2                     ;

    LDW R3, mm_vars_ptr_op              ;
    LDRW R0, R3, #0                     ;
    BRz main_menu_call_op_save_result   ;

main_menu_call_op_show_res              ;
    LDW R3, mm_aux_ptr_op               ;
    LDRW R0, R3, #8                     ;
    BRn main_menu_call_op_save_result   ;

    LDW R0, mm_q_vec_op                 ;
    LDRW R1, R3, #8                     ;
    ADD R1, R1, R1                      ;
    ADD R0, R0, R1                      ;
    LDRW R0, R0, #0                     ;
    PUTS                                ;

    LDW R3, mm_aux_ptr_op               ;
    LDRW R0, R3, #0                     ;
    LDRW R1, R3, #2                     ;
    LDRW R2, R3, #8                     ;
    LDW R3, sub_outval_op               ;
    JSRR R3                             ;

main_menu_call_op_save_result           ;
    LDW R3, mm_aux_ptr_op               ;
    LDRW R0, R3, #8                     ;
    LDW R1, mm_16_op                    ;
    SUB R0, R0, R1                      ;
    BRz main_menu_call_op_save_sk1      ;
    AND R0, R0, #0                      ;
    STRW R0, R3, #2                     ;

main_menu_call_op_save_sk1              ;
    LDRW R0, R3, #0                     ;
    LDRW R1, R3, #2                     ;
    STRW R0, R4, #4                     ;
    STRW R1, R4, #6                     ;

    ADD R4, R4, #4                      ;
    ADD R4, R4, #4                      ;
    LDW R3, mm_vars_ptr_op              ;
    STRW R4, R3, #2                     ;

    AND R0, R0, #0                      ;
    LDW R1, mm_swap_node_op             ;
    JMP R1                              ;

mm_vars_ptr_op              .FILL main_menu_op_verbose
mm_aux_ptr_op               .FILL main_menu_aux_0
mm_q_vec_op                 .FILL main_menu_prompt_q_text_vec
sub_outval_op               .FILL OUTVAL-OUTVAL
mm_16_op                    .FILL #16
mm_swap_node_op             .FILL main_menu_swap_node


;   ============================================================================
;   ==- Prompt texts -==========================================================

main_menu_prompt_qa_text_vec    .FILL main_menu_prompt_q0a_text
                                .FILL main_menu_prompt_q1a_text
                                .FILL main_menu_prompt_q2a_text
                                .FILL main_menu_prompt_q3a_text
                                .FILL main_menu_prompt_q4a_text
                                .FILL main_menu_prompt_q5a_text
                                .FILL main_menu_prompt_q6a_text
                                .FILL main_menu_prompt_q7a_text
                                .FILL main_menu_prompt_q8a_text
                                .FILL main_menu_prompt_q9a_text
                                .FILL main_menu_prompt_q10a_text
                                .FILL main_menu_prompt_q11a_text
                                .FILL main_menu_prompt_q12a_text
                                .FILL main_menu_prompt_q13a_text
                                .FILL main_menu_prompt_q14a_text
                                .FILL main_menu_prompt_q15a_text
                                .FILL main_menu_prompt_q16a_text
main_menu_prompt_qb_text_vec    .FILL main_menu_prompt_q0b_text
                                .FILL main_menu_prompt_q1b_text
                                .FILL main_menu_prompt_q2b_text
                                .FILL main_menu_prompt_q3b_text
                                .FILL main_menu_prompt_q4b_text
                                .FILL main_menu_prompt_q5b_text
                                .FILL main_menu_prompt_q6b_text
                                .FILL main_menu_prompt_q7b_text
                                .FILL main_menu_prompt_q8b_text
                                .FILL main_menu_prompt_q9b_text
                                .FILL main_menu_prompt_q10b_text
                                .FILL main_menu_prompt_q11b_text
                                .FILL main_menu_prompt_q12b_text
                                .FILL main_menu_prompt_q13b_text
                                .FILL main_menu_prompt_q14b_text
                                .FILL main_menu_prompt_q15b_text
                                .FILL main_menu_prompt_q16b_text
main_menu_prompt_q_text_vec     .FILL main_menu_prompt_q0_text
                                .FILL main_menu_prompt_q1_text
                                .FILL main_menu_prompt_q2_text
                                .FILL main_menu_prompt_q3_text
                                .FILL main_menu_prompt_q4_text
                                .FILL main_menu_prompt_q5_text
                                .FILL main_menu_prompt_q6_text
                                .FILL main_menu_prompt_q7_text
                                .FILL main_menu_prompt_q8_text
                                .FILL main_menu_prompt_q9_text
                                .FILL main_menu_prompt_q10_text
                                .FILL main_menu_prompt_q11_text
                                .FILL main_menu_prompt_q12_text
                                .FILL main_menu_prompt_q13_text
                                .FILL main_menu_prompt_q14_text
                                .FILL main_menu_prompt_q15_text
                                .FILL main_menu_prompt_q16_text

main_menu_prompt_q0a_text       .STRINGZ "a (int) > "
main_menu_prompt_q1a_text       .STRINGZ "a (Q14.1) > "
main_menu_prompt_q2a_text       .STRINGZ "a (Q13.2) > "
main_menu_prompt_q3a_text       .STRINGZ "a (Q12.3) > "
main_menu_prompt_q4a_text       .STRINGZ "a (Q11.4) > "
main_menu_prompt_q5a_text       .STRINGZ "a (Q10.5) > "
main_menu_prompt_q6a_text       .STRINGZ "a (Q9.6) > "
main_menu_prompt_q7a_text       .STRINGZ "a (Q8.7) > "
main_menu_prompt_q8a_text       .STRINGZ "a (Q7.8) > "
main_menu_prompt_q9a_text       .STRINGZ "a (Q6.9) > "
main_menu_prompt_q10a_text      .STRINGZ "a (Q5.10) > "
main_menu_prompt_q11a_text      .STRINGZ "a (Q4.11) > "
main_menu_prompt_q12a_text      .STRINGZ "a (Q3.12) > "
main_menu_prompt_q13a_text      .STRINGZ "a (Q2.13) > "
main_menu_prompt_q14a_text      .STRINGZ "a (Q1.14) > "
main_menu_prompt_q15a_text      .STRINGZ "a (Q0.15) > "
main_menu_prompt_q16a_text      .STRINGZ "a (Q15.16) > "
main_menu_prompt_q0b_text       .STRINGZ "b (int) > "
main_menu_prompt_q1b_text       .STRINGZ "b (Q14.1) > "
main_menu_prompt_q2b_text       .STRINGZ "b (Q13.2) > "
main_menu_prompt_q3b_text       .STRINGZ "b (Q12.3) > "
main_menu_prompt_q4b_text       .STRINGZ "b (Q11.4) > "
main_menu_prompt_q5b_text       .STRINGZ "b (Q10.5) > "
main_menu_prompt_q6b_text       .STRINGZ "b (Q9.6) > "
main_menu_prompt_q7b_text       .STRINGZ "b (Q8.7) > "
main_menu_prompt_q8b_text       .STRINGZ "b (Q7.8) > "
main_menu_prompt_q9b_text       .STRINGZ "b (Q6.9) > "
main_menu_prompt_q10b_text      .STRINGZ "b (Q5.10) > "
main_menu_prompt_q11b_text      .STRINGZ "b (Q4.11) > "
main_menu_prompt_q12b_text      .STRINGZ "b (Q3.12) > "
main_menu_prompt_q13b_text      .STRINGZ "b (Q2.13) > "
main_menu_prompt_q14b_text      .STRINGZ "b (Q1.14) > "
main_menu_prompt_q15b_text      .STRINGZ "b (Q0.15) > "
main_menu_prompt_q16b_text      .STRINGZ "b (Q15.16) > "
main_menu_prompt_q0_text        .STRINGZ "(int) "
main_menu_prompt_q1_text        .STRINGZ "(Q14.1) "
main_menu_prompt_q2_text        .STRINGZ "(Q13.2) "
main_menu_prompt_q3_text        .STRINGZ "(Q12.3) "
main_menu_prompt_q4_text        .STRINGZ "(Q11.4) "
main_menu_prompt_q5_text        .STRINGZ "(Q10.5) "
main_menu_prompt_q6_text        .STRINGZ "(Q9.6) "
main_menu_prompt_q7_text        .STRINGZ "(Q8.7) "
main_menu_prompt_q8_text        .STRINGZ "(Q7.8) "
main_menu_prompt_q9_text        .STRINGZ "(Q6.9) "
main_menu_prompt_q10_text       .STRINGZ "(Q5.10) "
main_menu_prompt_q11_text       .STRINGZ "(Q4.11) "
main_menu_prompt_q12_text       .STRINGZ "(Q3.12) "
main_menu_prompt_q13_text       .STRINGZ "(Q2.13) "
main_menu_prompt_q14_text       .STRINGZ "(Q1.14) "
main_menu_prompt_q15_text       .STRINGZ "(Q0.15) "
main_menu_prompt_q16_text       .STRINGZ "(Q15.16) "

;   ============================================================================
;   ==- TABLA DEL VECTOR DE OPERACIONES -=======================================
main_menu_op_table          .FILL main_menu_end
                            .FILL main_menu_argrd
                            .FILL main_menu_sin_taylor
                            .FILL main_menu_sin_table
                            .FILL main_menu_sin_cheb
                            .FILL main_menu_cos
                            .FILL main_menu_base_hex
                            .FILL main_menu_base_bin
                            .FILL main_menu_sqrt_nonres
                            .FILL main_menu_sqrt_nr
                            .FILL main_menu_exp
                            .FILL main_menu_pow_mults
                            .FILL main_menu_pow_expbin
                            .FILL main_menu_mult_cordic
                            .FILL main_menu_mult_basic
                            .FILL main_menu_mult_booth
                            .FILL main_menu_div_long
                            .FILL main_menu_div_nr
                            .FILL main_menu_div_cordic
                            .FILL main_menu_log_borch
                            .FILL main_menu_log_cordic
                            .FILL main_menu_mcd
                            .FILL main_menu_mcm
                            .FILL main_menu_qtoq

;   ============================================================================
;   ==- NODOS -=================================================================

main_menu_init              .FILL main_menu_show_menu
                            .FILL main_menu_init_text
                            .FILL main_menu_init_filter
                            .FILL main_menu_init_next
                            .FILL #0
main_menu_init_text         .STRINGZ "\n\n==CALCULADORA ARQUITECTURA 2026==\n[7] x      [8] /      [9] Log    [a] MCD\n[4] sqrt   [5] exp    [6] pow    [b] MCM\n[1] sin    [2] cos    [3] base   [c] Q3.12 -> Q7.8\n[0] Reduccion de argumento       [d] (salir)\n"
main_menu_init_filter       .STRINGZ "09adAD"
main_menu_init_next         .FILL main_menu_argrd
                            .FILL main_menu_sin
                            .FILL main_menu_cos
                            .FILL main_menu_base
                            .FILL main_menu_sqrt
                            .FILL main_menu_exp
                            .FILL main_menu_pow
                            .FILL main_menu_mult
                            .FILL main_menu_div
                            .FILL main_menu_log
                            .FILL main_menu_mcd
                            .FILL main_menu_mcm
                            .FILL main_menu_qtoq
                            .FILL main_menu_end

;   ============================================================================
main_menu_end               .FILL main_menu_return

;   ============================================================================
main_menu_argrd             .FILL main_menu_one_q12
                            .FILL main_menu_argrd_text
                            .FILL #0
                            .FILL main_menu_argrd_next
                            .FILL main_menu_sub_argrd
main_menu_argrd_text        .STRINGZ "\n\n==REDUCCION DE ARGUMENTO (CORDIC)==\n"
main_menu_argrd_next        .FILL main_menu_init

;   ============================================================================
main_menu_sin               .FILL main_menu_show_menu
                            .FILL main_menu_sin_text
                            .FILL main_menu_sin_filter
                            .FILL main_menu_sin_next
                            .FILL #0
main_menu_sin_text          .STRINGZ "\n\n==SENO TRIGONOMETRICO==\n[0] TAYLOR\n[1] TABLE\n[2] CHEBYSHEV-PADE\n"
main_menu_sin_filter        .STRINGZ "02"
main_menu_sin_next          .FILL main_menu_sin_taylor
                            .FILL main_menu_sin_table
                            .FILL main_menu_sin_cheb
;   ----------------------------------------------------------------------------
main_menu_sin_taylor        .FILL main_menu_one_int_result_q12
                            .FILL main_menu_sin_taylor_text
                            .FILL #0
                            .FILL main_menu_sin_taylor_next
                            .FILL main_menu_sub_sin_taylor
main_menu_sin_taylor_text   .STRINGZ "\n\n==SENO TRIGONOMETRICO (TAYLOR)==\n"
main_menu_sin_taylor_next   .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_sin_table         .FILL main_menu_one_q12_result_q14
                            .FILL main_menu_sin_table_text
                            .FILL #0
                            .FILL main_menu_sin_table_next
                            .FILL main_menu_sub_sin_table
main_menu_sin_table_text    .STRINGZ "\n\n==SENO TRIGONOMETRICO (TABLE)==\n"
main_menu_sin_table_next    .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_sin_cheb          .FILL main_menu_one_q12_result_q14
                            .FILL main_menu_sin_cheb_text
                            .FILL #0
                            .FILL main_menu_sin_cheb_next
                            .FILL main_menu_sub_sin_cheb
main_menu_sin_cheb_text     .STRINGZ "\n\n==SENO TRIGONOMETRICO (CHEVYSHEV-PADE)==\n"
main_menu_sin_cheb_next     .FILL main_menu_init

;   ============================================================================
main_menu_cos               .FILL main_menu_one_q12_result_q14
                            .FILL main_menu_cos_text
                            .FILL #0
                            .FILL main_menu_cos_next
                            .FILL main_menu_sub_cos
main_menu_cos_text          .STRINGZ "\n\n==COSENO TRIGONOMETRICO (TABLE)==\n"
main_menu_cos_next          .FILL main_menu_init

;   ============================================================================
main_menu_base              .FILL main_menu_show_menu
                            .FILL main_menu_base_text
                            .FILL main_menu_base_filter
                            .FILL main_menu_base_next
                            .FILL #0
main_menu_base_text         .STRINGZ "\n\n==EXPRESION CON BASE==\n[0] HEX\n[1] BIN\n"
main_menu_base_filter       .STRINGZ "01"
main_menu_base_next         .FILL main_menu_base_hex
                            .FILL main_menu_base_bin
;   ----------------------------------------------------------------------------
main_menu_base_hex          .FILL main_menu_one_int_noresult
                            .FILL main_menu_base_hex_text
                            .FILL #0
                            .FILL main_menu_base_hex_next
                            .FILL main_menu_sub_base_hex
main_menu_base_hex_text     .STRINGZ "\n\n==EXPRESION CON BASE (HEX)==\n"
main_menu_base_hex_next     .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_base_bin          .FILL main_menu_one_int_noresult
                            .FILL main_menu_base_bin_text
                            .FILL #0
                            .FILL main_menu_base_bin_next
                            .FILL main_menu_sub_base_bin
main_menu_base_bin_text     .STRINGZ "\n\n==EXPRESION CON BASE (BIN)==\n"
main_menu_base_bin_next     .FILL main_menu_init

;   ============================================================================
main_menu_sqrt              .FILL main_menu_show_menu
                            .FILL main_menu_sqrt_text
                            .FILL main_menu_sqrt_filter
                            .FILL main_menu_sqrt_next
                            .FILL #0
main_menu_sqrt_text         .STRINGZ "\n\n==RAIZ CUADRADA==\n[0] NON RESTORING\n[1] NEWTON-RAPHSON\n"
main_menu_sqrt_filter       .STRINGZ "01"
main_menu_sqrt_next         .FILL main_menu_sqrt_nonres
                            .FILL main_menu_sqrt_nr
;   ----------------------------------------------------------------------------
main_menu_sqrt_nonres       .FILL main_menu_one_q8_result_q9
                            .FILL main_menu_sqrt_nonres_text
                            .FILL #0
                            .FILL main_menu_sqrt_nonres_next
                            .FILL main_menu_sub_sqrt_nonres
main_menu_sqrt_nonres_text  .STRINGZ "\n\n==RAIZ CUADRADA (NON RESTORING)==\n"
main_menu_sqrt_nonres_next  .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_sqrt_nr           .FILL main_menu_one_dq16
                            .FILL main_menu_sqrt_nr_text
                            .FILL #0
                            .FILL main_menu_sqrt_nr_next
                            .FILL main_menu_sub_sqrt_nr
main_menu_sqrt_nr_text      .STRINGZ "\n\n==RAIZ CUADRADA (NEWTON-RAPHSON)==\n"
main_menu_sqrt_nr_next      .FILL main_menu_init

;   ============================================================================
main_menu_exp               .FILL main_menu_one_q12_result_q8
                            .FILL main_menu_exp_text
                            .FILL #0
                            .FILL main_menu_exp_next
                            .FILL main_menu_sub_exp
main_menu_exp_text          .STRINGZ "\n\n==EXPONENCIACION==\n"
main_menu_exp_next          .FILL main_menu_init

;   ============================================================================
main_menu_pow               .FILL main_menu_show_menu
                            .FILL main_menu_pow_text
                            .FILL main_menu_pow_filter
                            .FILL main_menu_pow_next
                            .FILL #0
main_menu_pow_text          .STRINGZ "\n\n==POTENCIACION==\n[0] MULTIPLICACIONES SUCESIVAS\n[1] EXP BINARIA\n"
main_menu_pow_filter        .STRINGZ "01"
main_menu_pow_next          .FILL main_menu_pow_mults
                            .FILL main_menu_pow_expbin
;   ----------------------------------------------------------------------------
main_menu_pow_mults         .FILL main_menu_q8_int_result_q8
                            .FILL main_menu_pow_mults_text
                            .FILL #0
                            .FILL main_menu_pow_mults_next
                            .FILL main_menu_sub_pow_mults
main_menu_pow_mults_text    .STRINGZ "\n\n==POTENCIACION (MULTIPLICACIONES SUCESIVAS)==\n"
main_menu_pow_mults_next    .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_pow_expbin        .FILL main_menu_two_int
                            .FILL main_menu_pow_expbin_text
                            .FILL #0
                            .FILL main_menu_pow_expbin_next
                            .FILL main_menu_sub_pow_expbin
main_menu_pow_expbin_text   .STRINGZ "\n\n==POTENCIACION (EXPONENCIACION BINARIA)==\n"
main_menu_pow_expbin_next   .FILL main_menu_init

;   ============================================================================
main_menu_mult              .FILL main_menu_show_menu
                            .FILL main_menu_mult_text
                            .FILL main_menu_mult_filter
                            .FILL main_menu_mult_next
                            .FILL #0
main_menu_mult_text         .STRINGZ "\n\n==MULTIPLICACION==\n[0] CORDIC\n[1] BASIC\n[2] BOOTH\n"
main_menu_mult_filter       .STRINGZ "02"
main_menu_mult_next         .FILL main_menu_mult_cordic
                            .FILL main_menu_mult_basic
                            .FILL main_menu_mult_booth
;   ----------------------------------------------------------------------------
main_menu_mult_cordic       .FILL main_menu_two_q8
                            .FILL main_menu_mult_cordic_text
                            .FILL #0
                            .FILL main_menu_mult_cordic_next
                            .FILL main_menu_sub_mult_cordic
main_menu_mult_cordic_text  .STRINGZ "\n\n==MULTIPLICACION (CORDIC)==\n"
main_menu_mult_cordic_next  .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_mult_basic        .FILL main_menu_two_q8_result_dq16
                            .FILL main_menu_mult_basic_text
                            .FILL #0
                            .FILL main_menu_mult_basic_next
                            .FILL main_menu_sub_mult_basic
main_menu_mult_basic_text   .STRINGZ "\n\n==MULTIPLICACION (BASIC)==\n"
main_menu_mult_basic_next   .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_mult_booth        .FILL main_menu_two_q8
                            .FILL main_menu_mult_booth_text
                            .FILL #0
                            .FILL main_menu_mult_booth_next
                            .FILL main_menu_sub_mult_booth
main_menu_mult_booth_text   .STRINGZ "\n\n==MULTIPLICACION (BOOTH)==\n"
main_menu_mult_booth_next   .FILL main_menu_init

;   ============================================================================
main_menu_div               .FILL main_menu_show_menu
                            .FILL main_menu_div_text
                            .FILL main_menu_div_filter
                            .FILL main_menu_div_next
                            .FILL #0
main_menu_div_text          .STRINGZ "\n\n==DIVISION==\n[0] LONG DIVISION\n[1] NEWTON-RAPHSON\n[2] CORDIC\n"
main_menu_div_filter        .STRINGZ "02"
main_menu_div_next          .FILL main_menu_div_long
                            .FILL main_menu_div_nr
                            .FILL main_menu_div_cordic
;   ----------------------------------------------------------------------------
main_menu_div_long          .FILL main_menu_two_q8
                            .FILL main_menu_div_long_text
                            .FILL #0
                            .FILL main_menu_div_long_next
                            .FILL main_menu_sub_div_long
main_menu_div_long_text     .STRINGZ "\n\n==DIVISION (LONG DIVISION)==\n"
main_menu_div_long_next     .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_div_nr            .FILL main_menu_two_q8
                            .FILL main_menu_div_nr_text
                            .FILL #0
                            .FILL main_menu_div_nr_next
                            .FILL main_menu_sub_div_nr
main_menu_div_nr_text       .STRINGZ "\n\n==DIVISION (NEWTON-RAPHSON)==\n"
main_menu_div_nr_next       .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_div_cordic        .FILL main_menu_two_q15
                            .FILL main_menu_div_cordic_text
                            .FILL #0
                            .FILL main_menu_div_cordic_next
                            .FILL main_menu_sub_div_cordic
main_menu_div_cordic_text   .STRINGZ "\n\n==DIVISION (CORDIC)==\n"
main_menu_div_cordic_next   .FILL main_menu_init

;   ============================================================================
main_menu_log               .FILL main_menu_show_menu
                            .FILL main_menu_log_text
                            .FILL main_menu_log_filter
                            .FILL main_menu_log_next
                            .FILL #0
main_menu_log_text          .STRINGZ "\n\n==LOGARITMO==\n[0] BORCHARDT\n[1] CORDIC\n"
main_menu_log_filter        .STRINGZ "01"
main_menu_log_next          .FILL main_menu_log_borch
                            .FILL main_menu_log_cordic
;   ----------------------------------------------------------------------------
main_menu_log_borch         .FILL main_menu_one_q7
                            .FILL main_menu_log_borch_text
                            .FILL #0
                            .FILL main_menu_log_borch_next
                            .FILL main_menu_sub_log_borch
main_menu_log_borch_text    .STRINGZ "\n\n==LOGARITMO== (BORCHARDT)\n"
main_menu_log_borch_next    .FILL main_menu_init
;   ----------------------------------------------------------------------------
main_menu_log_cordic        .FILL main_menu_one_q12
                            .FILL main_menu_log_cordic_text
                            .FILL #0
                            .FILL main_menu_log_cordic_next
                            .FILL main_menu_sub_log_cordic
main_menu_log_cordic_text   .STRINGZ "\n\n==LOGARITMO== (CORDIC)\n"
main_menu_log_cordic_next   .FILL main_menu_init

;   ============================================================================
main_menu_mcd               .FILL main_menu_two_int
                            .FILL main_menu_mcd_text
                            .FILL #0
                            .FILL main_menu_mcd_next
                            .FILL main_menu_sub_mcd
main_menu_mcd_text          .STRINGZ "\n\n==MAXIMO COMUN DIVISOR==\n"
main_menu_mcd_next          .FILL main_menu_init

;   ============================================================================
main_menu_mcm               .FILL main_menu_two_int
                            .FILL main_menu_mcm_text
                            .FILL #0
                            .FILL main_menu_mcm_next
                            .FILL main_menu_sub_mcm
main_menu_mcm_text          .STRINGZ "\n\n==MINIMO COMUN MULTIPLO==\n"
main_menu_mcm_next          .FILL main_menu_init

;   ============================================================================
main_menu_qtoq              .FILL main_menu_one_q12_result_q8
                            .FILL main_menu_qtoq_text
                            .FILL #0
                            .FILL main_menu_qtoq_next
                            .FILL main_menu_sub_qtoq
main_menu_qtoq_text         .STRINGZ "\n\n==Q3.12 -> Q7.8==\n"
main_menu_qtoq_next         .FILL main_menu_init


;   ============================================================================
;   ==- SUBRUTINAS de las Funciones de la calculadora -=========================

.EXTERNAL cordic_division-CORDIC_DIV                              ; DIV CORDIC (Q15, Q15 -> Q15)
.EXTERNAL g21_senotaylor_subrutina-CALCULAR_SENO                  ; SIN TAYLOR (int -> Q12)
.EXTERNAL g3_MultiplicacionSHIFTandADD-MULTIPLICARSHIFTANDADD   ; MULT SHIFT ADD (Q8, Q8 -> DQ16)
.EXTERNAL g4_potencia-EXP_RAPIDA
.EXTERNAL potencia-Mul_Sucesiva_POW
.EXTERNAL g6_EXP-EXP_Q3_12
.EXTERNAL mcd-MCD
.EXTERNAL g7_mcm-MCM
.EXTERNAL g10_division_larga-DIV_LONG
.EXTERNAL g11_CORDICLog-CORDIC_LOG_BASE


main_menu_sub_mult_cordic   .FILL NULL_SUBRUTINE
main_menu_sub_mult_basic    .FILL g3_MultiplicacionSHIFTandADD-MULTIPLICARSHIFTANDADD
main_menu_sub_mult_booth    .FILL NULL_SUBRUTINE
main_menu_sub_div_long      .FILL g10_division_larga-DIV_LONG
main_menu_sub_div_nr        .FILL NULL_SUBRUTINE
main_menu_sub_div_cordic    .FILL cordic_division-CORDIC_DIV
main_menu_sub_log_borch     .FILL NULL_SUBRUTINE
main_menu_sub_log_cordic    .FILL g11_CORDICLog-CORDIC_LOG_BASE
main_menu_sub_sqrt_nonres   .FILL NULL_SUBRUTINE
main_menu_sub_sqrt_nr       .FILL NULL_SUBRUTINE
main_menu_sub_exp           .FILL g6_EXP-EXP_Q3_12
main_menu_sub_pow_mults     .FILL potencia-Mul_Sucesiva_POW
main_menu_sub_pow_expbin    .FILL g4_potencia-EXP_RAPIDA
main_menu_sub_sin_taylor    .FILL g21_senotaylor_subrutina-CALCULAR_SENO
main_menu_sub_sin_table     .FILL NULL_SUBRUTINE
main_menu_sub_sin_cheb      .FILL NULL_SUBRUTINE
main_menu_sub_cos           .FILL NULL_SUBRUTINE
main_menu_sub_base_hex      .FILL NULL_SUBRUTINE
main_menu_sub_base_bin      .FILL NULL_SUBRUTINE
main_menu_sub_mcd           .FILL mcd-MCD
main_menu_sub_mcm           .FILL g7_mcm-MCM
main_menu_sub_argrd         .FILL NULL_SUBRUTINE
main_menu_sub_qtoq          .FILL NULL_SUBRUTINE


; (subrutina valida, pero que no hace nada...)
NULL_SUBRUTINE
    STW R0, null_subrutine_r0
    STW R7, null_subrutine_r7
    LEA R0, null_subrutine_text
    PUTS
    LDW R0, null_subrutine_r0
    LDW R7, null_subrutine_r7
    RET
null_subrutine_r0   .FILL #0
null_subrutine_r7   .FILL #0
null_subrutine_text .STRINGZ "(se ejecutaria una subrutina...)\n"

.END