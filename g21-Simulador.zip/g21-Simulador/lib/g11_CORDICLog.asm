; =====================================================================
; SUBRUTINA CORDIC_LOG_BASE : logaritmo natural en Q3.12 (Grupo 11)
; Adaptado para ISA Grupo 21 (memoria byte-addressable Little-Endian)
;
;   Entrada : R0 = m  (Q3.12, 0 < m <= 7.9998 = x7FFF)
;   Salida  : R0 = ln(m) (Q3.12, rango representable -8.0 .. 7.99)
;   Conserva R1-R7 (usa pila R6 para resguardo). Sin .ORIG.
;   m <= 0  -> R0 = x8000 (-8.0, ln no definido)
;   m muy chico (ln(m) < -8) -> R0 = x8000 (saturado)
; =====================================================================

CORDIC_LOG_BASE
        ADD     R6, R6, #-2          ; resguardar R1..R5 y R7 en pila
        STRW    R1, R6, #0
        ADD     R6, R6, #-2
        STRW    R2, R6, #0
        ADD     R6, R6, #-2
        STRW    R3, R6, #0
        ADD     R6, R6, #-2
        STRW    R4, R6, #0
        ADD     R6, R6, #-2
        STRW    R5, R6, #0
        ADD     R6, R6, #-2
        STRW    R7, R6, #0

        ADD     R0, R0, #0
        BRp     M_VALIDO             ; m > 0: continuar

LOG_MIN_EARLY
        LDW     R0, MIN_Q12          ; m <= 0: devuelve x8000 (-8.0)
        BRnzp   LOG_EPILOGO

LOG_EPILOGO
        LDRW    R7, R6, #0
        ADD     R6, R6, #2
        LDRW    R5, R6, #0
        ADD     R6, R6, #2
        LDRW    R4, R6, #0
        ADD     R6, R6, #2
        LDRW    R3, R6, #0
        ADD     R6, R6, #2
        LDRW    R2, R6, #0
        ADD     R6, R6, #2
        LDRW    R1, R6, #0
        ADD     R6, R6, #2
        RET

; ---- Zona de datos intermedia (<= 120 bytes de todo acceso PC-relativo) ----
HALF_Q12    .FILL   x0800            ; 0.5 en Q3.12
NEG_HALF    .FILL   xF800            ; -0.5 en Q3.12
MIN_Q12     .FILL   x8000            ; -8.0 en Q3.12
var_k       .FILL   #0
var_xs      .FILL   #0
PTR_FIN     .FILL   FIN

M_VALIDO
        ; ---- normalizacion: llevar m a >= 0.5 (x0800) contando k
        AND     R5, R5, #0
        LDW     R4, NEG_HALF
NORM    ADD     R1, R0, R4
        BRzp    NORM_OK
        ADD     R0, R0, R0
        ADD     R5, R5, #1
        BRnzp   NORM
NORM_OK STW     R5, var_k

        ; ---- x = m/2 + 0.5 ; y = m/2 - 0.5 ; z = 0
        ASR     R0, R0, #1           ; R0 = m >> 1 (nativo G21, m > 0)
        LDW     R4, HALF_Q12
        ADD     R1, R0, R4           ; x = m/2 + 0.5
        SUB     R2, R0, R4           ; y = m/2 - 0.5 (resta nativa G21)
        AND     R3, R3, #0           ; z = 0
        AND     R4, R4, #0           ; indice de tabla (0..12)

ITER    LSL     R5, R4, #1           ; desplazamiento en bytes = indice * 2
        LEA     R0, SEQ_I
        ADD     R5, R0, R5
        LDRW    R5, R5, #0           ; R5 = i (0 = fin)
        BRz     SALTAR_FIN

        ADD     R0, R1, #0
        JSR     ASR_TRUNC            ; R0 = x >> i (truncado hacia cero)
        STW     R0, var_xs
        ADD     R0, R2, #0
        JSR     ASR_TRUNC            ; R0 = y >> i (ASR_TRUNC conserva R5)

        ADD     R2, R2, #0
        BRp     Y_POS

        ; y <= 0 : x += y>>i ; y += x>>i ; z -= atanh(2^-i)
        ADD     R1, R1, R0
        LDW     R0, var_xs
        ADD     R2, R2, R0
        LSL     R5, R4, #1           ; offset en bytes = indice * 2
        LEA     R0, LUT_ATANH
        ADD     R5, R0, R5
        LDRW    R5, R5, #0
        SUB     R3, R3, R5           ; z -= atanh
        BRnzp   NEXT

Y_POS   ; y > 0 : x -= y>>i ; y -= x>>i ; z += atanh(2^-i)
        SUB     R1, R1, R0
        LDW     R0, var_xs
        SUB     R2, R2, R0
        LSL     R5, R4, #1           ; offset en bytes = indice * 2
        LEA     R0, LUT_ATANH
        ADD     R5, R0, R5
        LDRW    R5, R5, #0
        ADD     R3, R3, R5           ; z += atanh

NEXT    ADD     R4, R4, #1
        BRnzp   ITER

SALTAR_FIN
        LDW     R0, PTR_FIN
        JMP     R0

; ---- Tablas de iteraciones y constantes atanh(2^-i)*4096 ----
SEQ_I       .FILL   #1
            .FILL   #2
            .FILL   #3
            .FILL   #4
            .FILL   #4               ; repeticion obligatoria
            .FILL   #5
            .FILL   #6
            .FILL   #7
            .FILL   #8
            .FILL   #9
            .FILL   #10
            .FILL   #11
            .FILL   #12
            .FILL   #0

LUT_ATANH   .FILL   #2250
            .FILL   #1046
            .FILL   #515
            .FILL   #256
            .FILL   #256
            .FILL   #128
            .FILL   #64
            .FILL   #32
            .FILL   #16
            .FILL   #8
            .FILL   #4
            .FILL   #2
            .FILL   #1

FIN     ADD     R3, R3, R3           ; 2*z = ln(m*2^k)
        LDW     R5, var_k_low
        BRz     FIN_OK
        ADD     R1, R5, #-7
        ADD     R1, R1, #-4          ; R1 = k - 11
        BRzp    LOG_SAT              ; k >= 11 : ln < -8, satura
        LDW     R1, LN2_Q12_LOW
RESTA   SUB     R3, R3, R1           ; ln(m) = ln(m*2^k) - k*ln2
        ADD     R5, R5, #-1
        BRp     RESTA
FIN_OK  ADD     R0, R3, #0
        LDW     R4, PTR_EPILOGO_LOW
        JMP     R4

LOG_SAT LDW     R0, MIN_Q12_LOW
        LDW     R4, PTR_EPILOGO_LOW
        JMP     R4

; ---- Constantes y variables locales cercanas a FIN / LOG_SAT ([-128..127] bytes) ----
var_k_low       .FILL   #0
LN2_Q12_LOW     .FILL   #2839        ; ln(2)*4096
MIN_Q12_LOW     .FILL   x8000        ; -8.0 en Q3.12
PTR_EPILOGO_LOW .FILL   LOG_EPILOGO

; ---------------------------------------------------------------------
; ASR_TRUNC: R0 = R0 >> R5 (1..15), redondeo hacia cero. Conserva R1-R5.
; ---------------------------------------------------------------------
ASR_TRUNC
        ADD     R6, R6, #-2
        STRW    R1, R6, #0
        ADD     R6, R6, #-2
        STRW    R2, R6, #0
        ADD     R6, R6, #-2
        STRW    R3, R6, #0

        AND     R1, R1, #0           ; bandera de negativo
        ADD     R0, R0, #0
        BRzp    A_POS
        NOT     R0, R0
        ADD     R0, R0, #1
        ADD     R1, R1, #1
A_POS   NOT     R3, R5
        ADD     R3, R3, #1           ; R3 = -n
        ADD     R3, R3, #7
        ADD     R3, R3, #7
        ADD     R3, R3, #2           ; R3 = 16 - n iteraciones
        AND     R2, R2, #0
A_LOOP  ADD     R2, R2, R2
        ADD     R0, R0, #0
        BRzp    A_Z
        ADD     R2, R2, #1
A_Z     ADD     R0, R0, R0
        ADD     R3, R3, #-1
        BRp     A_LOOP
        ADD     R0, R2, #0
        ADD     R1, R1, #0
        BRz     A_END
        NOT     R0, R0
        ADD     R0, R0, #1
A_END   LDRW    R3, R6, #0
        ADD     R6, R6, #2
        LDRW    R2, R6, #0
        ADD     R6, R6, #2
        LDRW    R1, R6, #0
        ADD     R6, R6, #2
        RET

        .END