; ============================================================================
; Modulo: mcd  (archivo mcd.asm)                      Grupo 7
; Maximo comun divisor de dos enteros con signo, en punto fijo Q15.0.
; Algoritmo: Euclides por restas sucesivas (se resta el menor del mayor hasta
; que ambos sean iguales; ese valor es el MCD).
;
; MCD
;   Entrada:  R0 = a, R1 = b  (enteros con signo, formato Q15.0,
;                              rango valido [-32767, 32767])
;   Salida:   R0 = MCD(|a|, |b|) en Q15.0, exacto, rango [0, 32767]
;                  MCD(0, b) = |b|, MCD(a, 0) = |a|, MCD(0, 0) = 0
;   Preserva: R1 a R3. R4, R5, R6 y R7 no se tocan.
; ============================================================================

MCD
        STW R1, mcd_guardado_r1
        STW R2, mcd_guardado_r2
        STW R3, mcd_guardado_r3

        ; Obtener |a| y |b| (actualizando flags antes de cada BRzp).
        ADD R0, R0, #0
        BRzp mcd_a_positivo
        NOT R0, R0
        ADD R0, R0, #1
mcd_a_positivo
        ADD R1, R1, #0
        BRzp mcd_b_positivo
        NOT R1, R1
        ADD R1, R1, #1
mcd_b_positivo

        ; Casos con cero.
        ADD R0, R0, #0
        BRz mcd_devolver_b
        ADD R1, R1, #0
        BRz mcd_fin

        ; R2 conserva -R1 para no recalcularlo en cada resta.
        NOT R2, R1
        ADD R2, R2, #1
        ADD R3, R0, R2
        BRz mcd_fin
        BRn mcd_r0_menor_r1

mcd_restar_r0
        ADD R0, R3, #0
        ADD R3, R0, R2
        BRp mcd_restar_r0
        BRz mcd_fin

mcd_r0_menor_r1
        ; Ahora se conserva -R0 y se resta R0 de R1.
        NOT R2, R0
        ADD R2, R2, #1
mcd_restar_r1
        ADD R1, R1, R2
        ADD R3, R1, R2
        BRp mcd_restar_r1
        BRz mcd_fin

        ; R1 quedo menor que R0: volver a restar sobre R0.
        NOT R2, R1
        ADD R2, R2, #1
        ADD R3, R0, R2
        BRp mcd_restar_r0
        BRz mcd_fin
        BRnzp mcd_r0_menor_r1

mcd_devolver_b
        ADD R0, R1, #0

mcd_fin
        LDW R1, mcd_guardado_r1
        LDW R2, mcd_guardado_r2
        LDW R3, mcd_guardado_r3
        ADD R0, R0, #0
        RET

; ---- zona de datos ----
mcd_guardado_r1    .FILL #0
mcd_guardado_r2    .FILL #0
mcd_guardado_r3    .FILL #0

.END