; LAB 3 - GRUPO 9 - SQRT Newton-Raphson reciproco (ISA Grupo 21)
; Entrada: R0 = x en Q7.8 con 4 <= x <= 16 (x0400..x1000)
; Salida:  R0 = aproximacion de sqrt(x) en Q7.8 (0 si fuera de rango)
; Conserva: R1..R7; actualiza CC al salir; retorna con RET.

SQ9_SAVE6_INI     .FILL #0
SQ9_PTR_DATOS_INI .FILL SQ9_DATOS
SQ9_NEGMIN_TOP    .FILL #-1024
SQ9_NEGMAX_TOP    .FILL #-4096

SQRT_NR_Q8
        STW R6, SQ9_SAVE6_INI
        LDW R6, SQ9_PTR_DATOS_INI
        STRW R1, R6, #0
        STRW R2, R6, #2
        STRW R3, R6, #4
        STRW R4, R6, #6
        STRW R5, R6, #8
        STRW R7, R6, #10
        STRW R0, R6, #12

        LDW R1, SQ9_NEGMIN_TOP
        ADD R2, R0, R1
        BRn SQ9_BAD_JMP
        LDW R1, SQ9_NEGMAX_TOP
        ADD R2, R0, R1
        BRp SQ9_BAD_JMP

        LDW R1, SQ9_SEED
        STRW R1, R6, #14
        LDW R1, SQ9_NITER
        STRW R1, R6, #16

SQ9_ITER
        LDRW R0, R6, #14
        LDRW R1, R6, #14
        JSR SQ9_MULQ
        STRW R0, R6, #18

        LDRW R0, R6, #12
        LDRW R1, R6, #18
        JSR SQ9_MULQ
        STRW R0, R6, #20

        LDW R0, SQ9_THREE
        LDRW R1, R6, #20
        NOT R1, R1
        ADD R1, R1, #1
        ADD R0, R0, R1
        STRW R0, R6, #22

        LDRW R1, R6, #14
        JSR SQ9_MULQ

        ADD R2, R0, #0
        ADD R2, R2, R2
        ADD R2, R2, R2
        ADD R2, R2, R2
        ADD R2, R2, R2
        ADD R2, R2, R2
        ADD R2, R2, R2
        ADD R2, R2, R2

        AND R1, R1, #0
        AND R3, R3, #0
        ADD R3, R3, #7
        ADD R3, R3, #1

SQ9_HALF
        ADD R1, R1, R1
        ADD R2, R2, #0
        BRzp SQ9_HALF_ZERO
        ADD R1, R1, #1
SQ9_HALF_ZERO
        ADD R2, R2, R2
        ADD R3, R3, #-1
        BRp SQ9_HALF
        STRW R1, R6, #14

        LDRW R1, R6, #16
        ADD R1, R1, #-1
        STRW R1, R6, #16
        BRp SQ9_ITER_JMP

        LDRW R0, R6, #12
        LDRW R1, R6, #14
        JSR SQ9_MULQ
        BRnzp SQ9_DONE

SQ9_ITER_JMP
        LDW R4, SQ9_PTR_ITER
        JMP R4

SQ9_BAD_JMP
        LDW R4, SQ9_PTR_BAD
        JMP R4

SQ9_BAD
        AND R0, R0, #0

SQ9_DONE
        LDW R6, SQ9_PTR_DATOS_FIN
        STRW R0, R6, #24
        LDRW R1, R6, #0
        LDRW R2, R6, #2
        LDRW R3, R6, #4
        LDRW R4, R6, #6
        LDRW R5, R6, #8
        LDRW R7, R6, #10
        LDW R6, SQ9_SAVE6_INI
        ADD R0, R0, #0
        RET

SQ9_PTR_ITER      .FILL SQ9_ITER
SQ9_PTR_BAD       .FILL SQ9_BAD
SQ9_PTR_DATOS_FIN .FILL SQ9_DATOS
SQ9_SEED          .FILL #64
SQ9_NITER         .FILL #6
SQ9_THREE         .FILL #768

; Bloque de trabajo indexado por R6 (offsets en bytes: 0, 2, 4, ..., 24)
SQ9_DATOS
        .FILL #0          ; +0:  R1 guardado
        .FILL #0          ; +2:  R2 guardado
        .FILL #0          ; +4:  R3 guardado
        .FILL #0          ; +6:  R4 guardado
        .FILL #0          ; +8:  R5 guardado
        .FILL #0          ; +10: R7 guardado
        .FILL #0          ; +12: X
        .FILL #0          ; +14: Y
        .FILL #0          ; +16: COUNT
        .FILL #0          ; +18: Y2
        .FILL #0          ; +20: XY2
        .FILL #0          ; +22: FACTOR
        .FILL #0          ; +24: RESULT

; MULQ: R0=a>=0, R1=b (0..128) en Q7.8 -> R0=floor(a*b/256)
SQ9_MULQ
        AND R2, R2, #0
        ADD R3, R0, #0
        LDW R4, SQ9_M_NEG256
SQ9_SPLIT
        ADD R5, R3, R4
        BRn SQ9_SPLIT_END
        ADD R3, R5, #0
        ADD R2, R2, #1
        BRnzp SQ9_SPLIT

SQ9_SPLIT_END
        STW R1, SQ9_M_B
        AND R0, R0, #0
        AND R5, R5, #0
        AND R4, R4, #0
        ADD R4, R4, #1

SQ9_BITS
        LDW R1, SQ9_M_B
        AND R1, R1, R4
        BRz SQ9_NO_ADD
        ADD R0, R0, R2
        ADD R5, R5, R3
SQ9_NO_ADD
        ADD R2, R2, R2
        ADD R3, R3, R3
        ADD R4, R4, R4
        LDW R1, SQ9_M_NEG256
        ADD R1, R4, R1
        BRn SQ9_BITS

        AND R2, R2, #0
        AND R3, R3, #0
        ADD R3, R3, #7
        ADD R3, R3, #1
SQ9_GET_HIGH
        ADD R2, R2, R2
        ADD R5, R5, #0
        BRzp SQ9_HIGH_ZERO
        ADD R2, R2, #1
SQ9_HIGH_ZERO
        ADD R5, R5, R5
        ADD R3, R3, #-1
        BRp SQ9_GET_HIGH
        ADD R0, R0, R2
        RET

SQ9_M_NEG256      .FILL #-256
SQ9_M_B           .FILL #0

.END