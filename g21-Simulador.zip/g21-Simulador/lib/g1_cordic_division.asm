; Modulo: cordic_division   (adaptado a ISA Grupo 21)
; Division por CORDIC (modo lineal, vectoring) en punto fijo Q15

CORDIC_DIV
        STW R2, guardado_r2
        STW R3, guardado_r3
        STW R4, guardado_r4

        ADD R2, R0, #0        ; R2 = P = y0
        AND R0, R0, #0        ; R0 = Z = 0

        ; R3 = -x0
        NOT R3, R1
        ADD R3, R3, #1

        ; Iteracion 0
        ADD R2, R2, #0
        BRp INI_NEG
        ADD R2, R2, R1        ; P <= 0 -> d = +1: P = P + x0
        ADD R0, R0, #-1       ; Z = -d = -1
        BRnzp INI_LOOP

INI_NEG
        ADD R2, R2, R3        ; P > 0 -> d = -1: P = P - x0
        ADD R0, R0, #1        ; Z = -d = +1

        ; Iteraciones 1 a 15
INI_LOOP
        LDW R4, const_15
LOOP
        ADD R2, R2, #0
        BRp PPOS
        ADD R2, R2, R2        ; P = 2P
        ADD R2, R2, R1        ; P = 2P + x0 (d = +1)
        ADD R0, R0, R0        ; Z = 2Z
        ADD R0, R0, #-1       ; Z = 2Z - 1
        BRnzp GOON

PPOS
        ADD R2, R2, R2        ; P = 2P
        ADD R2, R2, R3        ; P = 2P - x0 (d = -1)
        ADD R0, R0, R0        ; Z = 2Z
        ADD R0, R0, #1        ; Z = 2Z + 1

GOON
        ADD R4, R4, #-1
        BRp LOOP

        LDW R2, guardado_r2
        LDW R3, guardado_r3
        LDW R4, guardado_r4
        RET

const_15    .FILL #15
guardado_r2 .FILL #0
guardado_r3 .FILL #0
guardado_r4 .FILL #0