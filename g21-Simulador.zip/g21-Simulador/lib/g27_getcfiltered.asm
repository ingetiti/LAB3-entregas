;   ============================================================================
;   Subrutina: GETCFILTERED (Migrada a ISA Grupo 21 - Direccionable por Byte)
;       Obtiene un caracter, solo si cumple con el filtro.
;       El filtro es una cadena (null terminada) con pares de caracteres (1 byte c/u),
;       los cuales representaran un rango valido de caracteres. Del par, el primero
;       sera el minimo inclusive, y el segundo sera el maximo inclusive.
;       - Ejemplo: "09az" tomaria caracteres 0-9 y a-z unicamente.
;
;   -> INPUT  [R0] Puntero al filtro
;   <- OUTPUT [R0] Caracter capturado
;   ============================================================================

GETCFILTERED                            ;
    STW R0, getcfiltered_filter_beg     ;   [filtro_beg] = filtro
    STW R1, getcfiltered_r1             ;
    STW R2, getcfiltered_r2             ;
    STW R3, getcfiltered_r3             ;
    STW R7, getcfiltered_r7             ;   (necesario porque usamos GETC)

getcfiltered_beg                        ;   while True:
    LDW R1, getcfiltered_filter_beg     ;       [R1] filtro
    GETC                                ;       [R0] char

getcfiltered_loop                       ;       while True:
    AND R2, R2, #0                      ;           limpia byte alto de R2
    LDBL R2, R1, #0                     ;           [R2] char_a = filtro[0] (1 byte)
    BRz getcfiltered_beg                ;           if char_a == 0: break

    AND R3, R3, #0                      ;           limpia byte alto de R3
    LDBL R3, R1, #1                     ;           [R3] char_b = filtro[1] (1 byte)
    BRz getcfiltered_beg                ;           if char_b == 0: break

    SUB R2, R0, R2                      ;           char - char_a
    BRn getcfiltered_incr               ;           if char < char_a: siguiente par
    SUB R3, R0, R3                      ;           char - char_b
    BRp getcfiltered_incr               ;           if char > char_b: siguiente par
    BRnzp getcfiltered_ret              ;           return char

getcfiltered_incr                       ;
    ADD R1, R1, #2                      ;           filtro.incr(2 bytes)
    BRnzp getcfiltered_loop             ;

getcfiltered_ret                        ;
    LDW R1, getcfiltered_r1             ;
    LDW R2, getcfiltered_r2             ;
    LDW R3, getcfiltered_r3             ;
    LDW R7, getcfiltered_r7             ;
    RET

getcfiltered_filter_beg     .FILL #0
getcfiltered_r1             .FILL #0
getcfiltered_r2             .FILL #0
getcfiltered_r3             .FILL #0
getcfiltered_r7             .FILL #0

.END