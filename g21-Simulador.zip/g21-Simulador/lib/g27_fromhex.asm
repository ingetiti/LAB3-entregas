;   ============================================================================
;   Subrutina: FROMHEX (Migrada a ISA Grupo 21 - Direccionable por Byte)
;       Convierte una cadena de texto hexadecimal al valor correspondiente.
;
;   -> INPUT  [R0] Puntero a la cadena.
;   <- OUTPUT [R0] Valor obtenido.
;   <- OUTPUT [R5] Banderas de error [15:2 none, 1 OVERFLOW, 0 INVALID_INPUT].
;   ============================================================================

FROMHEX                                 ;
    STW R1, fromhex_r1                  ;
    STW R2, fromhex_r2                  ;
    STW R3, fromhex_r3                  ;
    STW R4, fromhex_r4                  ;

    STW R0, fromhex_str_beg             ;   [str_beg] = texto
    AND R0, R0, #0                      ;   [R0] valor = 0
    LDW R1, fromhex_str_beg             ;   [R1] texto = [str_beg]
    AND R5, R5, #0                      ;   [R5] errores = 0

    LDBL R2, R1, #0                     ;   [R2] char = texto[0] (1 byte)
    BRnp fromhex_loop                   ;   if char == '\0':
    NOT R5, R5                          ;
    AND R5, R5, #-2                     ;
    NOT R5, R5                          ;       errores = errores | INVALID_INPUT
    LDW R4, fromhex_ret_ptr             ;
    JMP R4                              ;       return

fromhex_loop                            ;   while True:
    AND R2, R2, #0                      ;       [R2] offset
    LDBL R3, R1, #0                     ;       [R3] char = texto[0] (1 byte)
    BRnp fromhex_chk_digits             ;       if char == '\0': break
    LDW R4, fromhex_ovf_ptr             ;
    JMP R4                              ;

fromhex_chk_digits                      ;
    LDW R4, fromhex_neg_zero            ;
    ADD R4, R4, R3                      ;
    BRn fromhex_lower                   ;
    LDW R4, fromhex_neg_nine            ;
    ADD R4, R4, R3                      ;
    BRp fromhex_lower                   ;       if char >= '0' and char <= '9':
    LDW R2, fromhex_neg_zero            ;           offset = -ord('0')

fromhex_lower                           ;
    LDW R4, fromhex_neg_a               ;
    ADD R4, R4, R3                      ;
    BRn fromhex_upper                   ;
    LDW R4, fromhex_neg_f               ;
    ADD R4, R4, R3                      ;
    BRp fromhex_upper                   ;       if char >= 'a' and char <= 'f':
    LDW R2, fromhex_neg_a               ;
    ADD R2, R2, #5                      ;
    ADD R2, R2, #5                      ;           offset = -ord('a') + 10
    BRnzp fromhex_upper                 ;

; --- Pool intermedio de respaldo y punteros de salto ---
fromhex_str_beg         .FILL #0
fromhex_r1              .FILL #0
fromhex_r2              .FILL #0
fromhex_r3              .FILL #0
fromhex_r4              .FILL #0
fromhex_ret_ptr         .FILL fromhex_ret
fromhex_ovf_ptr         .FILL fromhex_overflow_chk
fromhex_loop_ptr        .FILL fromhex_loop

fromhex_upper                           ;
    LDW R4, fromhex_neg_upa             ;
    ADD R4, R4, R3                      ;
    BRn fromhex_invalid_chk             ;
    LDW R4, fromhex_neg_upf             ;
    ADD R4, R4, R3                      ;
    BRp fromhex_invalid_chk             ;       if char >= 'A' and char <= 'F':
    LDW R2, fromhex_neg_upa             ;
    ADD R2, R2, #5                      ;
    ADD R2, R2, #5                      ;           offset = -ord('A') + 10

fromhex_invalid_chk                     ;
    ADD R2, R2, #0                      ;
    BRnp fromhex_increment              ;       if offset == 0:
    NOT R5, R5                          ;
    AND R5, R5, #-2                     ;
    NOT R5, R5                          ;           errores = errores | INVALID_INPUT
    BRnzp fromhex_overflow_chk          ;           break

fromhex_increment                       ;
    LSL R0, R0, #4                      ;       valor = valor << 4
    ADD R0, R0, R3                      ;
    ADD R0, R0, R2                      ;       valor = valor + char + offset
    ADD R1, R1, #1                      ;       texto.incr(1 byte)
    LDW R4, fromhex_loop_ptr            ;
    JMP R4                              ;

fromhex_overflow_chk                    ;
    LDW R4, fromhex_str_beg             ;
    ADD R4, R4, #4                      ;       4 caracteres = 4 bytes
    SUB R4, R1, R4                      ;       texto - ([str_beg] + 4)
    BRnz fromhex_ret                    ;   if texto >= [str_beg] + 4:
    NOT R5, R5                          ;
    AND R5, R5, #-3                     ;
    NOT R5, R5                          ;       errores = errores | OVERFLOW

fromhex_ret                             ;
    LDW R1, fromhex_r1                  ;
    LDW R2, fromhex_r2                  ;
    LDW R3, fromhex_r3                  ;
    LDW R4, fromhex_r4                  ;
    RET                                 ;

fromhex_neg_zero        .FILL #-48      ;   - ord('0')
fromhex_neg_nine        .FILL #-57      ;   - ord('9')
fromhex_neg_a           .FILL #-97      ;   - ord('a')
fromhex_neg_f           .FILL #-102     ;   - ord('f')
fromhex_neg_upa         .FILL #-65      ;   - ord('A')
fromhex_neg_upf         .FILL #-70      ;   - ord('F')

.END