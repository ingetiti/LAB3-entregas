; ===========================================================================
; Modulo potencia (adaptado a ISA Grupo 21): POTENCIA y MULT juntas.
; ===========================================================================

Mul_Sucesiva_POW
                 LDW R2, P_K_NEG8
                 ADD R6, R6, R2
                 STRW R1, R6, #0
                 STRW R2, R6, #2
                 STRW R3, R6, #4
                 STRW R7, R6, #6

                 ADD R3, R1, #0          ; R3 = B
                 ADD R1, R0, #0          ; R1 = A
                 ADD R3, R3, #0
                 BRn P_JMP_ERR
                 BRp P_CHK_ZERO_BASE

                 ; B == 0
                 ADD R0, R0, #0
                 BRz P_JMP_ERR           ; 0^0 -> error
                 LDW R0, P_K_UNO
                 BRnzp P_JMP_FIN

P_JMP_ERR
                 LDW R2, P_PTR_ERR
                 JMP R2

P_JMP_FIN
                 LDW R2, P_PTR_FIN
                 JMP R2

P_CHK_ZERO_BASE
                 ADD R0, R0, #0
                 BRz P_JMP_FIN           ; 0^B = 0
                 ADD R3, R3, #-1         ; B - 1 multiplicaciones
                 BRz P_JMP_FIN           ; B == 1 -> R0 = A

P_BUC
                 LDW R2, P_PTR_MULT
                 JSRR R2                 ; R0 = R0 * R1
                 LDW R2, P_K_ERRQ
                 ADD R2, R0, R2          ; 0 si R0 == x8000
                 BRz P_JMP_FIN
                 ADD R3, R3, #-1
                 BRp P_JMP_BUC
                 BRnzp P_JMP_FIN

P_JMP_BUC
                 LDW R2, P_PTR_BUC
                 JMP R2

P_ERR
                 LDW R0, P_K_ERRQ

P_FIN
                 LDRW R1, R6, #0
                 LDRW R2, R6, #2
                 LDRW R3, R6, #4
                 LDRW R7, R6, #6
                 LDW R2, P_K_POS8
                 ADD R6, R6, R2
                 LDRW R2, R6, #-6
                 RET

P_K_NEG8         .FILL #-8
P_K_POS8         .FILL #8
P_K_UNO          .FILL x0100
P_K_ERRQ         .FILL x8000
P_PTR_ERR        .FILL P_ERR
P_PTR_FIN        .FILL P_FIN
P_PTR_BUC        .FILL P_BUC
P_PTR_MULT       .FILL MULT


; ---------------------------------------------------------------------------
; MULT - Multiplicacion Q7.8 con signo, por sumas sucesivas
;   Entrada : R0 = A (Q7.8), R1 = B (Q7.8)
;   Salida  : R0 = A*B (Q7.8) o x8000 si hay desborde
; ---------------------------------------------------------------------------
MULT
                 LDW R2, M_K_NEG10
                 ADD R6, R6, R2
                 STRW R1, R6, #0
                 STRW R2, R6, #2
                 STRW R3, R6, #4
                 STRW R4, R6, #6
                 STRW R5, R6, #8

                 ADD R2, R1, #0          ; R2 = B
                 ADD R1, R0, #0          ; R1 = A

                 ; ---- signos y magnitudes ----
                 AND R5, R5, #0
                 ADD R1, R1, #0
                 BRzp M_A_POS
                 NOT R1, R1
                 ADD R1, R1, #1
                 BRzp M_A_INC
                 LDW R2, M_P_ERR_1
                 JMP R2

M_A_INC
                 ADD R5, R5, #1
M_A_POS
                 ADD R2, R2, #0
                 BRzp M_B_POS
                 NOT R2, R2
                 ADD R2, R2, #1
                 BRzp M_B_INC
                 LDW R2, M_P_ERR_1
                 JMP R2

M_B_INC
                 ADD R5, R5, #1
M_B_POS
                 AND R0, R0, #0
                 ADD R5, R5, #-1
                 BRnp M_SGN_STORE
                 ADD R0, R0, #1

M_SGN_STORE
                 STIW R0, M_P_SGN_1
                 BRnzp M_DIV_B_INIT

M_K_NEG10        .FILL #-10
M_P_SGN_1        .FILL M_VAR_SGN
M_P_ERR_1        .FILL M_ERR_RET
M_P_NEG256_1     .FILL M_K_NEG256
M_P_BF_1         .FILL M_VAR_BF
M_P_DIV_A_1      .FILL M_DIV_A_INIT

M_DIV_B_INIT
                 ADD R3, R2, #0          ; R3 = resto (BF)
                 AND R4, R4, #0          ; R4 = BI
                 LDIW R5, M_P_NEG256_1

M_DIV_B_LOOP
                 ADD R2, R3, R5
                 BRzp M_DIV_B_STEP
                 LDW R2, M_P_DIV_B_DONE
                 JMP R2

M_DIV_B_STEP
                 ADD R3, R2, #0
                 ADD R4, R4, #1
                 LDW R2, M_P_DIV_B_LOOP
                 JMP R2

M_P_DIV_B_LOOP   .FILL M_DIV_B_LOOP
M_P_DIV_B_DONE   .FILL M_DIV_B_DONE

M_DIV_B_DONE
                 STIW R3, M_P_BF_1

                 ; ---- fase 1: sumar |A|, BI veces ----
                 AND R0, R0, #0
                 ADD R4, R4, #0
                 BRnp M_FASE1_LOOP
                 LDW R2, M_P_DIV_A_1
                 JMP R2

M_FASE1_LOOP
                 ADD R0, R0, R1
                 BRzp M_FASE1_NEXT
                 LDW R2, M_P_ERR_2
                 JMP R2

M_FASE1_NEXT
                 ADD R4, R4, #-1
                 BRnz M_FASE1_DONE
                 LDW R2, M_P_FASE1_LOOP
                 JMP R2

M_P_FASE1_LOOP   .FILL M_FASE1_LOOP
M_P_DIV_A_2      .FILL M_DIV_A_INIT

M_FASE1_DONE
                 LDW R2, M_P_DIV_A_2
                 JMP R2

M_P_ERR_2        .FILL M_ERR_RET
M_P_NEG256_2     .FILL M_K_NEG256
M_P_BF_2         .FILL M_VAR_BF
M_P_SGN_2        .FILL M_VAR_SGN
M_P_FIN_M_2      .FILL M_APPLY_SIGN

M_DIV_A_INIT
                 ADD R3, R1, #0          ; R3 = resto (AF)
                 AND R4, R4, #0          ; R4 = AI
                 LDIW R5, M_P_NEG256_2

M_DIV_A_LOOP
                 ADD R2, R3, R5
                 BRzp M_DIV_A_STEP
                 LDW R2, M_P_DIV_A_DONE
                 JMP R2

M_DIV_A_STEP
                 ADD R3, R2, #0
                 ADD R4, R4, #1
                 LDW R2, M_P_DIV_A_LOOP
                 JMP R2

M_P_DIV_A_LOOP   .FILL M_DIV_A_LOOP
M_P_DIV_A_DONE   .FILL M_DIV_A_DONE

M_DIV_A_DONE
                 ; ---- fase 2: sumar |A|/256, BF veces ----
                 AND R5, R5, #0
                 LDIW R1, M_P_BF_2
                 ADD R1, R1, #0
                 BRp M_FASE2_LOOP
                 LDW R2, M_P_FIN_M_2
                 JMP R2

M_FASE2_LOOP
                 ADD R0, R0, R4
                 BRzp M_FASE2_FRAC
                 LDW R2, M_P_ERR_3
                 JMP R2

M_FASE2_FRAC
                 ADD R5, R5, R3
                 LDIW R2, M_P_NEG256_3
                 ADD R2, R5, R2
                 BRn M_FASE2_CNT
                 ADD R5, R2, #0
                 ADD R0, R0, #1
                 BRzp M_FASE2_CNT
                 LDW R2, M_P_ERR_3
                 JMP R2

M_FASE2_CNT
                 ADD R1, R1, #-1
                 BRp M_FASE2_CONT
                 LDW R2, M_P_FIN_M_3
                 JMP R2

M_FASE2_CONT
                 LDW R2, M_P_FASE2_LOOP_3
                 JMP R2

M_P_ERR_3        .FILL M_ERR_RET
M_P_NEG256_3     .FILL M_K_NEG256
M_P_FIN_M_3      .FILL M_APPLY_SIGN
M_P_FASE2_LOOP_3 .FILL M_FASE2_LOOP

M_APPLY_SIGN
                 LDIW R1, M_P_SGN_3
                 ADD R1, R1, #0
                 BRz M_JMP_RET_3
                 NOT R0, R0
                 ADD R0, R0, #1

M_JMP_RET_3
                 LDW R2, M_P_RET_3
                 JMP R2

M_P_SGN_3        .FILL M_VAR_SGN
M_P_RET_3        .FILL M_RESTORE_END

M_ERR_RET
                 LDW R0, M_K_ERRQ_END
                 LDW R2, M_P_RET_ERR
                 JMP R2

M_P_RET_ERR      .FILL M_RESTORE_END
M_K_ERRQ_END     .FILL x8000
M_K_POS10_END    .FILL #10
M_K_NEG256       .FILL #-256
M_VAR_SGN        .FILL #0
M_VAR_BF         .FILL #0

M_RESTORE_END
                 LDRW R1, R6, #0
                 LDRW R3, R6, #4
                 LDRW R4, R6, #6
                 LDRW R5, R6, #8
                 LDW R2, M_K_POS10_END
                 ADD R6, R6, R2
                 LDRW R2, R6, #-8
                 RET

.END