;   ============================================================================
;   Subrutina: GETLINE (Migrada a ISA Grupo 21 - Direccionable por Byte)
;       Obtiene una cadena de texto desde el teclado, mostrandola y guardandola
;       en el buffer dado hasta pulsar ENTER ('\n' o '\r').
;
;   -> INPUT  [R0] Puntero al buffer de la cadena.
;   -> INPUT  [R1] Puntero a 1 pasando del final del buffer de la cadena.
;   <- OUTPUT [R0] Puntero al buffer de la cadena (modificada).
;   ============================================================================
GETLINE                                 ;
    STW R0, getline_buffer_beg          ;
    STW R1, getline_r1                  ;
    STW R2, getline_r2                  ;
    STW R3, getline_r3                  ;
    STW R7, getline_r7                  ;

    LDW R2, getline_buffer_beg          ;   [R2] cursor = [buffer_beg]
    NOT R1, R1                          ;
    ADD R1, R1, #2                      ;   [R1] - (buffer_end - 1)

getline_loop                            ;   while True:
    GETC                                ;       [R0] char = getc()
    ADD R3, R0, #-5                     ;
    ADD R3, R3, #-5                     ;       char - 10 ('\n')
    BRz getline_chk_empty               ;       if char == '\n': verificar si hay texto

    ADD R3, R3, #-3                     ;       char - 13 ('\r')
    BRz getline_chk_empty               ;       if char == '\r': verificar si hay texto

    OUT                                 ;       putc(char)

    ADD R3, R2, R1                      ;       if cursor >= (buffer_end - 1):
    BRzp getline_loop                   ;           continue

    STBL R0, R2, #0                     ;       cursor[0] = char (1 byte)
    ADD R2, R2, #1                      ;       cursor += 1 byte
    BRnzp getline_loop                  ;

getline_chk_empty                       ;
    LDW R3, getline_buffer_beg          ;
    SUB R3, R2, R3                      ;
    BRz getline_loop                    ;   ignora Enter pendiente antes del primer digito

getline_ret                             ;
    AND R0, R0, #0                      ;
    ADD R0, R0, #5                      ;
    ADD R0, R0, #5                      ;       R0 = 10 ('\n')
    OUT                                 ;       putc('\n')
    AND R0, R0, #0                      ;
    STBL R0, R2, #0                     ;       cursor[0] = '\0' (1 byte)

    LDW R0, getline_buffer_beg          ;
    LDW R1, getline_r1                  ;
    LDW R2, getline_r2                  ;
    LDW R3, getline_r3                  ;
    LDW R7, getline_r7                  ;
    RET                                 ;

getline_buffer_beg      .FILL #0
getline_r1              .FILL #0
getline_r2              .FILL #0
getline_r3              .FILL #0
getline_r7              .FILL #0

.END