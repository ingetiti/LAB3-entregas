; ===========================================================================
; EXP para la interfaz del Grupo 27 y el simulador del Grupo 8 (ISA Grupo 21).
; Entrada: R0 en Q3.12 con signo. Salida: R0 en Q7.8 con signo.
; Conserva R1, R2, R3, R4, R5 y R7. R6 no se utiliza ni se modifica.
; EXP_Q3_12 es el simbolo usado por .EXTERNAL g6_EXP-EXP_Q3_12.
;
; EST_EXP y NUM_ITER quedan en memoria.
; EST_EXP: 0 = normal, 1 = saturado, 2 = redondeado a cero.
; NUM_ITER: 6 en el calculo normal, 0 en saturacion detectada al entrar.
; CC refleja el resultado al retornar. No hay TRAP ni HALT en la rutina.
; ===========================================================================

EXP_Q3_12
        STW R1, G6_EXP_R1
        STW R2, G6_EXP_R2
        STW R3, G6_EXP_R3
        STW R4, G6_EXP_R4
        STW R5, G6_EXP_R5
        STW R7, G6_EXP_R7

        LDW R6, G6_JMP_CALCULA
        JSRR R6

        STW R1, EST_EXP
        STW R2, NUM_ITER

        LDW R1, G6_EXP_R1
        LDW R2, G6_EXP_R2
        LDW R3, G6_EXP_R3
        LDW R4, G6_EXP_R4
        LDW R5, G6_EXP_R5
        LDW R7, G6_EXP_R7
        ADD R0, R0, #0
        RET

G6_EXP_R1        .FILL #0
G6_EXP_R2        .FILL #0
G6_EXP_R3        .FILL #0
G6_EXP_R4        .FILL #0
G6_EXP_R5        .FILL #0
G6_EXP_R7        .FILL #0
EST_EXP          .FILL #0
NUM_ITER         .FILL #0
G6_JMP_CALCULA   .FILL G6_EXP_CALCULA

; ---------------------------------------------------------------------------
; Calculo interno (base TRABAJO en R5; offsets en bytes)
;   TRABAJO + 0  (0x00): R7 guardado
;   TRABAJO + 2  (0x02): V0 (bajo 15)
;   TRABAJO + 4  (0x04): V1 (medio 15)
;   TRABAJO + 6  (0x06): V2 (alto 15)
;   TRABAJO + 8  (0x08): k (contador ln(2))
;   TRABAJO + 10 (0x0A): signo x (0=pos, 1=neg)
;   TRABAJO + 12 (0x0C): E_0 (bajo 15)
;   TRABAJO + 14 (0x0E): E_1 (medio 15)
; ---------------------------------------------------------------------------
G6_EXP_CALCULA
        LDW R5, C_PTR_TRABAJO
        STRW R7, R5, #0

        AND R1, R1, #0
        STRW R1, R5, #8         ; k = 0
        STRW R1, R5, #10        ; signo = 0

        LDW R2, C_PTR_T24_A
        STRW R1, R2, #0         ; iter_count = 0

        ADD R0, R0, #0
        BRn EXP_NEG
        LDW R2, C_NEG_LIMITE
        ADD R2, R0, R2
        BRp EXP_SAT_ENTRY
        BRnzp ESCALA

EXP_SAT_ENTRY
        LDW R2, C_PTR_EXP_SAT
        JMP R2

EXP_NEG
        ADD R1, R1, #1
        STRW R1, R5, #10        ; signo = 1
        NOT R0, R0
        ADD R0, R0, #1          ; |x| con signo 16 bits
        BRnzp ESCALA

C_PTR_TRABAJO    .FILL TRABAJO
C_PTR_T24_A      .FILL T_ITER
C_NEG_LIMITE     .FILL #-19873
C_MASK15_A       .FILL x7FFF
C_PTR_EXP_SAT    .FILL EXP_SAT

ESCALA
        AND R1, R1, #0
        STRW R1, R5, #2         ; V0 = 0

        ADD R1, R0, R0
        ADD R1, R1, R1
        ADD R1, R1, R1
        LDW R7, C_MASK15_B
        AND R1, R1, R7
        STRW R1, R5, #4         ; V1

        AND R2, R2, #0
        AND R3, R3, #0
        ADD R3, R3, #4

ESCALA_BITS
        ADD R2, R2, R2
        ADD R0, R0, #0
        BRzp ESCALA_SIG
        ADD R2, R2, #1
ESCALA_SIG
        ADD R0, R0, R0
        ADD R3, R3, #-1
        BRp ESCALA_BITS
        STRW R2, R5, #6         ; V2
        BRnzp REDUCE

C_MASK15_B       .FILL x7FFF
C_NEG_LN_LO      .FILL #-1534
C_NEG_LN_MI      .FILL #-22713

; ---------------------------------------------------------------------------
; Reducir |x| restando ln(2)*2^30
; ---------------------------------------------------------------------------
REDUCE
        LDRW R0, R5, #2         ; V0
        LDRW R1, R5, #4         ; V1
        LDRW R2, R5, #6         ; V2

        LDW R3, C_NEG_LN_LO
        ADD R0, R0, R3
        BRzp REDUCE_MED
        ADD R1, R1, #-1

REDUCE_MED
        LDW R3, C_NEG_LN_MI
        ADD R1, R1, R3
        BRzp REDUCE_ALTO
        ADD R2, R2, #-1

REDUCE_ALTO
        ADD R2, R2, #0
        BRn REDUCE_SIGNO

        LDW R7, C_MASK15_C
        AND R0, R0, R7
        AND R1, R1, R7
        STRW R0, R5, #2
        STRW R1, R5, #4
        STRW R2, R5, #6

        LDRW R3, R5, #8         ; k++
        ADD R3, R3, #1
        STRW R3, R5, #8
        BRnzp REDUCE

REDUCE_SIGNO
        LDRW R0, R5, #10        ; signo
        BRz EXP_INICIA_JMP

        LDRW R2, R5, #8         ; k
        NOT R2, R2
        LDRW R0, R5, #2
        LDRW R1, R5, #4
        ADD R3, R0, R1
        BRnp REDUCE_COMP
        ADD R2, R2, #1
        BRnzp REDUCE_GUARDA

REDUCE_COMP
        NOT R0, R0
        ADD R0, R0, #1
        NOT R1, R1
        ADD R1, R1, #1
        LDW R3, C_LN_LO
        ADD R0, R0, R3
        BRzp REDUCE_COMP_MI
        ADD R1, R1, #-1

REDUCE_COMP_MI
        LDW R3, C_LN_MI
        ADD R1, R1, R3
        LDW R7, C_MASK15_C
        AND R0, R0, R7
        STRW R0, R5, #2
        STRW R1, R5, #4

REDUCE_GUARDA
        STRW R2, R5, #8

EXP_INICIA_JMP
        LDW R2, C_PTR_EXP_INICIA
        JMP R2

C_MASK15_C       .FILL x7FFF
C_LN_LO          .FILL #1534
C_LN_MI          .FILL #22713
C_PTR_EXP_INICIA .FILL EXP_INICIA

; ---------------------------------------------------------------------------
; Inicializacion de E = 1 (2^30 -> [0, 0, 1]) y punteros de tabla/shift
; ---------------------------------------------------------------------------
EXP_INICIA
        AND R0, R0, #0
        STRW R0, R5, #12        ; E_0 = 0
        STRW R0, R5, #14        ; E_1 = 0
        ADD R0, R0, #1

        LDW R2, C_PTR_T16_A
        STRW R0, R2, #0         ; E_2 = 1

        ADD R0, R0, #3          ; shift = 4
        LDW R2, C_PTR_T22_A
        STRW R0, R2, #0

        LDW R0, C_PTR_D16_A
        LDW R2, C_PTR_T20_A
        STRW R0, R2, #0
        BRnzp EXP_PASO

C_PTR_T16_A      .FILL T_E2
C_PTR_T22_A      .FILL T_SHIFT
C_PTR_T20_A      .FILL T_PTR_TAB
C_PTR_D16_A      .FILL TABLA_D16

; ---------------------------------------------------------------------------
; Paso iterativo de base 16 (6 iteraciones)
; ---------------------------------------------------------------------------
EXP_PASO
        LDW R2, C_PTR_T20_B
        LDRW R3, R2, #0         ; puntero en TABLA_D16

        AND R7, R7, #0
        ADD R7, R7, #7
        ADD R7, R7, #7
        ADD R7, R7, #2          ; R7 = 16

EXP_BUSCA
        LDRW R0, R5, #2         ; r_lo
        LDRW R1, R5, #4         ; r_mi

        LDRW R4, R3, #0
        NOT R4, R4
        ADD R4, R4, #1
        ADD R0, R0, R4
        BRzp EXP_BUSCA_MI
        ADD R1, R1, #-1

EXP_BUSCA_MI
        LDRW R4, R3, #2
        NOT R4, R4
        ADD R4, R4, #1
        ADD R1, R1, R4
        BRzp EXP_ACEPTA

        ADD R3, R3, #-4
        ADD R7, R7, #-1
        BRnzp EXP_BUSCA

EXP_ACEPTA
        ADD R3, R7, #0
        LDW R7, C_MASK15_D
        AND R0, R0, R7
        STRW R0, R5, #2
        STRW R1, R5, #4

        AND R0, R0, #0
        AND R1, R1, #0
        AND R2, R2, #0
        ADD R3, R3, #0
        BRz EXP_MULT_FIN

EXP_MULT
        LDRW R4, R5, #12
        ADD R0, R0, R4
        BRzp EXP_MULT_MI
        AND R0, R0, R7
        ADD R1, R1, #1

EXP_MULT_MI
        LDRW R4, R5, #14
        ADD R1, R1, R4
        BRzp EXP_MULT_ALTO
        AND R1, R1, R7
        ADD R2, R2, #1

EXP_MULT_ALTO
        LDW R6, C_PTR_T16_B
        LDRW R4, R6, #0
        ADD R2, R2, R4

        ADD R3, R3, #-1
        BRp EXP_MULT
        BRnzp EXP_MULT_FIN

C_PTR_T20_B      .FILL T_PTR_TAB
C_MASK15_D       .FILL x7FFF
C_PTR_T16_B      .FILL T_E2
C_PTR_T22_B      .FILL T_SHIFT
C_PTR_T24_B      .FILL T_ITER
C_PTR_T26_B      .FILL T_P0
C_PTR_T28_B      .FILL T_P1
C_PTR_T30_B      .FILL T_P2
C_PTR_RED_B      .FILL REDONDEA
C_PTR_PASO_B     .FILL EXP_PASO
C_PTR_SAL_B      .FILL EXP_SALIDA
C_K_68           .FILL #68

EXP_MULT_FIN
        LDW R6, C_PTR_T26_B
        STRW R0, R6, #0
        LDW R6, C_PTR_T28_B
        STRW R1, R6, #0
        LDW R6, C_PTR_T30_B
        STRW R2, R6, #0

        LDW R2, C_PTR_T22_B
        LDRW R0, R2, #0
        LDW R6, C_PTR_RED_B
        JSRR R6

        LDW R7, C_MASK15_D
        LDRW R3, R5, #12
        ADD R0, R0, R3
        BRzp EXP_SUMA_MI
        AND R0, R0, R7
        ADD R1, R1, #1

EXP_SUMA_MI
        LDRW R3, R5, #14
        ADD R1, R1, R3
        BRzp EXP_SUMA_ALTO
        AND R1, R1, R7
        ADD R2, R2, #1

EXP_SUMA_ALTO
        LDW R6, C_PTR_T16_B
        LDRW R3, R6, #0
        ADD R2, R2, R3

        STRW R0, R5, #12
        STRW R1, R5, #14
        STRW R2, R6, #0

        LDW R6, C_PTR_T24_B
        LDRW R3, R6, #0
        ADD R3, R3, #1
        STRW R3, R6, #0

        ADD R3, R3, #-6
        BRz EXP_SALIDA_JMP

        LDW R6, C_PTR_T20_B
        LDRW R0, R6, #0
        LDW R4, C_K_68
        ADD R0, R0, R4
        STRW R0, R6, #0

        LDW R6, C_PTR_T22_B
        LDRW R0, R6, #0
        ADD R0, R0, #4
        STRW R0, R6, #0

        LDW R6, C_PTR_PASO_B
        JMP R6

EXP_SALIDA_JMP
        LDW R6, C_PTR_SAL_B
        JMP R6

; ---------------------------------------------------------------------------
; Salida a Q7.8: redondeo(E / 2^(22 - k))
; ---------------------------------------------------------------------------
EXP_SALIDA
        LDW R6, C_PTR_T26_C
        STRW R0, R6, #0
        LDW R6, C_PTR_T28_C
        STRW R1, R6, #0
        LDW R6, C_PTR_T30_C
        STRW R2, R6, #0

        LDRW R0, R5, #8
        NOT R0, R0
        ADD R0, R0, #1
        LDW R4, C_K_22
        ADD R0, R0, R4

        LDW R6, C_PTR_RED_C
        JSRR R6

        ADD R3, R1, R2
        BRnp EXP_SAT

        ADD R0, R0, #0
        BRnp EXP_NORMAL_OK
        AND R1, R1, #0
        ADD R1, R1, #2
        BRnzp EXP_FIN

EXP_NORMAL_OK
        AND R1, R1, #0
        BRnzp EXP_FIN

EXP_SAT
        LDW R0, C_MASK15_E
        AND R1, R1, #0
        ADD R1, R1, #1

EXP_FIN
        LDW R6, C_PTR_T24_C
        LDRW R2, R6, #0
        LDRW R7, R5, #0
        RET

C_PTR_T26_C      .FILL T_P0
C_PTR_T28_C      .FILL T_P1
C_PTR_T30_C      .FILL T_P2
C_K_22           .FILL #22
C_PTR_RED_C      .FILL REDONDEA
C_MASK15_E       .FILL x7FFF
C_PTR_T24_C      .FILL T_ITER

; ---------------------------------------------------------------------------
; REDONDEA: entero de 45 bits en T_P0, T_P1, T_P2; R0 = n (1..44).
; Retorna resultado en R2:R1:R0.
; ---------------------------------------------------------------------------
REDONDEA
        LDW R6, C_PTR_T32
        STRW R7, R6, #0

        NOT R7, R0
        ADD R7, R7, #1
        LDW R4, C_K_45
        ADD R7, R7, R4

        AND R0, R0, #0
        AND R1, R1, #0
        AND R2, R2, #0

        LDW R3, C_PTR_T30_D
        LDW R6, C_PTR_T34
        STRW R3, R6, #0
        BRnzp RED_CARGA

C_PTR_T32        .FILL T_SAV_R7
C_K_45           .FILL #45
C_PTR_T30_D      .FILL T_P2
C_PTR_T34        .FILL T_CUR_PTR
C_PTR_T36        .FILL T_SAV_R4
C_MASK15_F       .FILL x7FFF
C_PTR_RED_CARGA  .FILL RED_CARGA
C_PTR_RED_AJUSTA .FILL RED_AJUSTA
C_PTR_RED_BIT    .FILL RED_BIT

RED_CARGA
        LDW R6, C_PTR_T34
        LDRW R3, R6, #0
        LDRW R3, R3, #0
        ADD R3, R3, R3

        AND R4, R4, #0
        ADD R4, R4, #7
        ADD R4, R4, #7
        ADD R4, R4, #1

RED_BIT
        ADD R7, R7, #0
        BRp RED_DO_BIT
        LDW R6, C_PTR_RED_AJUSTA
        JMP R6

RED_DO_BIT
        ADD R2, R2, R2
        ADD R1, R1, R1
        BRzp RED_DUP_BAJO

        LDW R6, C_PTR_T36
        STRW R4, R6, #0
        LDW R4, C_MASK15_F
        AND R1, R1, R4
        LDW R6, C_PTR_T36
        LDRW R4, R6, #0
        ADD R2, R2, #1

RED_DUP_BAJO
        ADD R0, R0, R0
        BRzp RED_INSERTA

        LDW R6, C_PTR_T36
        STRW R4, R6, #0
        LDW R4, C_MASK15_F
        AND R0, R0, R4
        LDW R6, C_PTR_T36
        LDRW R4, R6, #0
        ADD R1, R1, #1

RED_INSERTA
        ADD R3, R3, #0
        BRzp RED_SIG_BIT
        ADD R0, R0, #1

RED_SIG_BIT
        ADD R3, R3, R3
        ADD R7, R7, #-1
        ADD R4, R4, #-1
        BRnz RED_BIT_DONE
        BRnzp RED_BIT

RED_BIT_DONE
        ADD R7, R7, #0
        BRnz RED_DO_CARGA
        LDW R6, C_PTR_RED_BIT
        JMP R6

RED_DO_CARGA
        LDW R6, C_PTR_T34
        LDRW R3, R6, #0
        ADD R3, R3, #-2
        STRW R3, R6, #0
        LDW R6, C_PTR_RED_CARGA
        JMP R6

C_AJ_T36         .FILL T_SAV_R4
C_AJ_MASK15      .FILL x7FFF
C_AJ_T32         .FILL T_SAV_R7

RED_AJUSTA
        ADD R3, R3, #0
        BRzp RED_RETORNO
        ADD R0, R0, #1
        BRzp RED_RETORNO

        LDW R6, C_AJ_T36
        STRW R4, R6, #0
        LDW R4, C_AJ_MASK15
        AND R0, R0, R4
        LDW R6, C_AJ_T36
        LDRW R4, R6, #0
        ADD R1, R1, #1
        BRzp RED_RETORNO

        LDW R6, C_AJ_T36
        STRW R4, R6, #0
        LDW R4, C_AJ_MASK15
        AND R1, R1, R4
        LDW R6, C_AJ_T36
        LDRW R4, R6, #0
        ADD R2, R2, #1

RED_RETORNO
        LDW R6, C_AJ_T32
        LDRW R7, R6, #0
        RET

; ---------------------------------------------------------------------------
; Area de trabajo y variables auxiliares
; ---------------------------------------------------------------------------
TRABAJO          .BLKW #8
T_E2             .FILL #0
T_PTR_TAB        .FILL #0
T_SHIFT          .FILL #0
T_ITER           .FILL #0
T_P0             .FILL #0
T_P1             .FILL #0
T_P2             .FILL #0
T_SAV_R7         .FILL #0
T_CUR_PTR        .FILL #0
T_SAV_R4         .FILL #0

; ---------------------------------------------------------------------------
; Tabla TABLA_D16: cada constante tiene [bajo15, medio15] (2 palabras = 4 bytes)
; ---------------------------------------------------------------------------
; j = 1
                 .FILL x0000
                 .FILL x0000
                 .FILL x4618
                 .FILL x07C2
                 .FILL x41DC
                 .FILL x0F13
                 .FILL x1838
                 .FILL x15FF
                 .FILL x7BE4
                 .FILL x1C8F
                 .FILL x5CAC
                 .FILL x22CE
                 .FILL x0BC2
                 .FILL x28C3
                 .FILL x57F7
                 .FILL x2E73
                 .FILL x23ED
                 .FILL x33E6
                 .FILL x77C8
                 .FILL x391F
                 .FILL x0F60
                 .FILL x3E25
                 .FILL x65C8
                 .FILL x42F9
                 .FILL x3EBD
                 .FILL x47A1
                 .FILL x2E67
                 .FILL x4C1F
                 .FILL x1FD1
                 .FILL x5076
                 .FILL x5A4D
                 .FILL x54A8
TABLA_D16        .FILL x05FE
                 .FILL x58B9

; j = 2
                 .FILL x0000
                 .FILL x0000
                 .FILL x6015
                 .FILL x007F
                 .FILL x00AA
                 .FILL x00FF
                 .FILL x623B
                 .FILL x017D
                 .FILL x0546
                 .FILL x01FC
                 .FILL x6A44
                 .FILL x0279
                 .FILL x11B0
                 .FILL x02F7
                 .FILL x7C02
                 .FILL x0373
                 .FILL x29B1
                 .FILL x03F0
                 .FILL x1B31
                 .FILL x046C
                 .FILL x50F7
                 .FILL x04E7
                 .FILL x4B76
                 .FILL x0562
                 .FILL x0B1F
                 .FILL x05DD
                 .FILL x1062
                 .FILL x0657
                 .FILL x5BAE
                 .FILL x06D0
                 .FILL x6D71
                 .FILL x0749
                 .FILL x4618
                 .FILL x07C2

; j = 3
                 .FILL x0000
                 .FILL x0000
                 .FILL x7FE0
                 .FILL x0007
                 .FILL x7F80
                 .FILL x000F
                 .FILL x7EE0
                 .FILL x0017
                 .FILL x7E00
                 .FILL x001F
                 .FILL x7CE1
                 .FILL x0027
                 .FILL x7B81
                 .FILL x002F
                 .FILL x79E2
                 .FILL x0037
                 .FILL x7803
                 .FILL x003F
                 .FILL x75E4
                 .FILL x0047
                 .FILL x7385
                 .FILL x004F
                 .FILL x70E7
                 .FILL x0057
                 .FILL x6E09
                 .FILL x005F
                 .FILL x6AEB
                 .FILL x0067
                 .FILL x678E
                 .FILL x006F
                 .FILL x63F2
                 .FILL x0077
                 .FILL x6015
                 .FILL x007F

; j = 4
                 .FILL x0000
                 .FILL x0000
                 .FILL x4000
                 .FILL x0000
                 .FILL x0000
                 .FILL x0001
                 .FILL x3FFF
                 .FILL x0001
                 .FILL x7FFE
                 .FILL x0001
                 .FILL x3FFD
                 .FILL x0002
                 .FILL x7FFC
                 .FILL x0002
                 .FILL x3FFA
                 .FILL x0003
                 .FILL x7FF8
                 .FILL x0003
                 .FILL x3FF6
                 .FILL x0004
                 .FILL x7FF4
                 .FILL x0004
                 .FILL x3FF1
                 .FILL x0005
                 .FILL x7FEE
                 .FILL x0005
                 .FILL x3FEB
                 .FILL x0006
                 .FILL x7FE8
                 .FILL x0006
                 .FILL x3FE4
                 .FILL x0007
                 .FILL x7FE0
                 .FILL x0007

; j = 5
                 .FILL x0000
                 .FILL x0000
                 .FILL x0400
                 .FILL x0000
                 .FILL x0800
                 .FILL x0000
                 .FILL x0C00
                 .FILL x0000
                 .FILL x1000
                 .FILL x0000
                 .FILL x1400
                 .FILL x0000
                 .FILL x1800
                 .FILL x0000
                 .FILL x1C00
                 .FILL x0000
                 .FILL x2000
                 .FILL x0000
                 .FILL x2400
                 .FILL x0000
                 .FILL x2800
                 .FILL x0000
                 .FILL x2C00
                 .FILL x0000
                 .FILL x3000
                 .FILL x0000
                 .FILL x3400
                 .FILL x0000
                 .FILL x3800
                 .FILL x0000
                 .FILL x3C00
                 .FILL x0000
                 .FILL x4000
                 .FILL x0000

; j = 6
                 .FILL x0000
                 .FILL x0000
                 .FILL x0040
                 .FILL x0000
                 .FILL x0080
                 .FILL x0000
                 .FILL x00C0
                 .FILL x0000
                 .FILL x0100
                 .FILL x0000
                 .FILL x0140
                 .FILL x0000
                 .FILL x0180
                 .FILL x0000
                 .FILL x01C0
                 .FILL x0000
                 .FILL x0200
                 .FILL x0000
                 .FILL x0240
                 .FILL x0000
                 .FILL x0280
                 .FILL x0000
                 .FILL x02C0
                 .FILL x0000
                 .FILL x0300
                 .FILL x0000
                 .FILL x0340
                 .FILL x0000
                 .FILL x0380
                 .FILL x0000
                 .FILL x03C0
                 .FILL x0000
                 .FILL x4000
                 .FILL x0000

.END