; ============================================================================
; Modulo: division   (archivo g10_division_larga.asm)                Grupo 10
; Division larga (restoring) con signo en punto fijo de 16 bits.
; Adaptado para ISA Grupo 21 (offsets BR en [-64..63] y LDW/STW en [-128..127])
; ============================================================================

DIVIDIR     ADD R6, R6, #-2          ; guardar R1..R5 en pila (R0 es la salida)
            STRW R1, R6, #0
            ADD R6, R6, #-2
            STRW R2, R6, #0
            ADD R6, R6, #-2
            STRW R3, R6, #0
            ADD R6, R6, #-2
            STRW R4, R6, #0
            ADD R6, R6, #-2
            STRW R5, R6, #0

            AND R5, R5, #0           ; R5 = 0
            STW R5, ESTADO           ; estado = 0 (ok)

            ADD R1, R1, #0           ; divisor = 0 ?
            BRnp DIV_NO_CERO

            AND R0, R0, #0           ; divisor 0: resultado 0
            AND R4, R4, #0
            ADD R4, R4, #1
            STW R4, ESTADO           ; estado = 1
            BRnzp EPILOGO

EPILOGO     LDRW R5, R6, #0          ; restaurar R5..R1 desde pila
            ADD R6, R6, #2
            LDRW R4, R6, #0
            ADD R6, R6, #2
            LDRW R3, R6, #0
            ADD R6, R6, #2
            LDRW R2, R6, #0
            ADD R6, R6, #2
            LDRW R1, R6, #0
            ADD R6, R6, #2
            RET

DIV_NO_CERO ADD R1, R1, #0           ; signo de b
            BRp B_POS
            ADD R5, R5, #1           ; divisor negativo
            NOT R1, R1
            ADD R1, R1, #1           ; R1 = |b|
B_POS       NOT R3, R1
            ADD R3, R3, #1           ; R3 = -|b|

            ADD R0, R0, #0           ; dividendo negativo ?
            BRzp A_POS
            ADD R5, R5, #1
            NOT R0, R0
            ADD R0, R0, #1           ; R0 = |a|
A_POS       ADD R5, R5, #-1          ; cuenta 0 -> -1, 1 -> 0, 2 -> 1
            BRz SIGNO_NEG            ; exactamente un operando negativo
            AND R5, R5, #0           ; cociente positivo: R5 = 0
            BRnzp SIGNO_FIN
SIGNO_NEG   ADD R5, R5, #1           ; cociente negativo: R5 = 1

SIGNO_FIN   BRnzp PRE_START

ESTADO      .FILL x0000              ; 0 = ok, 1 = divisor 0, 2 = desborde
K_X8000     .FILL x8000
K_16        .FILL #16

            ; Dividendo de 32 bits = (R1:R0) = |a| desplazado s bits a la izquierda
PRE_START   AND R1, R1, #0           ; palabra alta = 0 (|b| ya esta en R3)
            ADD R2, R2, #0
            BRz PRE_FIN
PRE         ADD R1, R1, R1           ; (R1:R0) <<= 1
            ADD R0, R0, #0
            BRzp PRE_SIN
            ADD R1, R1, #1           ; el bit 15 de R0 pasa a R1
PRE_SIN     ADD R0, R0, R0
            ADD R2, R2, #-1
            BRp PRE

PRE_FIN     ADD R4, R1, R3           ; palabra alta - |b|
            BRn LAZO_INIT            ; si alta < |b|, no hay overflow inicial

            ; Overflow por palabra alta >= |b|
            AND R4, R4, #0
            ADD R4, R4, #2
            STW R4, ESTADO           ; estado = 2
            LDW R0, K_X8000
            ADD R5, R5, #0
            BRp JMP_EPIL_1
            NOT R0, R0
JMP_EPIL_1  LEA R4, EPILOGO
            JMP R4

            ; Lazo principal: 16 vueltas; (resto:cociente) <<= 1 y comparar con |b|
LAZO_INIT   LDW R2, K_16             ; R2 = 16 iteraciones
LAZO        ADD R0, R0, #0
            BRzp L_BIT0
            ADD R0, R0, R0           ; sale un 1 de R0 ...
            ADD R1, R1, R1
            ADD R1, R1, #1           ; ... y entra al resto
            BRnzp L_CMP
L_BIT0      ADD R0, R0, R0
            ADD R1, R1, R1
L_CMP       ADD R1, R1, #0
            BRn L_SIEMPRE            ; resto >= x8000 (>= |b| seguro)
            ADD R4, R1, R3           ; resto - |b|
            BRn L_SEGUIR             ; resto < |b|: bit 0
            ADD R1, R4, #0           ; resto = resto - |b|
            ADD R0, R0, #1           ; bit del cociente = 1
            BRnzp L_SEGUIR
L_SIEMPRE   ADD R1, R1, R3           ; resto - |b|
            ADD R0, R0, #1
L_SEGUIR    ADD R2, R2, #-1
            BRp LAZO

            ; R0 = cociente sin signo; aplicar el signo y verificar el rango
            ADD R5, R5, #0
            BRp POST_NEG
            ADD R0, R0, #0           ; positivo: debe ser <= x7FFF
            BRzp JMP_EPIL_2
            BRnzp SAT_POS
POST_NEG    ADD R0, R0, #0           ; negativo: debe ser <= x8000
            BRzp NEG_APLIC
            ADD R4, R0, R0           ; si R0 >= x8000 solo vale x8000
            BRz JMP_EPIL_2
            BRnzp SAT_NEG
NEG_APLIC   NOT R0, R0
            ADD R0, R0, #1
            BRnzp JMP_EPIL_2

JMP_EPIL_2  LDW R4, PTR_EPILOGO
            JMP R4

PTR_EPILOGO .FILL EPILOGO
PTR_ESTADO  .FILL ESTADO
K_X8000_LOW .FILL x8000

SAT_POS     AND R4, R4, #0
            ADD R4, R4, #2
            LDW R3, PTR_ESTADO
            STRW R4, R3, #0          ; estado = 2
            LDW R0, K_X8000_LOW
            NOT R0, R0               ; x7FFF (32767)
            BRnzp JMP_EPIL_2

SAT_NEG     AND R4, R4, #0
            ADD R4, R4, #2
            LDW R3, PTR_ESTADO
            STRW R4, R3, #0          ; estado = 2
            LDW R0, K_X8000_LOW      ; x8000 (-32768)
            BRnzp JMP_EPIL_2

; ---- DIV_LONG: a/b con a y b en Q7.8, resultado en Q7.8 (s = 8) ----
DIV_LONG    ADD R6, R6, #-2
            STRW R2, R6, #0
            ADD R6, R6, #-2
            STRW R7, R6, #0
            AND R2, R2, #0
            ADD R2, R2, #7
            ADD R2, R2, #1           ; s = 8
            JSR DIVIDIR              ; R0 = a/b en Q7.8; R1..R5 vuelven intactos
            LDRW R7, R6, #0
            ADD R6, R6, #2
            LDRW R2, R6, #0
            ADD R6, R6, #2
            RET
            .END