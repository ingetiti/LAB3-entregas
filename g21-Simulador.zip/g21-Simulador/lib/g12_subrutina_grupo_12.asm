; =====================================================================
; SUBRUTINA DIV_NEWTON : division en punto fijo via Newton-Raphson
; Adaptado para ISA Grupo 21 (byte-addressable Little-Endian)
; =====================================================================

DIV_NEWTON
    ; --- 1. GUARDADO DE ESTADO EN PILA (R6) ---
    ADD     R6, R6, #-2
    STRW    R1, R6, #0
    ADD     R6, R6, #-2
    STRW    R2, R6, #0
    ADD     R6, R6, #-2
    STRW    R3, R6, #0
    ADD     R6, R6, #-2
    STRW    R4, R6, #0
    ADD     R6, R6, #-2
    STRW    R5, R6, #0
    ADD     R6, R6, #-2
    STRW    R7, R6, #0

    ; --- 2. LOGICA DE SIGNOS (Entradas: R0=Dividendo, R1=Divisor) ---
    AND     R2, R2, #0           ; R2 = contador temporal de signos

    ADD     R3, R0, #0           ; Evaluar Dividendo (R0)
    BRzp    CHK_DIVISOR
    NOT     R3, R3
    ADD     R3, R3, #1           ; |Dividendo|
    ADD     R2, R2, #1

CHK_DIVISOR
    ADD     R4, R1, #0           ; Evaluar Divisor (R1)
    BRzp    SIGN_DONE
    NOT     R4, R4
    ADD     R4, R4, #1           ; |Divisor|
    ADD     R2, R2, #1

SIGN_DONE
    AND     R2, R2, #1           ; 1 si el signo final es negativo
    STW     R2, D_FLAG_SIGNO_A
    STW     R3, D_VAR_DIV_A
    ADD     R2, R4, #0           ; R2 = |Divisor|

    ; --- 3. REDUCCION DE RANGO ---
    ADD     R2, R2, #0
    BRz     ERR_DIV0_TRAMP

    AND     R3, R3, #0           ; s = 0
    ADD     R5, R2, #0
FIND_S_LOOP
    ADD     R5, R5, #0
    BRn     FIND_S_DONE
    ADD     R5, R5, R5
    ADD     R3, R3, #1
    BRnzp   FIND_S_LOOP
FIND_S_DONE
    STW     R3, D_SAVED_S_A
    BRnzp   POST_S_SAVE

ERR_DIV0_TRAMP
    LDW     R7, PTR_ERR_DIV0_L
    JMP     R7

PTR_ERR_DIV0_L  .FILL   ERROR_DIV0
D_FLAG_SIGNO_A  .FILL   #0
D_VAR_DIV_A     .FILL   #0
D_SAVED_S_A     .FILL   #0

POST_S_SAVE
    ADD     R4, R3, #-4
    BRz     NORM_DONE
    BRp     NORM_LEFT
    NOT     R4, R4
    ADD     R4, R4, #1           ; R4 = 4 - s
    BRnzp   NORM_R_START

K15_NORM        .FILL   #15

NORM_R_START
NORM_RIGHT_OUTER
    AND     R0, R0, #0
    LDW     R1, K15_NORM
    ADD     R5, R2, #0
NORM_SR_LOOP
    ADD     R0, R0, R0
    ADD     R5, R5, #0
    BRzp    NORM_SR_SKIP
    ADD     R0, R0, #1
NORM_SR_SKIP
    ADD     R5, R5, R5
    ADD     R1, R1, #-1
    BRp     NORM_SR_LOOP
    ADD     R2, R0, #0
    ADD     R4, R4, #-1
    BRp     NORM_RIGHT_OUTER
    BRnzp   NORM_DONE

NORM_LEFT
    ADD     R2, R2, R2
    ADD     R4, R4, #-1
    BRp     NORM_LEFT

NORM_DONE
    ADD     R5, R2, #0
    AND     R4, R4, #0
    ADD     R4, R4, #7
    ADD     R4, R4, #1           ; R4 = 8
    BRnzp   IDX_START

K15_IDX         .FILL   #15

IDX_START
IDX_RIGHT_OUTER
    AND     R0, R0, #0
    LDW     R1, K15_IDX
    ADD     R7, R5, #0
IDX_SR_LOOP
    ADD     R0, R0, R0
    ADD     R7, R7, #0
    BRzp    IDX_SR_SKIP
    ADD     R0, R0, #1
IDX_SR_SKIP
    ADD     R7, R7, R7
    ADD     R1, R1, #-1
    BRp     IDX_SR_LOOP
    ADD     R5, R0, #0
    ADD     R4, R4, #-1
    BRp     IDX_RIGHT_OUTER

    LDW     R0, D_MASK_0007
    AND     R3, R5, R0
    LSL     R3, R3, #1           ; indice * 2 bytes por entrada en TABLA_LUT

    LEA     R4, TABLA_LUT
    ADD     R4, R4, R3
    LDRW    R5, R4, #0           ; R5 = estimacion inicial x0

    ; --- 4. NEWTON-RAPHSON (2 iteraciones) ---
    ADD     R0, R2, #0
    ADD     R1, R5, #0
    LDW     R7, PTR_MULT_MOD
    JSRR    R7
    LDW     R3, M_RES_MULT
    LDW     R7, D_DOS_Q312
    SUB     R7, R7, R3           ; 2 - d*x0
    ADD     R0, R5, #0
    ADD     R1, R7, #0
    LDW     R7, PTR_MULT_MOD
    JSRR    R7
    LDW     R5, M_RES_MULT       ; x1 = x0 * (2 - d*x0)

    ADD     R0, R2, #0
    ADD     R1, R5, #0
    LDW     R7, PTR_MULT_MOD
    JSRR    R7
    LDW     R3, M_RES_MULT
    LDW     R7, D_DOS_Q312
    SUB     R7, R7, R3           ; 2 - d*x1
    ADD     R0, R5, #0
    ADD     R1, R7, #0
    LDW     R7, PTR_MULT_MOD
    JSRR    R7
    LDW     R5, M_RES_MULT       ; x2 = x1 * (2 - d*x1)

    ; Multiplicacion final: |Dividendo| * x2
    LDW     R0, D_VAR_DIV_A
    ADD     R1, R5, #0
    LDW     R7, PTR_MULT_MOD
    JSRR    R7
    LDW     R2, M_RES_MULT

    ; Sincronizar variables para desnormalizacion y signo
    LDW     R3, D_SAVED_S_A
    STW     R3, D2_SAVED_S
    LDW     R3, D_FLAG_SIGNO_A
    STW     R3, D2_FLAG_SIGNO

    LDW     R7, PTR_POST_MULT
    JMP     R7

; ---- Datos locales de la primera mitad (dentro de [-128..127] bytes) ----
D_MASK_0007     .FILL   x0007
D_DOS_Q312      .FILL   x2000
PTR_MULT_MOD    .FILL   MULT_MODULO
PTR_POST_MULT   .FILL   POST_MULT

TABLA_LUT       .FILL   x1E1E
                .FILL   x1AF2
                .FILL   x1861
                .FILL   x1642
                .FILL   x147A
                .FILL   x12F6
                .FILL   x11A7
                .FILL   x1084

; --- 5. DESNORMALIZACION ---
POST_MULT
    LDW     R3, D2_SAVED_S
    ADD     R4, R3, #-8
    BRz     DENORM_DONE
    BRp     DENORM_LEFT
    NOT     R4, R4
    ADD     R4, R4, #1           ; R4 = 8 - s
    BRnzp   DENORM_R_START

K15_DENORM      .FILL   #15

DENORM_R_START
DENORM_RIGHT_OUTER
    AND     R0, R0, #0
    LDW     R1, K15_DENORM
    ADD     R5, R2, #0
DENORM_SR_LOOP
    ADD     R0, R0, R0
    ADD     R5, R5, #0
    BRzp    DENORM_SR_SKIP
    ADD     R0, R0, #1
DENORM_SR_SKIP
    ADD     R5, R5, R5
    ADD     R1, R1, #-1
    BRp     DENORM_SR_LOOP
    ADD     R2, R0, #0
    ADD     R4, R4, #-1
    BRp     DENORM_RIGHT_OUTER
    BRnzp   DENORM_DONE

DENORM_LEFT
    ADD     R2, R2, R2
    ADD     R4, R4, #-1
    BRp     DENORM_LEFT

DENORM_DONE
    ; --- 6. RESTAURACION DE SIGNO ---
    LDW     R0, D2_FLAG_SIGNO
    BRz     FIN_EXITOSO
    NOT     R2, R2
    ADD     R2, R2, #1

FIN_EXITOSO
    ADD     R0, R2, #0
    LDW     R7, PTR_REST_ESTADO
    JMP     R7

ERROR_DIV0
    AND     R0, R0, #0
    NOT     R0, R0               ; R0 = xFFFF (-1)

RESTAURAR_ESTADO
    LDRW    R7, R6, #0
    ADD     R6, R6, #2
    LDRW    R5, R6, #0
    ADD     R6, R6, #2
    LDRW    R4, R6, #0
    ADD     R6, R6, #2
    LDRW    R3, R6, #0
    ADD     R6, R6, #2
    LDRW    R2, R6, #0
    ADD     R6, R6, #2
    LDRW    R1, R6, #0
    ADD     R6, R6, #2
    RET

; ---- Datos locales de desnormalizacion y retorno ----
D2_SAVED_S      .FILL   #0
D2_FLAG_SIGNO   .FILL   #0
PTR_REST_ESTADO .FILL   RESTAURAR_ESTADO

; --- SUBRUTINA: MULTIPLICACION MODULAR 32 BITS ---
MULT_MODULO
    ADD     R6, R6, #-2
    STRW    R0, R6, #0
    ADD     R6, R6, #-2
    STRW    R1, R6, #0
    ADD     R6, R6, #-2
    STRW    R2, R6, #0
    ADD     R6, R6, #-2
    STRW    R3, R6, #0
    ADD     R6, R6, #-2
    STRW    R4, R6, #0
    ADD     R6, R6, #-2
    STRW    R5, R6, #0
    ADD     R6, R6, #-2
    STRW    R7, R6, #0

    AND     R4, R4, #0
    AND     R5, R5, #0
    ADD     R2, R1, #0
    LDW     R3, M_CONT_16

LOOP_MULT
    ADD     R5, R5, #0
    BRzp    SHIFT_ACC_NORM
    ADD     R5, R5, R5
    ADD     R4, R4, R4
    ADD     R4, R4, #1
    BRnzp   SHIFT_ACC_FIN
SHIFT_ACC_NORM
    ADD     R5, R5, R5
    ADD     R4, R4, R4
SHIFT_ACC_FIN
    ADD     R2, R2, #0
    BRzp    OMITIR_SUMA
    ADD     R5, R5, #0
    BRzp    SUMAR_NORM
    ADD     R5, R5, R0
    BRn     OMITIR_SUMA
    ADD     R4, R4, #1
    BRnzp   OMITIR_SUMA
SUMAR_NORM
    ADD     R5, R5, R0
OMITIR_SUMA
    ADD     R2, R2, R2
    ADD     R3, R3, #-1
    BRp     LOOP_MULT

    LDW     R3, M_CONT_4
AJUSTE_Q312
    ADD     R5, R5, #0
    BRzp    SHIFT_AJ_NORM
    ADD     R5, R5, R5
    ADD     R4, R4, R4
    ADD     R4, R4, #1
    BRnzp   SHIFT_AJ_FIN
SHIFT_AJ_NORM
    ADD     R5, R5, R5
    ADD     R4, R4, R4
SHIFT_AJ_FIN
    ADD     R3, R3, #-1
    BRp     AJUSTE_Q312

    STW     R4, M_RES_MULT

    LDRW    R7, R6, #0
    ADD     R6, R6, #2
    LDRW    R5, R6, #0
    ADD     R6, R6, #2
    LDRW    R4, R6, #0
    ADD     R6, R6, #2
    LDRW    R3, R6, #0
    ADD     R6, R6, #2
    LDRW    R2, R6, #0
    ADD     R6, R6, #2
    LDRW    R1, R6, #0
    ADD     R6, R6, #2
    LDRW    R0, R6, #0
    ADD     R6, R6, #2
    RET

; ---- Datos locales de MULT_MODULO ----
M_CONT_16       .FILL   #16
M_CONT_4        .FILL   #4
M_RES_MULT      .FILL   #0

    .END