.ORIG x3000
    .EXTERNAL operaciones-SUMAR
    AND R0,R0,#0
    ADD R0,R0,#5
    AND R1,R1,#0
    ADD R1,R1,#7
    LD R3,PTR_SUMAR
    JSRR R3
    ST R0,RESULTADO
    HALT
RESULTADO .BLKW #1
PTR_SUMAR .FILL operaciones-SUMAR
.END
