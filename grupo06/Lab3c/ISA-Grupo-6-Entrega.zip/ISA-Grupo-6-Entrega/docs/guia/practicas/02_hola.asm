.ORIG x3000
    LEA R0,MENSAJE
    PUTS
    HALT
MENSAJE .STRINGZ "Hola desde nuestra ISA3C!\n"
.END
